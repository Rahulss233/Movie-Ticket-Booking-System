package com.moviebooking.config;

import com.moviebooking.dto.Dtos.RegisterRequest;
import com.moviebooking.entity.Location;
import com.moviebooking.enums.LocationType;
import com.moviebooking.enums.Role;
import com.moviebooking.repository.LocationRepository;
import com.moviebooking.repository.UserRepository;
import com.moviebooking.service.AuthService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/** Idempotent bootstrap: creates the first Super Admin and a few starter locations only if missing. */
@Component
public class DataInitializer implements CommandLineRunner {
    private static final Logger log = LoggerFactory.getLogger(DataInitializer.class);
    private final UserRepository users;
    private final LocationRepository locations;
    private final AuthService auth;
    @Value("${app.admin.name:Super Admin}") private String adminName;
    @Value("${app.admin.email}") private String adminEmail;
    @Value("${app.admin.password}") private String adminPassword;

    public DataInitializer(UserRepository users, LocationRepository locations, AuthService auth) {
        this.users = users;
        this.locations = locations;
        this.auth = auth;
    }

    @Override
    public void run(String... args) {
        if (users.countByRole(Role.SUPER_ADMIN) == 0) {
            auth.createUser(new RegisterRequest(adminName, adminEmail, "9000000000", adminPassword), Role.SUPER_ADMIN);
            log.warn("Created initial Super Admin '{}'. Change the password / set ADMIN_PASSWORD before deploying.", adminEmail);
        }
        seedIndianLocations();
    }

    /** Idempotently seeds the national state/UT list and starter district/city records.
     * Remaining districts can be added by Super Admin from Locations without SQL changes. */
    private void seedIndianLocations() {
        String[] states = {"Tamil Nadu"};
        for (String name : states) ensure(name, LocationType.STATE, null);
        String[][] districts = {
          {"Tamil Nadu","Ariyalur","Chengalpattu","Chennai","Coimbatore","Cuddalore","Dharmapuri","Dindigul","Erode","Kallakurichi","Kancheepuram","Kanniyakumari","Karur","Krishnagiri","Madurai","Mayiladuthurai","Nagapattinam","Namakkal","Nilgiris","Perambalur","Pudukkottai","Ramanathapuram","Ranipet","Salem","Sivaganga","Tenkasi","Thanjavur","Theni","Thoothukudi","Tiruchirappalli","Tirunelveli","Tirupathur","Tiruppur","Tiruvallur","Tiruvannamalai","Tiruvarur","Vellore","Viluppuram","Virudhunagar"},
        };
        for (String[] group : districts) for (int i=1;i<group.length;i++) {
            Location state = ensure(group[0], LocationType.STATE, null);
            Location district = ensure(group[i], LocationType.DISTRICT, state);
            ensure(group[i], LocationType.CITY, district);
        }
        seed("Tamil Nadu", "Karur", "Karur");
        seed("Tamil Nadu", "Chennai", "Chennai");
        seedTowns();
    }

    /** Real towns / areas under each district, so customers pick e.g. Tiruppur -> Kangayam instead of a duplicate district name. */
    private void seedTowns() {
        String[][] towns = {
          {"Tamil Nadu","Tiruppur","Kangayam","Dharapuram","Avinashi","Palladam","Udumalpet","Pongalur","Madathukulam","Uthukuli","Vellakoil"},
          {"Tamil Nadu","Coimbatore","Pollachi","Mettupalayam","Sulur","Annur","Valparai","Kinathukadavu","Thondamuthur","Perur","Gandhipuram","RS Puram","Singanallur"},
          {"Tamil Nadu","Erode","Gobichettipalayam","Bhavani","Perundurai","Sathyamangalam","Anthiyur","Kodumudi"},
          {"Tamil Nadu","Karur","Kulithalai","Aravakurichi","Krishnarayapuram","Kadavur"},
          {"Tamil Nadu","Salem","Attur","Mettur","Omalur","Edappadi","Sankagiri","Vazhapadi"},
          {"Tamil Nadu","Namakkal","Rasipuram","Tiruchengode","Paramathi Velur","Kumarapalayam"},
          {"Tamil Nadu","Madurai","Melur","Usilampatti","Thirumangalam","Vadipatti"},
          {"Tamil Nadu","Tiruchirappalli","Srirangam","Lalgudi","Manapparai","Musiri","Thuraiyur"},
          {"Tamil Nadu","Chennai","T. Nagar","Anna Nagar","Adyar","Velachery","Porur","Perambur","Guindy"},
          {"Tamil Nadu","Chengalpattu","Tambaram","Maraimalai Nagar","Madurantakam","Pallavaram"},
          {"Tamil Nadu","Tirunelveli","Palayamkottai","Ambasamudram","Nanguneri"},
          {"Tamil Nadu","Thanjavur","Kumbakonam","Pattukkottai","Orathanadu","Papanasam"},
          {"Tamil Nadu","Vellore","Katpadi","Gudiyatham","Anaikattu","Pernambut"},
          {"Tamil Nadu","Dindigul","Palani","Kodaikanal","Oddanchatram","Vedasandur","Nilakottai"},
          {"Tamil Nadu","Nilgiris","Udhagamandalam","Coonoor","Kotagiri","Gudalur"},
          {"Tamil Nadu","Theni","Bodinayakanur","Cumbum","Periyakulam","Uthamapalayam"},
          {"Tamil Nadu","Kanniyakumari","Nagercoil","Marthandam","Thuckalay","Colachel"},
          {"Tamil Nadu","Cuddalore","Chidambaram","Virudhachalam","Neyveli"},
          {"Tamil Nadu","Thoothukudi","Kovilpatti","Tiruchendur"}
        };
        for (String[] g : towns) {
            Location state = ensure(g[0], LocationType.STATE, null);
            Location district = ensure(g[1], LocationType.DISTRICT, state);
            for (int i = 2; i < g.length; i++) ensure(g[i], LocationType.CITY, district);
        }
    }

    private Location ensure(String name, LocationType type, Location parent) {
        return locations.findByTypeAndParentIsNullOrderByName(type).stream().filter(x -> parent == null && x.getName().equalsIgnoreCase(name)).findFirst()
          .orElseGet(() -> {
            if (parent != null) return locations.findByParentIdOrderByName(parent.getId()).stream().filter(x -> x.getType() == type && x.getName().equalsIgnoreCase(name)).findFirst().orElseGet(() -> make(name,type,parent));
            return make(name,type,null);
          });
    }

    private void seed(String state, String district, String city) {
        Location s = ensure(state, LocationType.STATE, null);
        Location d = ensure(district, LocationType.DISTRICT, s);
        ensure(city, LocationType.CITY, d);
    }

    private Location make(String name, LocationType type, Location parent) {
        Location l = new Location();
        l.setName(name);
        l.setType(type);
        l.setParent(parent);
        return locations.save(l);
    }
}
