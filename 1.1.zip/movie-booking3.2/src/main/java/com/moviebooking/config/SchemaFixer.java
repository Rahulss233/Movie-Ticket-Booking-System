package com.moviebooking.config;

import java.sql.Connection;
import java.sql.ResultSet;
import javax.sql.DataSource;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/**
 * Safety net for databases created by an older version of the project.
 * 1) Hibernate's ddl-auto=update never widens a column: movies.status was VARCHAR(10), too short for PENDING_REVIEW.
 * 2) If Hibernate could not add a new column (its DDL errors are only logged), every query on that table would fail with
 *    "Something went wrong". This adds any expected column that is missing. Both steps are harmless when nothing is needed.
 */
@Slf4j
@Component
@Order(1)
@RequiredArgsConstructor
public class SchemaFixer implements ApplicationRunner {
    private final JdbcTemplate jdbc;
    private final DataSource dataSource;

    /** table, column, MySQL column type */
    private static final String[][] EXPECTED = {
            {"seats", "section", "varchar(40)"}, {"seats", "grid_row", "int"}, {"seats", "grid_col", "int"},
            {"shows", "audio_language", "varchar(40)"}, {"shows", "dimension", "varchar(10)"}, {"shows", "special_formats", "varchar(120)"}, {"shows", "cancel_reason", "varchar(300)"},
            {"screens", "layout_json", "text"}, {"screens", "special_formats", "varchar(120)"},
            {"theatres", "cancellation_available", "bit"},
            {"bookings", "refund_completed_at", "datetime(6)"}, {"bookings", "refund_reference", "varchar(60)"}, {"bookings", "offer_code", "varchar(40)"}, {"bookings", "discount_amount", "decimal(10,2)"},
            {"movies", "proposed_by_email", "varchar(150)"},
    };

    private boolean hasColumn(Connection c, String table, String column) throws Exception {
        try (ResultSet rs = c.getMetaData().getColumns(c.getCatalog(), null, table, column)) {
            if (rs.next()) return true;
        }
        try (ResultSet rs = c.getMetaData().getColumns(c.getCatalog(), null, table.toUpperCase(), column.toUpperCase())) {   // H2 stores names upper-case
            return rs.next();
        }
    }

    @Override
    public void run(ApplicationArguments args) {
        try { jdbc.execute("ALTER TABLE movies MODIFY COLUMN status VARCHAR(20) NOT NULL"); log.info("Schema check OK: movies.status is wide enough"); }
        catch (Exception e) { log.warn("Schema check skipped (movies.status): {}", e.getMessage()); }
        try (Connection c = dataSource.getConnection()) {
            for (String[] col : EXPECTED) {
                try {
                    if (hasColumn(c, col[0], col[1])) continue;
                    jdbc.execute("ALTER TABLE " + col[0] + " ADD COLUMN " + col[1] + " " + col[2] + " NULL");
                    log.warn("Schema repair: added missing column {}.{}", col[0], col[1]);
                } catch (Exception e) { log.error("Schema repair FAILED for {}.{}: {}", col[0], col[1], e.getMessage()); }
            }
        } catch (Exception e) { log.warn("Schema column check skipped: {}", e.getMessage()); }
    }
}
