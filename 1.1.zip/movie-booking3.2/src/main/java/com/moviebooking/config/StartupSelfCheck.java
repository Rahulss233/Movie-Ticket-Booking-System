package com.moviebooking.config;

import com.moviebooking.enums.PaymentStatus;
import com.moviebooking.repository.*;
import java.time.LocalDateTime;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * Runs each important database query once at startup and prints a clear line for any that fail
 * (for example a column that the database does not have yet). Purely diagnostic: it never stops the app.
 */
@Slf4j
@Component
@Order(100)
@RequiredArgsConstructor
public class StartupSelfCheck implements ApplicationRunner {
    private final BookingRepository bookings;
    private final PaymentRepository payments;
    private final OfferRepository offers;
    private final ReviewRepository reviews;
    private final ComplaintRepository complaints;
    private final TheatreMovieRepository listings;
    private final ShowRepository shows;
    private final ShowSeatRepository showSeats;
    private final MovieRepository movies;
    private final ScreenRepository screens;
    private final SeatRepository seats;

    private void probe(String name, Runnable r) {
        try { r.run(); }
        catch (Exception e) {
            Throwable root = e; while (root.getCause() != null && root.getCause() != root) root = root.getCause();
            log.error("SELF-CHECK FAILED [{}]: {} - {}", name, root.getClass().getSimpleName(), root.getMessage());
        }
    }

    @Override
    public void run(ApplicationArguments args) {
        LocalDateTime now = LocalDateTime.now();
        probe("movies", () -> movies.findAll(org.springframework.data.domain.PageRequest.of(0, 1)));
        probe("screens", () -> screens.findAll(org.springframework.data.domain.PageRequest.of(0, 1)));
        probe("seats", () -> seats.findAll(org.springframework.data.domain.PageRequest.of(0, 1)));
        probe("shows", () -> shows.findAll(org.springframework.data.domain.PageRequest.of(0, 1)));
        probe("finance bookings", () -> bookings.financeByCreated(null, null, null, null, now.minusDays(1), now));
        probe("finance payments", () -> payments.financeByCreated(null, null, null, null, now.minusDays(1), now));
        probe("refund list", () -> bookings.findByPaymentStatuses(List.of(PaymentStatus.REFUND_PENDING)));
        probe("offers", () -> offers.findLive(now));
        probe("offer manager list", () -> offers.findForManager(null));
        probe("reviews", () -> reviews.findFiltered(null, false, false));
        probe("complaints", () -> complaints.findByTypes(List.of("PLATFORM")));
        probe("theatre movie runs", () -> listings.findAllForTheatre(0L));
        probe("upcoming shows", () -> shows.findUpcomingForMovie(0L, 0L, now));
        probe("price range", () -> showSeats.priceRange(0L));
        probe("booking search", () -> bookings.searchBookings(null, null, null, now.minusDays(1), now));
        probe("available movies", () -> shows.availableMovies(null, null, null, now));
        log.info("Startup self-check finished. Any line above starting with SELF-CHECK FAILED shows what to fix.");
    }
}
