package com.moviebooking.controller;

import com.moviebooking.dto.Dtos.*;
import com.moviebooking.entity.*;
import com.moviebooking.enums.*;
import com.moviebooking.security.CurrentUser;
import com.moviebooking.service.*;
import jakarta.servlet.http.*;
import jakarta.validation.Valid;
import java.time.LocalDate;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class AdminController {
    private final AdminService admin;
    private final CurrentUser currentUser;
    private final MovieImportService movieImport;
    private final MovieOpsService movieOps;

    @GetMapping("/dashboard")
    public DashboardView dashboard() { return admin.dashboard(); }

    @GetMapping("/payments")
    public List<PaymentLedgerView> payments() { return admin.paymentLedger(); }

    @GetMapping("/audit")
    public List<AuditView> audit() { return admin.auditTrail(); }

    @GetMapping("/theatres")
    public List<TheatreView> theatres(@RequestParam(required = false) String status, @RequestParam(required = false) String q) {
        return admin.listTheatres(status, q);
    }

    @PostMapping("/theatres/{id}/status")
    public TheatreView status(@PathVariable Long id, @Valid @RequestBody StatusActionRequest r) {
        return admin.changeStatus(id, r, currentUser.get().getEmail());
    }

    @GetMapping("/theatres/{id}/history")
    public List<HistoryView> history(@PathVariable Long id) { return admin.theatreHistory(id); }

    @GetMapping("/theatres/{id}/screens")
    public List<ScreenView> screens(@PathVariable Long id) { return admin.theatreScreens(id); }

    @PutMapping("/theatres/{id}/commission")
    public TheatreView theatreCommission(@PathVariable Long id, @Valid @RequestBody CommissionRequest r) {
        return admin.setTheatreCommission(id, r, currentUser.get().getEmail());
    }

    @PutMapping("/screens/{id}/commission")
    public ScreenView screenCommission(@PathVariable Long id, @Valid @RequestBody CommissionRequest r) {
        return admin.setScreenCommission(id, r, currentUser.get().getEmail());
    }

    @GetMapping("/movies")
    public List<Movie> movies(@RequestParam(required = false) String status) { return admin.listMovies(status); }

    @GetMapping("/movie-import/status")
    public java.util.Map<String, Object> importStatus() { return movieImport.status(); }

    @GetMapping("/movie-import/history")
    public List<MovieImportRun> importHistory() { return movieImport.history(); }

    @PostMapping("/movie-import/sync")
    public List<MovieImportRun> syncMovieMetadata(@RequestParam(required = false) String provider) {
        return movieImport.runAll("MANUAL", provider);
    }

    /** Movies currently in booking (live theatre run or upcoming shows). */
    @GetMapping("/movies/in-booking")
    public List<java.util.Map<String, Object>> moviesInBooking() { return movieOps.inBooking(); }

    @PostMapping("/movies/{id}/remove")
    public java.util.Map<String, Object> removeMovie(@PathVariable Long id, @RequestBody java.util.Map<String, String> body) {
        return movieOps.remove(id, body.get("remarks"), currentUser.get());
    }

    @PutMapping("/movies/{id}")
    public Movie updateMovie(@PathVariable Long id, @Valid @RequestBody MovieRequest r) {
        return admin.saveMovie(id, r, currentUser.get().getEmail());
    }

    @PostMapping("/locations")
    @ResponseStatus(HttpStatus.CREATED)
    public LocationView addLocation(@Valid @RequestBody LocationRequest r) { return admin.addLocation(r, currentUser.get().getEmail()); }

    @GetMapping("/users")
    public List<UserView> users() { return admin.listUsers(); }

    @PostMapping("/users/{id}/active")
    public UserView active(@PathVariable Long id, @RequestBody ActiveRequest r) {
        return admin.setUserActive(id, r.active(), currentUser.get().getEmail());
    }
}
