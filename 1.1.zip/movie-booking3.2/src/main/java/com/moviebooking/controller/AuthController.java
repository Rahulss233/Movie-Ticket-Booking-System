package com.moviebooking.controller;

import com.moviebooking.dto.Dtos.*;
import com.moviebooking.entity.*;
import com.moviebooking.enums.*;
import com.moviebooking.security.CurrentUser;
import com.moviebooking.service.*;
import jakarta.servlet.http.*;
import jakarta.validation.Valid;
import java.time.LocalDate;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import com.moviebooking.repository.UserRepository;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {
    private final AuthService authService;
    private final AuthenticationManager authManager;
    private final CurrentUser currentUser;
    private final ViewMapper mapper;

    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    public UserView register(@Valid @RequestBody RegisterRequest r) {
        return authService.registerCustomer(r);
    }

    @PostMapping("/register-theatre")
    @ResponseStatus(HttpStatus.CREATED)
    public UserView registerTheatre(@Valid @RequestBody TheatreRegistrationRequest r) {
        return authService.registerTheatre(r);
    }

    @PostMapping("/login")
    public UserView login(@Valid @RequestBody LoginRequest r, HttpServletRequest req, HttpServletResponse res) {
        Authentication auth = authManager.authenticate(
                new UsernamePasswordAuthenticationToken(r.email().toLowerCase().trim(), r.password()));
        if (req.getSession(false) != null) req.changeSessionId();   // prevent session fixation
        SecurityContext ctx = SecurityContextHolder.createEmptyContext();
        ctx.setAuthentication(auth);
        SecurityContextHolder.setContext(ctx);
        new HttpSessionSecurityContextRepository().saveContext(ctx, req, res);
        return mapper.user(currentUser.get());
    }

    @PostMapping("/logout")
    public void logout(HttpServletRequest req) {
        HttpSession s = req.getSession(false);
        if (s != null) s.invalidate();
        SecurityContextHolder.clearContext();
    }

    @GetMapping("/me")
    public UserView me() {
        return mapper.user(currentUser.get());
    }

    @PutMapping("/me")
    public UserView updateMe(@Valid @RequestBody ProfileUpdate r) {
        return authService.updateProfile(currentUser.get(), r);
    }
}
