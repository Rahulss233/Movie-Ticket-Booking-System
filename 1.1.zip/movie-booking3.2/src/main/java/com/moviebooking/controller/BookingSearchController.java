package com.moviebooking.controller;

import com.moviebooking.enums.Role;
import com.moviebooking.security.CurrentUser;
import com.moviebooking.service.BookingSearchService;
import com.moviebooking.service.TheatreService;
import java.time.LocalDate;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

/** Super Admin: every theatre (or one chosen). Theatre Admin: only their own theatre, whatever theatreId the browser sends. */
@RestController
@RequiredArgsConstructor
public class BookingSearchController {
    private final BookingSearchService search;
    private final TheatreService theatres;
    private final CurrentUser currentUser;

    @GetMapping({"/api/admin/bookings", "/api/theatre/bookings/search"})
    public BookingSearchService.Result find(@RequestParam(required = false) Long theatreId, @RequestParam(required = false) Long screenId, @RequestParam(required = false) Long movieId,
                                            @RequestParam(required = false) String status, @RequestParam(required = false) String paymentStatus,
                                            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
                                            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to,
                                            @RequestParam(required = false) String q, @RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "25") int size) {
        boolean theatreAdmin = currentUser.get().getRole() == Role.THEATRE_ADMIN;
        Long scope = theatreAdmin ? theatres.myTheatre(currentUser.get()).id() : theatreId;
        return search.search(scope, screenId, movieId, status, paymentStatus, from, to, q, !theatreAdmin, page, size);
    }
}
