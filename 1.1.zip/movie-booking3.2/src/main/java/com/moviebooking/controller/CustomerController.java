package com.moviebooking.controller;

import com.moviebooking.dto.Dtos.*;
import com.moviebooking.entity.*;
import com.moviebooking.enums.*;
import com.moviebooking.security.CurrentUser;
import com.moviebooking.service.*;
import jakarta.servlet.http.*;
import jakarta.validation.Valid;
import java.time.LocalDate;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import java.io.ByteArrayOutputStream;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/customer")
@RequiredArgsConstructor
public class CustomerController {
    private final BookingService bookingService;
    private final CurrentUser currentUser;
    private final com.moviebooking.repository.PaymentRepository payments;

    public record PaymentView(String bookingReference, String movieTitle, String theatreName, java.time.LocalDateTime paidAt, java.math.BigDecimal amount,
                              String status, String method, String transactionRef, String message) {}

    /** The customer's own payment history (successful, failed and refunded attempts). */
    @GetMapping("/payments")
    @org.springframework.transaction.annotation.Transactional(readOnly = true)
    public java.util.List<PaymentView> myPayments() {
        return payments.forCustomer(currentUser.get().getId()).stream().map(p -> new PaymentView(p.getBooking().getReference(),
                p.getBooking().getShow().getMovie().getTitle(), p.getBooking().getShow().getScreen().getTheatre().getName(), p.getCreatedAt(), p.getAmount(),
                p.getStatus().name(), p.getTransactionRef().startsWith("MQR-") ? "Phone QR scan" : "Website (test payment)",
                p.getTransactionRef(), p.getMessage())).toList();
    }

    @PostMapping("/bookings/hold")
    @ResponseStatus(HttpStatus.CREATED)
    public BookingView hold(@Valid @RequestBody HoldRequest r) {
        return bookingService.holdSeats(currentUser.get(), r);
    }

    @PostMapping("/bookings/{reference}/pay")
    public BookingView pay(@PathVariable String reference, @Valid @RequestBody PayRequest r) {
        return bookingService.pay(currentUser.get(), reference, r);
    }

    @PostMapping("/bookings/{reference}/cancel")
    public BookingView cancel(@PathVariable String reference) {
        return bookingService.cancel(currentUser.get(), reference);
    }

    @GetMapping("/bookings")
    public List<BookingView> mine() {
        return bookingService.myBookings(currentUser.get());
    }


    @GetMapping(value = "/bookings/{reference}/qr", produces = MediaType.IMAGE_PNG_VALUE)
    public ResponseEntity<byte[]> qr(@PathVariable String reference) throws Exception {
        String token = bookingService.ticketToken(currentUser.get(), reference);
        BitMatrix matrix = new QRCodeWriter().encode(token, BarcodeFormat.QR_CODE, 260, 260);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        MatrixToImageWriter.writeToStream(matrix, "PNG", out);
        return ResponseEntity.ok().contentType(MediaType.IMAGE_PNG).header("Cache-Control", "no-store").body(out.toByteArray());
    }

    /** QR for the test payment. Opens /pay.html on the phone, so the link must use an address the phone can reach (LAN IP, not localhost). */
    @GetMapping(value = "/bookings/{reference}/pay-qr", produces = MediaType.IMAGE_PNG_VALUE)
    public ResponseEntity<byte[]> payQr(@PathVariable String reference, jakarta.servlet.http.HttpServletRequest req,
                                        @org.springframework.beans.factory.annotation.Value("${app.public-base-url:}") String baseUrl) throws Exception {
        String token = bookingService.mobilePayToken(currentUser.get(), reference);
        String base = baseUrl == null || baseUrl.isBlank() ? req.getScheme() + "://" + lanHost(req.getServerName()) + ":" + req.getServerPort() : baseUrl.replaceAll("/+$", "");
        BitMatrix matrix = new QRCodeWriter().encode(base + "/pay.html?ref=" + reference + "&t=" + token, BarcodeFormat.QR_CODE, 260, 260);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        MatrixToImageWriter.writeToStream(matrix, "PNG", out);
        return ResponseEntity.ok().contentType(MediaType.IMAGE_PNG).header("Cache-Control", "no-store").body(out.toByteArray());
    }

    private static String lanHost(String host) {
        if (!host.equals("localhost") && !host.equals("127.0.0.1") && !host.equals("[::1]") && !host.equals("::1")) return host;
        try {
            for (var ni : java.util.Collections.list(java.net.NetworkInterface.getNetworkInterfaces()))
                if (ni.isUp() && !ni.isLoopback())
                    for (var a : java.util.Collections.list(ni.getInetAddresses()))
                        if (a instanceof java.net.Inet4Address && a.isSiteLocalAddress()) return a.getHostAddress();
        } catch (Exception ignored) { }
        return host;
    }

    @GetMapping("/bookings/{reference}")
    public BookingView one(@PathVariable String reference) {
        return bookingService.get(currentUser.get(), reference);
    }
}
