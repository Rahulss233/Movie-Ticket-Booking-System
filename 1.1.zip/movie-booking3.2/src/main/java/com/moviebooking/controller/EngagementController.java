package com.moviebooking.controller;

import com.moviebooking.entity.Theatre;
import com.moviebooking.repository.ShowRepository;
import com.moviebooking.security.CurrentUser;
import com.moviebooking.service.*;
import com.moviebooking.service.ComplaintService.*;
import com.moviebooking.service.OfferService.*;
import com.moviebooking.service.RefundService.RefundView;
import com.moviebooking.service.ReviewService.*;
import java.util.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

/**
 * Offers, reviews, complaints and refunds. Every path sits under /api/admin, /api/theatre or /api/customer,
 * so SecurityConfig already limits it to the right role; the services re-check ownership.
 */
@RestController
@RequiredArgsConstructor
public class EngagementController {
    private final OfferService offers;
    private final ReviewService reviews;
    private final ComplaintService complaints;
    private final RefundService refunds;
    private final TheatreService theatreService;
    private final ShowRepository shows;
    private final CurrentUser currentUser;

    private Theatre myTheatre() { return theatreService.requireOwned(currentUser.get()); }

    // ------------------------------------------------------------ offers
    @GetMapping("/api/public/offers")
    public List<OfferView> liveOffers() { return offers.live(); }

    public record ValidateRequest(String code, Long showId, List<Long> seatIds) {}

    @PostMapping("/api/customer/offers/validate")
    public Map<String, Object> validate(@RequestBody ValidateRequest r) {
        if (r.showId() == null || r.seatIds() == null || r.seatIds().isEmpty()) throw new com.moviebooking.exception.BadRequestException("Select seats first");
        return offers.preview(currentUser.get(), r.code(), r.showId(), r.seatIds(), shows);
    }

    @GetMapping("/api/admin/offers")
    public List<OfferView> adminOffers() { return offers.manage(null); }

    @PostMapping("/api/admin/offers")
    @ResponseStatus(HttpStatus.CREATED)
    public OfferView adminCreate(@RequestBody OfferRequest r) { return offers.create(currentUser.get(), null, r); }

    @PutMapping("/api/admin/offers/{id}/status")
    public OfferView adminStatus(@PathVariable Long id, @RequestParam String status) { return offers.setStatus(currentUser.get(), null, id, status); }

    @GetMapping("/api/theatre/offers")
    public List<OfferView> theatreOffers() { return offers.manage(theatreService.requireApproved(currentUser.get()).getId()); }

    @PostMapping("/api/theatre/offers")
    @ResponseStatus(HttpStatus.CREATED)
    public OfferView theatreCreate(@RequestBody OfferRequest r) { return offers.create(currentUser.get(), theatreService.requireApproved(currentUser.get()), r); }

    @PutMapping("/api/theatre/offers/{id}/status")
    public OfferView theatreStatus(@PathVariable Long id, @RequestParam String status) { return offers.setStatus(currentUser.get(), theatreService.requireApproved(currentUser.get()), id, status); }

    // ------------------------------------------------------------ reviews
    public record ReviewRequest(String reference, int rating, String comment) {}
    public record ReasonRequest(String reason) {}

    @PostMapping("/api/customer/reviews")
    @ResponseStatus(HttpStatus.CREATED)
    public ReviewView review(@RequestBody ReviewRequest r) { return reviews.create(currentUser.get(), r.reference(), r.rating(), r.comment()); }

    @GetMapping("/api/customer/reviews/mine")
    public List<String> reviewed() { return reviews.reviewedReferences(currentUser.get()); }

    @GetMapping("/api/theatre/reviews")
    public Map<String, Object> theatreReviews() { return reviews.forTheatre(myTheatre()); }

    @PostMapping("/api/theatre/reviews/{id}/report")
    public void reportReview(@PathVariable Long id, @RequestBody ReasonRequest r) { reviews.report(currentUser.get(), myTheatre(), id, r.reason()); }

    @GetMapping("/api/admin/reviews/ratings")
    public Map<String, Object> ratings() { return Map.of("thresholds", reviews.thresholds(), "theatres", reviews.ratings()); }

    @GetMapping("/api/admin/reviews")
    public List<ReviewView> evidence(@RequestParam(required = false) Long theatreId, @RequestParam(defaultValue = "false") boolean reportedOnly) { return reviews.evidence(theatreId, reportedOnly); }

    @PostMapping("/api/admin/reviews/{id}/hide")
    public void hide(@PathVariable Long id, @RequestBody ReasonRequest r) { reviews.moderate(currentUser.get(), id, true, r.reason()); }

    @PostMapping("/api/admin/reviews/{id}/restore")
    public void restore(@PathVariable Long id) { reviews.moderate(currentUser.get(), id, false, null); }

    // ------------------------------------------------------------ complaints
    public record RespondRequest(String status, String response) {}

    @PostMapping("/api/customer/complaints")
    @ResponseStatus(HttpStatus.CREATED)
    public ComplaintView customerRaise(@RequestBody ComplaintRequest r) { return complaints.raise(currentUser.get(), null, r); }

    @GetMapping("/api/customer/complaints")
    public List<ComplaintView> customerMine() { return complaints.mine(currentUser.get()); }

    @PostMapping("/api/theatre/complaints")
    @ResponseStatus(HttpStatus.CREATED)
    public ComplaintView theatreRaise(@RequestBody ComplaintRequest r) { return complaints.raise(currentUser.get(), myTheatre(), r); }

    @GetMapping("/api/theatre/complaints")
    public Map<String, Object> theatreComplaints() { return Map.of("inbox", complaints.inbox(currentUser.get(), myTheatre(), false), "mine", complaints.mine(currentUser.get())); }

    @PostMapping("/api/theatre/complaints/{id}/respond")
    public ComplaintView theatreRespond(@PathVariable Long id, @RequestBody RespondRequest r) { return complaints.respond(currentUser.get(), myTheatre(), id, r.status(), r.response()); }

    @GetMapping("/api/admin/complaints")
    public List<ComplaintView> adminComplaints(@RequestParam(defaultValue = "false") boolean includeTheatre) { return complaints.inbox(currentUser.get(), null, includeTheatre); }

    @PostMapping("/api/admin/complaints/{id}/respond")
    public ComplaintView adminRespond(@PathVariable Long id, @RequestBody RespondRequest r) { return complaints.respond(currentUser.get(), null, id, r.status(), r.response()); }

    // ------------------------------------------------------------ refunds
    public record RefundDone(String reference) {}

    @GetMapping("/api/admin/refunds")
    public List<RefundView> refundList(@RequestParam(defaultValue = "false") boolean pendingOnly) { return refunds.list(pendingOnly); }

    @PostMapping("/api/admin/refunds/{reference}/complete")
    public RefundView refundComplete(@PathVariable String reference, @RequestBody(required = false) RefundDone body) { return refunds.complete(currentUser.get(), reference, body == null ? null : body.reference()); }
}
