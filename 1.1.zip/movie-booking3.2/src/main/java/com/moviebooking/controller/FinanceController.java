package com.moviebooking.controller;

import com.moviebooking.enums.Role;
import com.moviebooking.security.CurrentUser;
import com.moviebooking.service.FinanceService;
import com.moviebooking.service.FinanceService.*;
import com.moviebooking.service.TheatreService;
import java.time.*;
import java.util.*;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

/**
 * Finance and analytics for both admin roles. URL prefixes are protected by SecurityConfig
 * (/api/admin = Super Admin, /api/theatre = Theatre Admin); a Theatre Admin's scope is ALWAYS overwritten with their own theatre.
 */
@RestController
@RequestMapping({"/api/admin/finance", "/api/theatre/finance"})
@RequiredArgsConstructor
public class FinanceController {
    private final FinanceService finance;
    private final TheatreService theatres;
    private final CurrentUser currentUser;

    private Scope scope(Long stateId, Long districtId, Long cityId, Long theatreId, LocalDate from, LocalDate to, LocalTime fromTime, LocalTime toTime, String basis) {
        Long forced = currentUser.get().getRole() == Role.THEATRE_ADMIN ? theatres.myTheatre(currentUser.get()).id() : null;
        if (forced != null) return new Scope(null, null, null, forced, from, to, fromTime, toTime, basis);
        return new Scope(stateId, districtId, cityId, theatreId, from, to, fromTime, toTime, basis);
    }

    @GetMapping("/summary")
    public Map<String, Object> summary(@RequestParam(required = false) Long stateId, @RequestParam(required = false) Long districtId, @RequestParam(required = false) Long cityId,
                                       @RequestParam(required = false) Long theatreId,
                                       @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from, @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to,
                                       @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.TIME) LocalTime fromTime,
                                       @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.TIME) LocalTime toTime,
                                       @RequestParam(defaultValue = "CREATED") String basis, @RequestParam(defaultValue = "false") boolean compare) {
        return finance.summary(scope(stateId, districtId, cityId, theatreId, from, to, fromTime, toTime, basis), compare);
    }

    @GetMapping("/records")
    public Page records(@RequestParam String metric, @RequestParam(required = false) Long stateId, @RequestParam(required = false) Long districtId, @RequestParam(required = false) Long cityId,
                        @RequestParam(required = false) Long theatreId,
                        @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from, @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to,
                        @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.TIME) LocalTime fromTime,
                        @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.TIME) LocalTime toTime,
                        @RequestParam(defaultValue = "CREATED") String basis, @RequestParam(required = false) String q,
                        @RequestParam(defaultValue = "createdAt") String sort, @RequestParam(defaultValue = "false") boolean asc,
                        @RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "25") int size) {
        return finance.records(scope(stateId, districtId, cityId, theatreId, from, to, fromTime, toTime, basis), metric, q, sort, asc, page, size);
    }

    @GetMapping("/breakdown")
    public List<Group> breakdown(@RequestParam(defaultValue = "auto") String by, @RequestParam(required = false) Long stateId, @RequestParam(required = false) Long districtId,
                                 @RequestParam(required = false) Long cityId, @RequestParam(required = false) Long theatreId,
                                 @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from, @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to,
                                 @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.TIME) LocalTime fromTime,
                                 @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.TIME) LocalTime toTime,
                                 @RequestParam(defaultValue = "CREATED") String basis) {
        return finance.breakdown(scope(stateId, districtId, cityId, theatreId, from, to, fromTime, toTime, basis), by);
    }
}
