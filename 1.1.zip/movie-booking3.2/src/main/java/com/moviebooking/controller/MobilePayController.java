package com.moviebooking.controller;

import com.moviebooking.dto.Dtos.BookingView;
import com.moviebooking.service.BookingService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/** TEST MODE ONLY: the page a phone opens after scanning the payment QR. The signed token in the link is the only credential. */
@RestController
@RequestMapping("/api/public/mockpay")
@RequiredArgsConstructor
public class MobilePayController {
    private final BookingService bookingService;

    @GetMapping("/{reference}")
    public BookingView info(@PathVariable String reference, @RequestParam("t") String token) { return bookingService.mobileInfo(reference, token); }

    @PostMapping("/{reference}/approve")
    public BookingView approve(@PathVariable String reference, @RequestParam("t") String token) { return bookingService.mobileApprove(reference, token); }
}
