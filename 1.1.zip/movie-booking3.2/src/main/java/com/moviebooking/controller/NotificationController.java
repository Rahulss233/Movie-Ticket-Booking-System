package com.moviebooking.controller;

import com.moviebooking.dto.Dtos.*;
import com.moviebooking.entity.*;
import com.moviebooking.enums.*;
import com.moviebooking.security.CurrentUser;
import com.moviebooking.service.*;
import jakarta.servlet.http.*;
import jakarta.validation.Valid;
import java.time.LocalDate;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/notifications")
@RequiredArgsConstructor
public class NotificationController {
    private final NotificationService notifications;
    private final CurrentUser currentUser;

    @GetMapping
    public List<NotificationView> list() { return notifications.list(currentUser.get()); }

    @GetMapping("/unread-count")
    public long unread() { return notifications.unread(currentUser.get()); }

    @PostMapping("/read")
    public void readAll() { notifications.markAllRead(currentUser.get()); }

    @PostMapping("/{id}/read")
    public void readOne(@PathVariable Long id) { notifications.markRead(currentUser.get(), id); }

    @DeleteMapping("/{id}")
    public void deleteOne(@PathVariable Long id) { notifications.delete(currentUser.get(), id); }

    @DeleteMapping("/read")
    public void clearRead() { notifications.clearRead(currentUser.get()); }
}
