package com.moviebooking.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

/** Local poster upload for the development project. Use object storage/CDN for production. */
@RestController
@RequestMapping
public class PosterUploadController {
    private static final long MAX_BYTES = 5L * 1024 * 1024;
    private static final Set<String> TYPES = Set.of("image/jpeg", "image/png", "image/webp");

    @PostMapping(value = {"/api/admin/poster-upload", "/api/theatre/poster-upload"}, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Map<String, String> upload(@RequestPart("file") MultipartFile file) {
        if (file.isEmpty() || file.getSize() > MAX_BYTES)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Choose an image up to 5 MB");
        if (!TYPES.contains(file.getContentType()))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Only JPG, PNG or WebP images are supported");
        String ext = switch (file.getContentType()) { case "image/jpeg" -> ".jpg"; case "image/png" -> ".png"; default -> ".webp"; };
        try {
            Path dir = Path.of("uploads", "posters").toAbsolutePath().normalize();
            Files.createDirectories(dir);
            String name = UUID.randomUUID() + ext;
            file.transferTo(dir.resolve(name));
            return Map.of("url", "/uploads/posters/" + name);
        } catch (IOException ex) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Could not save poster image");
        }
    }
}
