package com.moviebooking.controller;

import com.moviebooking.dto.Dtos.*;
import com.moviebooking.entity.*;
import com.moviebooking.enums.*;
import com.moviebooking.security.CurrentUser;
import com.moviebooking.service.*;
import jakarta.servlet.http.*;
import jakarta.validation.Valid;
import java.time.LocalDate;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/public")
@RequiredArgsConstructor
public class PublicController {
    private final CatalogService catalog;

    @GetMapping("/locations/search")
    public List<LocationView> searchLocations(@RequestParam String q) {
        return catalog.searchLocations(q);
    }

    @GetMapping("/locations")
    public List<LocationView> locations(@RequestParam(required = false) Long parentId) {
        return catalog.locations(null, parentId);
    }

    @GetMapping("/movies")
    public List<Movie> movies(@RequestParam(required = false) MovieStatus status, @RequestParam(required = false) String language,
                              @RequestParam(required = false) String genre, @RequestParam(required = false) String q,
                              @RequestParam(required = false) Long locationId) {
        return catalog.movies(status, language, genre, q, locationId);
    }

    @GetMapping("/movies/{id}")
    public Movie movie(@PathVariable Long id) {
        return catalog.movie(id);
    }

    @GetMapping("/movies/{id}/shows")
    public List<ShowView> shows(@PathVariable Long id, @RequestParam Long cityId,
                                @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return catalog.showsFor(id, cityId, date);
    }

    @GetMapping("/movies/available")
    public List<CatalogService.MovieAvailability> availableMovies(@RequestParam(required = false) Long cityId, @RequestParam(required = false) Long districtId,
                                                                  @RequestParam(required = false) Long stateId) {
        return catalog.availableMovies(cityId, districtId, stateId);
    }

    @GetMapping("/movies/{id}/listing")
    public List<CatalogService.TheatreListing> listing(@PathVariable Long id, @RequestParam Long cityId,
                                                       @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return catalog.listing(id, cityId, date);
    }

    /** The real dates a customer can book for this movie (slides forward daily). locationId may be a city, district or state. */
    @GetMapping("/movies/{id}/booking-dates")
    public List<LocalDate> bookingDates(@PathVariable Long id, @RequestParam(required = false) Long locationId) {
        return catalog.bookingDates(id, locationId);
    }

    @GetMapping("/shows/{id}/seats")
    public SeatMap seats(@PathVariable Long id) {
        return catalog.seatMap(id);
    }
}
