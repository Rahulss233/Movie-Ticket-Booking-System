package com.moviebooking.controller;

import com.moviebooking.dto.Dtos.*;
import com.moviebooking.entity.*;
import com.moviebooking.enums.*;
import com.moviebooking.security.CurrentUser;
import com.moviebooking.service.*;
import jakarta.servlet.http.*;
import jakarta.validation.Valid;
import java.time.LocalDate;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/theatre")
@RequiredArgsConstructor
public class TheatreAdminController {
    private final TheatreService theatreService;
    private final ShowService showService;
    private final CurrentUser currentUser;
    private final BookingService bookingService;
    private final AdminService adminService;

    @GetMapping("/me")
    public TheatreView me() { return theatreService.myTheatre(currentUser.get()); }

    @GetMapping("/history")
    public List<HistoryView> history() { return theatreService.myHistory(currentUser.get()); }

    @PutMapping("/me")
    public TheatreView update(@Valid @RequestBody TheatreDetails d) { return theatreService.update(currentUser.get(), d); }

    @GetMapping("/screens")
    public List<ScreenView> screens() { return theatreService.myScreens(currentUser.get()); }

    @PostMapping("/screens")
    @ResponseStatus(HttpStatus.CREATED)
    public ScreenView addScreen(@Valid @RequestBody ScreenRequest r) { return theatreService.addScreen(currentUser.get(), r); }

    @PutMapping("/screens/{id}")
    public ScreenView updateScreen(@PathVariable Long id, @Valid @RequestBody ScreenUpdateRequest r) { return theatreService.updateScreen(currentUser.get(), id, r); }

    /** Theatres add a film they want to screen straight into the shared catalogue: no approval step. */
    @PostMapping("/movies")
    @ResponseStatus(HttpStatus.CREATED)
    public Movie addMovie(@Valid @RequestBody MovieRequest request) {
        return adminService.addMovieByTheatre(request, currentUser.get().getEmail());
    }

    @PutMapping("/movies/{id}")
    public Movie editMovie(@PathVariable Long id, @Valid @RequestBody MovieRequest request) {
        return adminService.editMovieByTheatre(id, request, currentUser.get().getEmail());
    }

    @GetMapping("/shows")
    public List<ShowView> shows() { return showService.list(currentUser.get()); }

    @PostMapping("/shows")
    @ResponseStatus(HttpStatus.CREATED)
    public ShowView createShow(@Valid @RequestBody ShowRequest r) { return showService.create(currentUser.get(), r); }

    @PostMapping("/shows/{id}/cancel")
    public void cancelShow(@PathVariable Long id, @Valid @RequestBody ShowCancelRequest r) { showService.cancel(currentUser.get(), id, r.reason()); }

    @GetMapping("/bookings")
    public List<BookingView> bookings() { return theatreService.myBookings(currentUser.get()); }

    @PostMapping("/tickets/validate")
    public TicketValidationView validateTicket(@Valid @RequestBody TicketValidationRequest request) {
        return bookingService.validateTicket(currentUser.get(), request.token().trim());
    }
}
