package com.moviebooking.controller;

import com.moviebooking.dto.Dtos.*;
import com.moviebooking.security.CurrentUser;
import com.moviebooking.service.*;
import com.moviebooking.service.ListingService.*;
import com.moviebooking.service.ShowService.BulkResult;
import jakarta.validation.Valid;
import java.util.Map;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

/** Theatre admin tools: seating designer, show timings, movie runs (with history) and theatre specifications. Role is enforced by the /api/theatre prefix. */
@RestController
@RequestMapping("/api/theatre")
@RequiredArgsConstructor
public class TheatreStudioController {
    private final TheatreService theatres;
    private final ShowService shows;
    private final ListingService listings;
    private final CurrentUser currentUser;

    public record RemoveRequest(String reason) {}

    // ---- seating designer
    @PostMapping("/screens/designer")
    @ResponseStatus(HttpStatus.CREATED)
    public ScreenView createScreen(@Valid @RequestBody LayoutRequest r) { return theatres.saveLayout(currentUser.get(), null, r); }

    @PutMapping("/screens/{id}/designer")
    public ScreenView updateScreenLayout(@PathVariable Long id, @Valid @RequestBody LayoutRequest r) { return theatres.saveLayout(currentUser.get(), id, r); }

    @GetMapping("/screens/{id}/designer")
    public Map<String, Object> layout(@PathVariable Long id) { return theatres.layoutOf(currentUser.get(), id); }

    // ---- shows
    @PostMapping("/shows/bulk")
    @ResponseStatus(HttpStatus.CREATED)
    public BulkResult bulk(@Valid @RequestBody BulkShowRequest r) { return shows.createMany(currentUser.get(), r); }

    @PostMapping("/shows/{id}/seats/block")
    public Map<String, Object> blockSeats(@PathVariable Long id, @RequestBody ShowService.BlockRequest r) { return Map.of("changed", shows.blockSeats(currentUser.get(), id, r)); }

    @PutMapping("/shows/{id}")
    public ShowView updateShow(@PathVariable Long id, @Valid @RequestBody ShowUpdateRequest r) { return shows.update(currentUser.get(), id, r); }

    @GetMapping("/screen-history")
    public List<ShowService.ScreeningRun> screenHistory() { return shows.screenHistory(currentUser.get()); }

    // ---- movie runs + history
    @GetMapping("/listings")
    public List<ListingView> listings(@RequestParam(defaultValue = "false") boolean history) { return listings.list(currentUser.get(), history); }

    @PostMapping("/listings")
    @ResponseStatus(HttpStatus.CREATED)
    public ListingView addListing(@RequestBody ListingRequest r) { return listings.add(currentUser.get(), r); }

    @PutMapping("/listings/{id}")
    public ListingView updateListing(@PathVariable Long id, @RequestBody ListingUpdate r) { return listings.update(currentUser.get(), id, r); }

    @PostMapping("/listings/{id}/remove")
    public ListingView removeListing(@PathVariable Long id, @RequestBody RemoveRequest r) { return listings.remove(currentUser.get(), id, r.reason()); }

    // ---- specifications
    @GetMapping("/specs")
    public Map<String, Object> specs() { return theatres.specsOf(currentUser.get()); }

    @PutMapping("/booking-window")
    public Map<String, Object> bookingWindow(@Valid @RequestBody BookingWindowRequest r) { return Map.of("bookingWindowDays", theatres.setBookingWindow(currentUser.get(), r.days())); }

    @PutMapping("/specs")
    public void saveSpecs(@Valid @RequestBody SpecsRequest r) { theatres.updateSpecs(currentUser.get(), r); }
}
