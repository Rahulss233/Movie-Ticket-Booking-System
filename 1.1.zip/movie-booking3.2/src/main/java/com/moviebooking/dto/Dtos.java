package com.moviebooking.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/** All request/response DTOs (Java records: immutable, validated at the API boundary). */
public final class Dtos {
    private Dtos() {}

    // ------------------------------ requests ------------------------------
    public record LoginRequest(@NotBlank @Email String email, @NotBlank String password) {}

    public record RegisterRequest(
            @NotBlank @Size(max = 100) String name,
            @NotBlank @Email @Size(max = 150) String email,
            @NotBlank @Pattern(regexp = "^\\+?[0-9]{10,13}$", message = "Phone must be 10-13 digits") String phone,
            @NotBlank @Pattern(regexp = "^(?=.*[A-Za-z])(?=.*\\d).{8,64}$",
                    message = "Password must be 8-64 characters with a letter and a digit") String password,
            @Size(max = 300) String address) {
        public RegisterRequest(String name, String email, String phone, String password) { this(name, email, phone, password, null); }
    }

    public record ProfileUpdate(
            @NotBlank @Size(max = 100) String name,
            @NotBlank @Pattern(regexp = "^\\+?[0-9]{10,13}$", message = "Phone must be 10-13 digits") String phone,
            @NotBlank @Size(max = 300) String address) {}

    public record TheatreDetails(
            @NotBlank @Size(max = 150) String theatreName,
            @NotBlank @Size(max = 500) String address,
            @NotNull Long cityId,
            @Size(max = 255) String managerName,
            @NotBlank @Pattern(regexp = "^\\+?[0-9]{10,13}$", message = "Contact phone must be 10-13 digits") String contactPhone,
            @NotBlank @Size(max = 60) String licenseNumber,
            @NotNull @Future LocalDate licenseExpiry,
            @NotBlank String bankAccountHolder,
            @NotBlank @Pattern(regexp = "^[0-9]{9,18}$", message = "Bank account must be 9-18 digits") String bankAccountNumber,
            @NotBlank @Pattern(regexp = "^[A-Z]{4}0[A-Z0-9]{6}$", message = "Invalid IFSC code") String bankIfsc,
            @Size(max = 500) String facilities) {}

    public record TheatreRegistrationRequest(@Valid @NotNull RegisterRequest owner, @Valid @NotNull TheatreDetails theatre) {}

    public record ScreenUpdateRequest(@NotBlank @Size(max = 60) String name, @Min(1) @Max(26) Integer rows,
            @Min(1) @Max(40) Integer seatsPerRow, @Min(0) Integer premiumRows) {}

    public record ShowCancelRequest(@NotBlank @Size(min = 5, max = 300) String reason) {}

    public record ScreenRequest(
            @NotBlank @Size(max = 60) String name,
            @Min(1) @Max(26) int rows,
            @Min(1) @Max(40) int seatsPerRow,
            @Min(0) int premiumRows) {}

    public record ShowRequest(
            @NotNull Long movieId, @NotNull Long screenId, @NotNull LocalDateTime startTime,
            @DecimalMin("1.00") BigDecimal regularPrice, @DecimalMin("1.00") BigDecimal premiumPrice,
            java.util.Map<String, BigDecimal> sectionPrices,
            @Size(max = 40) String audioLanguage, @Size(max = 10) String dimension, @Size(max = 120) String specialFormats) {
        public ShowRequest(Long movieId, Long screenId, LocalDateTime startTime, BigDecimal regularPrice, BigDecimal premiumPrice) {
            this(movieId, screenId, startTime, regularPrice, premiumPrice, null, null, null, null);
        }
    }

    public record BulkShowRequest(@NotNull Long movieId, @NotNull Long screenId, @NotNull LocalDate fromDate, @NotNull LocalDate toDate,
            @NotEmpty List<@NotBlank String> times, @DecimalMin("1.00") BigDecimal regularPrice, @DecimalMin("1.00") BigDecimal premiumPrice,
            java.util.Map<String, BigDecimal> sectionPrices,
            @Size(max = 40) String audioLanguage, @Size(max = 10) String dimension, @Size(max = 120) String specialFormats) {}

    public record ShowUpdateRequest(Long movieId, Long screenId, LocalDateTime startTime, java.util.Map<String, BigDecimal> sectionPrices,
            @Size(max = 40) String audioLanguage, @Size(max = 10) String dimension, @Size(max = 120) String specialFormats) {}

    public record RowDef(@Size(max = 8) String label, @Size(max = 40) String section, @Size(max = 300) String pattern) {}

    public record LayoutRequest(@NotBlank @Size(max = 60) String name, @Size(max = 120) String specialFormats, @NotEmpty List<RowDef> rows) {}

    public record BookingWindowRequest(@Min(4) @Max(7) int days) {}

    public record SpecsRequest(@Size(max = 300) String facilities, Boolean cancellationAvailable) {}

    public record MovieRequest(
            @NotBlank @Size(max = 200) String title,
            @Size(max = 2000) String description,
            @Size(max = 500) String posterUrl, @Size(max = 500) String trailerUrl,
            @NotBlank String genre, @NotBlank String language,
            @Min(1) @Max(600) int durationMinutes,
            @Size(max = 10) String certification, @Size(max = 500) String castInfo,
            LocalDate releaseDate,
            @NotBlank @Pattern(regexp = "PENDING_REVIEW|UPCOMING|ACTIVE|ARCHIVED") String status) {}

    public record LocationRequest(@NotBlank @Size(max = 100) String name,
                                  @NotBlank @Pattern(regexp = "STATE|DISTRICT|CITY") String type, Long parentId) {}

    public record HoldRequest(@NotNull Long showId, @NotEmpty List<@NotNull Long> seatIds, @Size(max = 40) String couponCode) {
        public HoldRequest(Long showId, List<Long> seatIds) { this(showId, seatIds, null); }
    }

    public record PayRequest(@NotBlank @Size(min = 8, max = 64) String idempotencyKey, boolean simulateFailure) {}

    public record StatusActionRequest(@NotBlank String action, @Size(max = 500) String reason) {}

    public record CommissionRequest(@DecimalMin("0.00") @DecimalMax("100.00") BigDecimal percent) {}

    public record ActiveRequest(boolean active) {}

    public record TicketValidationRequest(@NotBlank @Size(max = 64) String token) {}

    public record TicketValidationView(boolean valid, String status, String reference, String movieTitle,
                                       String theatreName, String screenName, LocalDateTime showTime,
                                       String seats, LocalDateTime checkedInAt, String message) {}

    public record AuditView(String actorEmail, String action, String details, LocalDateTime at) {}

    // ------------------------------ responses ------------------------------
    public record UserView(Long id, String name, String email, String phone, String address, String role, boolean active) {}

    public record LocationView(Long id, String name, String type, Long parentId) {}

    public record TheatreView(Long id, String name, String address, String city, String district, String state,
                              String ownerName, String ownerEmail, String contactPhone, String licenseNumber,
                              LocalDate licenseExpiry, String facilities, String status, String statusReason,
                              BigDecimal theatreCommission, BigDecimal effectiveCommission, int screenCount,
                              int totalSeats, List<String> allowedActions, LocalDateTime registeredAt) {}

    public record ScreenView(Long id, String name, int totalSeats, boolean active,
                             BigDecimal screenCommission, BigDecimal effectiveCommission) {}

    public record ShowView(Long id, Long movieId, String movieTitle, Long theatreId, String theatreName,
                           String screenName, LocalDateTime startTime, LocalDateTime endTime,
                           BigDecimal regularPrice, BigDecimal premiumPrice, String status, long availableSeats,
                           String audioLanguage, String dimension, String specialFormats, long totalSeats, long bookedSeats) {}

    public record SeatView(Long seatId, String rowLabel, int number, String label, String category,
                           String state, BigDecimal price, String section, int gridRow, int gridCol) {}

    public record SeatMap(ShowView show, List<SeatView> seats) {}

    public record BookingView(String reference, String status, String paymentStatus, String movieTitle,
                              String theatreName, String screenName, LocalDateTime showTime, String seats,
                              BigDecimal totalAmount, LocalDateTime holdExpiresAt, BigDecimal refundAmount,
                              String refundStatus, String customerName, Long customerId, String message) {}

    public record NotificationView(Long id, String message, boolean seen, LocalDateTime createdAt, String category) {}

    public record PaymentLedgerView(Long id, String bookingReference, String transactionRef, String gatewayRef,
                                    BigDecimal amount, String status, String mode, String message, LocalDateTime createdAt) {}

    public record DashboardView(long theatresTotal, long theatresPending, long theatresApproved,
                                long theatresSuspended, long theatresDeactivated, long customers, long movies,
                                long confirmedBookings, long cancelledBookings, BigDecimal grossTicketSales,
                                BigDecimal collectedPayments, BigDecimal refundsIssued, BigDecimal commissionIncome,
                                BigDecimal theatrePayables, long failedPayments, List<String> recentActivity) {}

    public record HistoryView(String from, String to, String reason, String actor, LocalDateTime at) {}
}
