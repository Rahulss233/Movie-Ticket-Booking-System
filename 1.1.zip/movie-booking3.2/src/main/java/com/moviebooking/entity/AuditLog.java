package com.moviebooking.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "audit_logs")
@Getter
@Setter
public class AuditLog extends BaseEntity {
    @Column(nullable = false)
    private String actorEmail;
    @Column(nullable = false, length = 80)
    private String action;
    @Column(length = 1000)
    private String details;
}
