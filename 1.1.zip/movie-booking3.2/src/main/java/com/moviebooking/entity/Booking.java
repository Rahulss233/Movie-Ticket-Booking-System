package com.moviebooking.entity;

import com.moviebooking.enums.BookingStatus;
import com.moviebooking.enums.PaymentStatus;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "bookings", indexes = {
        @Index(name = "idx_booking_customer", columnList = "customer_id"),
        @Index(name = "idx_booking_status_hold", columnList = "status,holdExpiresAt")})
@Getter
@Setter
public class Booking extends BaseEntity {
    @Column(nullable = false, unique = true, length = 20)
    private String reference;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private User customer;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Show show;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private BookingStatus status = BookingStatus.PENDING_PAYMENT;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private PaymentStatus paymentStatus = PaymentStatus.PENDING;
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal totalAmount;
    /** Snapshot kept for history even after seats are released. */
    @Column(length = 300)
    private String seatLabels;
    private LocalDateTime holdExpiresAt;

    /** Opaque, unique ticket token. The QR contains only this token, never customer/payment details. */
    @Column(unique = true, length = 64)
    private String ticketToken;

    private LocalDateTime checkedInAt;

    // ---- Financial snapshot, frozen at payment time; later rate changes never touch it ----
    @Column(precision = 5, scale = 2)
    private BigDecimal commissionRate;
    @Column(precision = 10, scale = 2)
    private BigDecimal commissionBasis;
    @Column(precision = 10, scale = 2)
    private BigDecimal commissionAmount;
    @Column(precision = 10, scale = 2)
    private BigDecimal theatrePayable;

    // ---- Cancellation / refund ----
    private LocalDateTime cancelledAt;
    @Column(precision = 10, scale = 2)
    private BigDecimal refundAmount;
    @Column(length = 20)
    private String refundStatus;
    private LocalDateTime refundCompletedAt;
    @Column(length = 60) private String refundReference;
    @Column(length = 40) private String offerCode;
    @Column(precision = 10, scale = 2) private BigDecimal discountAmount;
}
