package com.moviebooking.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

/**
 * type PLATFORM: customer -> website (handled by Super Admin)
 * type THEATRE:  customer -> a theatre (handled by that theatre's admin; Super Admin can also act)
 * type ADMIN:    theatre admin -> Super Admin
 */
@Entity
@Table(name = "complaints", indexes = @Index(name = "idx_complaint_status", columnList = "status,type"))
@Getter
@Setter
public class Complaint extends BaseEntity {
    @ManyToOne(fetch = FetchType.LAZY, optional = false) private User createdBy;
    @Column(nullable = false, length = 20) private String raisedAsRole;
    @Column(nullable = false, length = 10) private String type;
    @ManyToOne(fetch = FetchType.LAZY) private Theatre theatre;
    @Column(length = 30) private String bookingReference;
    @Column(nullable = false, length = 150) private String subject;
    @Column(nullable = false, length = 2000) private String message;
    @Column(nullable = false, length = 20) private String status = "OPEN";      // OPEN, IN_PROGRESS, RESOLVED, CLOSED
    @Column(length = 2000) private String response;
    @Column(length = 150) private String respondedBy;
    private LocalDateTime respondedAt;
}
