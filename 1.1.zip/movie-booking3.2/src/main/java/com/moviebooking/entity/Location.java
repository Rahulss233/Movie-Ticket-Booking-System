package com.moviebooking.entity;

import com.moviebooking.enums.LocationType;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

/** State -> District -> City hierarchy stored in one self-referencing table. */
@Entity
@Table(name = "locations", uniqueConstraints = @UniqueConstraint(columnNames = {"name", "parent_id"}))
@Getter
@Setter
public class Location extends BaseEntity {
    @Column(nullable = false, length = 100)
    private String name;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 15)
    private LocationType type;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "parent_id")
    private Location parent;
}
