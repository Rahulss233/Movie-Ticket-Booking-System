package com.moviebooking.entity;

import com.moviebooking.enums.MovieStatus;
import jakarta.persistence.*;
import java.time.LocalDate;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "movies", indexes = @Index(name = "idx_movie_status", columnList = "status"), uniqueConstraints = @UniqueConstraint(name = "uk_movie_external_source_id", columnNames = {"externalSource", "externalId"}))
@Getter
@Setter
public class Movie extends BaseEntity {
    @Column(nullable = false, length = 200)
    private String title;
    @Column(length = 2000)
    private String description;
    @Column(length = 500)
    private String posterUrl;
    @Column(length = 500)
    private String trailerUrl;
    @Column(nullable = false, length = 100)
    private String genre;
    @Column(nullable = false, length = 50)
    private String language;
    @Column(nullable = false)
    private int durationMinutes;
    @Column(length = 10)
    private String certification;
    @Column(length = 500)
    private String castInfo;
    private LocalDate releaseDate;
    /** External metadata identity used to prevent duplicate imports; nullable for manually entered records. */
    @Column(length = 30) private String externalSource;
    @Column(length = 80) private String externalId;
    /** Email of the theatre admin who proposed this movie (null for Super Admin / imported records). */
    @Column(length = 150) private String proposedByEmail;
    /** Why a record is in the review queue, or how it was approved (shown to the Super Admin). */
    @Column(length = 500) private String reviewNote;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private MovieStatus status = MovieStatus.UPCOMING;
}
