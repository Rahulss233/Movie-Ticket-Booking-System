package com.moviebooking.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

/** One execution of one metadata provider: what it fetched and what happened to each record. */
@Entity
@Table(name = "movie_import_runs", indexes = @Index(name = "idx_import_provider_started", columnList = "provider,startedAt"))
@Getter
@Setter
public class MovieImportRun extends BaseEntity {
    @Column(nullable = false, length = 40) private String provider;
    @Column(nullable = false, length = 20) private String triggerType; // SCHEDULED, MANUAL, RETRY
    private LocalDateTime startedAt;
    private LocalDateTime finishedAt;
    private boolean success;
    private int fetched;
    private int created;
    private int updated;
    private int duplicates;
    private int autoPublished;
    private int sentToReview;
    private int failed;
    @Column(length = 500) private String errorMessage;
}
