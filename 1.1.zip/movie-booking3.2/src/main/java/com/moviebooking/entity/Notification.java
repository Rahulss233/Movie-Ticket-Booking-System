package com.moviebooking.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

/** In-app notification only. No email/SMS is sent or claimed. */
@Entity
@Table(name = "notifications", indexes = @Index(name = "idx_notif_user", columnList = "user_id,seen"))
@Getter
@Setter
public class Notification extends BaseEntity {
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private User user;
    @Column(nullable = false, length = 500)
    private String message;
    @Column(nullable = false)
    private boolean seen = false;
}
