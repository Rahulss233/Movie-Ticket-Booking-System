package com.moviebooking.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

/** A coupon. theatre == null means platform-wide (created by Super Admin); otherwise valid only for that theatre. */
@Entity
@Table(name = "offers", uniqueConstraints = @UniqueConstraint(name = "uk_offer_code", columnNames = "code"))
@Getter
@Setter
public class Offer extends BaseEntity {
    @Column(nullable = false, length = 40) private String code;
    @Column(nullable = false, length = 120) private String title;
    @Column(length = 500) private String description;
    @Column(nullable = false, length = 10) private String discountType;      // PERCENT or FLAT
    @Column(nullable = false, precision = 10, scale = 2) private BigDecimal discountValue;
    @Column(nullable = false, precision = 10, scale = 2) private BigDecimal minAmount = BigDecimal.ZERO;
    @Column(precision = 10, scale = 2) private BigDecimal maxDiscount;
    @Column(nullable = false) private LocalDateTime startsAt;
    @Column(nullable = false) private LocalDateTime endsAt;
    private Integer totalLimit;
    @Column(nullable = false) private int perUserLimit = 1;
    @Column(nullable = false, length = 10) private String status = "ACTIVE"; // ACTIVE or PAUSED
    @ManyToOne(fetch = FetchType.LAZY) private Theatre theatre;
    @ManyToOne(fetch = FetchType.LAZY) private Movie movie;
    @ManyToOne(fetch = FetchType.LAZY) private User createdBy;
}
