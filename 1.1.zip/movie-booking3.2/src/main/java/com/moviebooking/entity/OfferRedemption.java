package com.moviebooking.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "offer_redemptions", uniqueConstraints = @UniqueConstraint(name = "uk_redemption_booking", columnNames = "booking_id"))
@Getter
@Setter
public class OfferRedemption extends BaseEntity {
    @ManyToOne(fetch = FetchType.LAZY, optional = false) private Offer offer;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) private Booking booking;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) private User customer;
    @Column(nullable = false, precision = 10, scale = 2) private BigDecimal discount;
}
