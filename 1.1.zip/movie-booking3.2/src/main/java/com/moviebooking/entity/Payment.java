package com.moviebooking.entity;

import com.moviebooking.enums.PaymentStatus;
import jakarta.persistence.*;
import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "payments")
@Getter
@Setter
public class Payment extends BaseEntity {
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Booking booking;
    /** Client-supplied idempotency key; UNIQUE so a duplicate callback cannot charge twice. */
    @Column(nullable = false, unique = true, length = 64)
    private String transactionRef;
    private String gatewayRef;
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal amount;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private PaymentStatus status;
    @Column(nullable = false, length = 20)
    private String mode;
    private String message;
}
