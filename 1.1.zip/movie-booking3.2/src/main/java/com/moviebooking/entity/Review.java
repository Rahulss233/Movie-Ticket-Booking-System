package com.moviebooking.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

/** One verified review per confirmed booking, written only after the show has ended. */
@Entity
@Table(name = "reviews", uniqueConstraints = @UniqueConstraint(name = "uk_review_booking", columnNames = "booking_id"),
        indexes = @Index(name = "idx_review_theatre", columnList = "theatre_id,createdAt"))
@Getter
@Setter
public class Review extends BaseEntity {
    @OneToOne(fetch = FetchType.LAZY, optional = false) private Booking booking;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) private User customer;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) private Theatre theatre;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) private Movie movie;
    @Column(nullable = false) private int rating;
    @Column(length = 1000) private String comment;
    @Column(nullable = false, length = 10) private String status = "VISIBLE";   // VISIBLE or HIDDEN
    @Column(length = 300) private String hiddenReason;
    private boolean reported;
    @Column(length = 300) private String reportReason;
}
