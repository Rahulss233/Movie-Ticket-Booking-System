package com.moviebooking.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "screens", uniqueConstraints = @UniqueConstraint(columnNames = {"theatre_id", "name"}))
@Getter
@Setter
public class Screen extends BaseEntity {
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Theatre theatre;
    @Column(nullable = false, length = 60)
    private String name;
    @Column(nullable = false)
    private int totalSeats;
    @Column(nullable = false)
    private boolean active = true;
    /** Screen-level override; null means "inherit theatre/platform rate". */
    @Column(precision = 5, scale = 2)
    private BigDecimal commissionPercent;
    /** The rows exactly as the theatre designed them (JSON), so the designer can reopen them. */
    @Column(columnDefinition = "TEXT") private String layoutJson;
    /** Default special formats of this screen, e.g. "Dolby Atmos, 4K, Laser". */
    @Column(length = 120) private String specialFormats;
}
