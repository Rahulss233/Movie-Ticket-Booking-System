package com.moviebooking.entity;

import com.moviebooking.enums.SeatCategory;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "seats", uniqueConstraints = @UniqueConstraint(columnNames = {"screen_id", "rowLabel", "seatNumber"}))
@Getter
@Setter
public class Seat extends BaseEntity {
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Screen screen;
    @Column(nullable = false, length = 3)
    private String rowLabel;
    @Column(nullable = false)
    private int seatNumber;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private SeatCategory category;
    @Column(nullable = false)
    private boolean active = true;
    /** Pricing section such as "FIRST CLASS" or "BOX A"; null for seats created before the layout designer existed. */
    @Column(length = 40) private String section;
    /** Position on the drawing grid (row index and column index, gaps included). */
    private Integer gridRow;
    private Integer gridCol;

    public String label() {
        return rowLabel + seatNumber;
    }
}
