package com.moviebooking.entity;

import com.moviebooking.enums.ShowStatus;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "shows", indexes = {
        @Index(name = "idx_show_screen_time", columnList = "screen_id,startTime,endTime"),
        @Index(name = "idx_show_movie_time", columnList = "movie_id,startTime")})
@Getter
@Setter
public class Show extends BaseEntity {
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Movie movie;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Screen screen;
    @Column(nullable = false)
    private LocalDateTime startTime;
    /** Includes the cleaning buffer, so a plain overlap check protects the screen. */
    @Column(nullable = false)
    private LocalDateTime endTime;
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal regularPrice;
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal premiumPrice;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 12)
    private ShowStatus status = ShowStatus.SCHEDULED;
    @Column(length = 300) private String cancelReason;
    @Column(length = 40) private String audioLanguage;
    @Column(length = 10) private String dimension;          // 2D / 3D
    @Column(length = 120) private String specialFormats;    // comma separated: Dolby Atmos, 4K, Laser, IMAX...
}
