package com.moviebooking.entity;

import com.moviebooking.enums.SeatState;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

/** Per-show seat inventory: this is what makes availability independent for every show. */
@Entity
@Table(name = "show_seats",
        uniqueConstraints = @UniqueConstraint(columnNames = {"show_id", "seat_id"}),
        indexes = @Index(name = "idx_showseat_state", columnList = "show_id,state"))
@Getter
@Setter
public class ShowSeat extends BaseEntity {
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Show show;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Seat seat;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private SeatState state = SeatState.AVAILABLE;
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal price;
    private LocalDateTime lockedUntil;
    @ManyToOne(fetch = FetchType.LAZY)
    private Booking booking;
    @Version
    private long version;
}
