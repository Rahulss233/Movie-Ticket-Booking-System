package com.moviebooking.entity;

import com.moviebooking.enums.TheatreStatus;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "theatres", indexes = @Index(name = "idx_theatre_status", columnList = "status"))
@Getter
@Setter
public class Theatre extends BaseEntity {
    @Column(nullable = false, length = 150)
    private String name;
    @Column(nullable = false, length = 500)
    private String address;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Location city;
    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(unique = true)
    private User owner;
    private String managerName;
    @Column(nullable = false, length = 15)
    private String contactPhone;
    @Column(nullable = false, unique = true, length = 60)
    private String licenseNumber;
    private LocalDate licenseExpiry;
    private String bankAccountHolder;
    private String bankAccountNumber;
    private String bankIfsc;
    @Column(length = 500)
    private String facilities;
    /** null is treated as "cancellation available" so existing theatres keep today's behaviour. */
    private Boolean cancellationAvailable;

    /** How many days ahead customers may book (today included). 4 to 7; null means 7 so existing theatres keep today's behaviour. */
    private Integer bookingWindowDays;

    public int windowDays() { return bookingWindowDays == null ? 7 : Math.max(4, Math.min(7, bookingWindowDays)); }
    public boolean isCancellable() { return cancellationAvailable == null || cancellationAvailable; }
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 25)
    private TheatreStatus status = TheatreStatus.PENDING_VERIFICATION;
    @Column(length = 500)
    private String statusReason;
    /** Theatre-level default commission; null means "use platform default". */
    @Column(precision = 5, scale = 2)
    private BigDecimal commissionPercent;
}
