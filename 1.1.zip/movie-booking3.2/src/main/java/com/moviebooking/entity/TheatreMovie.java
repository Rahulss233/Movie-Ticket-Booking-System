package com.moviebooking.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

/** A movie a theatre has put on its screens for a date window. Rows are never deleted, so this table is the add/remove history. */
@Entity
@Table(name = "theatre_movies", indexes = @Index(name = "idx_theatre_movie", columnList = "theatre_id,movie_id"))
@Getter
@Setter
public class TheatreMovie extends BaseEntity {
    @ManyToOne(fetch = FetchType.LAZY, optional = false) private Theatre theatre;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) private Movie movie;
    @Column(nullable = false) private LocalDate startDate;
    @Column(nullable = false) private LocalDate endDate;
    @Column(length = 150) private String addedBy;
    private LocalDateTime removedAt;
    @Column(length = 150) private String removedBy;
    @Column(length = 300) private String removeReason;
}
