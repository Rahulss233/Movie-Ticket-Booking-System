package com.moviebooking.entity;

import com.moviebooking.enums.TheatreStatus;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "theatre_status_history")
@Getter
@Setter
public class TheatreStatusHistory extends BaseEntity {
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Theatre theatre;
    @Enumerated(EnumType.STRING)
    private TheatreStatus fromStatus;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TheatreStatus toStatus;
    @Column(length = 500)
    private String reason;
    @Column(nullable = false)
    private String actorEmail;
}
