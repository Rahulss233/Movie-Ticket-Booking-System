package com.moviebooking.enums;

public enum BookingStatus {
    PENDING_PAYMENT, CONFIRMED, CANCELLED, EXPIRED
}
