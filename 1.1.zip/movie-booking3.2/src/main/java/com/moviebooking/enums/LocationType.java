package com.moviebooking.enums;

public enum LocationType {
    STATE, DISTRICT, CITY
}
