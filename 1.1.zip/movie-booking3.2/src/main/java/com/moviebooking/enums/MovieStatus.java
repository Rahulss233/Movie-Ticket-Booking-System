package com.moviebooking.enums;

public enum MovieStatus {
    PENDING_REVIEW, UPCOMING, ACTIVE, ARCHIVED
}
