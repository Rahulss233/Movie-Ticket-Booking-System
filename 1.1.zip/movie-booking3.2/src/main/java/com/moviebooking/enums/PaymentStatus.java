package com.moviebooking.enums;

public enum PaymentStatus {
    PENDING, SUCCESS, FAILED, REFUND_PENDING, REFUNDED
}
