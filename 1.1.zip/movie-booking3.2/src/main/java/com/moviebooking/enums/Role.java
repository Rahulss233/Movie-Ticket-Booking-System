package com.moviebooking.enums;

public enum Role {
    CUSTOMER, THEATRE_ADMIN, SUPER_ADMIN
}
