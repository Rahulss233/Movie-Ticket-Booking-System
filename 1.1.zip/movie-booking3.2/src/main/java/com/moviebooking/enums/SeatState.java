package com.moviebooking.enums;

public enum SeatState {
    AVAILABLE, LOCKED, BOOKED
}
