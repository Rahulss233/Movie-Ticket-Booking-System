package com.moviebooking.enums;

public enum ShowStatus {
    SCHEDULED, CANCELLED
}
