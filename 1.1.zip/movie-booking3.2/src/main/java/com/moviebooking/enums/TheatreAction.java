package com.moviebooking.enums;

import static com.moviebooking.enums.TheatreStatus.*;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;

/** Encodes the theatre approval state machine: which action is legal from which status. */
public enum TheatreAction {
    START_REVIEW(UNDER_REVIEW, false, PENDING_VERIFICATION),
    APPROVE(APPROVED, false, PENDING_VERIFICATION, UNDER_REVIEW),
    REJECT(REJECTED, true, PENDING_VERIFICATION, UNDER_REVIEW),
    REQUEST_CHANGES(CHANGES_REQUIRED, true, PENDING_VERIFICATION, UNDER_REVIEW),
    SUSPEND(SUSPENDED, true, APPROVED),
    REACTIVATE(APPROVED, false, SUSPENDED),
    DEACTIVATE(DEACTIVATED, true, APPROVED, SUSPENDED);

    private final TheatreStatus target;
    private final boolean reasonRequired;
    private final Set<TheatreStatus> allowedFrom;

    TheatreAction(TheatreStatus target, boolean reasonRequired, TheatreStatus... from) {
        this.target = target;
        this.reasonRequired = reasonRequired;
        this.allowedFrom = EnumSet.copyOf(Arrays.asList(from));
    }

    public TheatreStatus getTarget() { return target; }
    public boolean isReasonRequired() { return reasonRequired; }
    public boolean canApplyTo(TheatreStatus status) { return allowedFrom.contains(status); }

    public static List<TheatreAction> availableFor(TheatreStatus status) {
        return Arrays.stream(values()).filter(a -> a.canApplyTo(status)).toList();
    }
}
