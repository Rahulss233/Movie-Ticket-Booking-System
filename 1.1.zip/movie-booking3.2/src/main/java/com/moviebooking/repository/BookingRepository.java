package com.moviebooking.repository;

import com.moviebooking.entity.*;
import com.moviebooking.enums.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

public interface BookingRepository extends JpaRepository<Booking, Long> {
    Optional<Booking> findByReference(String reference);
    Optional<Booking> findByTicketToken(String ticketToken);
    List<Booking> findByCustomerIdOrderByCreatedAtDesc(Long customerId);
    List<Booking> findByShow_Screen_Theatre_IdOrderByCreatedAtDesc(Long theatreId);
    List<Booking> findByShowIdAndStatusIn(Long showId, Collection<BookingStatus> statuses);
    List<Booking> findByStatusAndHoldExpiresAtBefore(BookingStatus status, LocalDateTime time);
    long countByStatus(BookingStatus status);
    long countByShowId(Long showId);

    @Query("select b from Booking b join fetch b.customer cu join fetch b.show s join fetch s.movie mv join fetch s.screen sc join fetch sc.theatre t "
            + "where (:theatreId is null or t.id = :theatreId) and (:screenId is null or sc.id = :screenId) and (:movieId is null or mv.id = :movieId) "
            + "and b.createdAt >= :from and b.createdAt < :to order by b.createdAt desc")
    List<Booking> searchBookings(@Param("theatreId") Long theatreId, @Param("screenId") Long screenId, @Param("movieId") Long movieId,
                                 @Param("from") LocalDateTime from, @Param("to") LocalDateTime to);

    @Query("select count(b) from Booking b where b.show.id = :showId and b.status in (com.moviebooking.enums.BookingStatus.PENDING_PAYMENT, com.moviebooking.enums.BookingStatus.CONFIRMED)")
    long countLiveByShow(@Param("showId") Long showId);

    @org.springframework.data.jpa.repository.Query("select b from Booking b join fetch b.customer join fetch b.show s join fetch s.movie join fetch s.screen sc join fetch sc.theatre where b.paymentStatus in :st order by b.cancelledAt desc")
    List<Booking> findByPaymentStatuses(@Param("st") java.util.Collection<com.moviebooking.enums.PaymentStatus> st);

    @org.springframework.data.jpa.repository.Query("select count(b) from Booking b where b.customer.id = :userId and b.show.screen.theatre.id = :theatreId")
    long countAtTheatre(@Param("userId") Long userId, @Param("theatreId") Long theatreId);

    String FIN_JOIN = "select b from Booking b join fetch b.customer cu join fetch b.show s join fetch s.movie mv join fetch s.screen sc "
            + "join fetch sc.theatre t join fetch t.city c left join fetch c.parent d left join fetch d.parent st "
            + "where (:theatreId is null or t.id = :theatreId) and (:cityId is null or c.id = :cityId) "
            + "and (:districtId is null or d.id = :districtId) and (:stateId is null or st.id = :stateId) ";

    @Query(FIN_JOIN + "and b.createdAt >= :from and b.createdAt < :to")
    List<Booking> financeByCreated(@Param("stateId") Long stateId, @Param("districtId") Long districtId, @Param("cityId") Long cityId,
                                   @Param("theatreId") Long theatreId, @Param("from") LocalDateTime from, @Param("to") LocalDateTime to);

    @Query(FIN_JOIN + "and s.startTime >= :from and s.startTime < :to")
    List<Booking> financeByShowTime(@Param("stateId") Long stateId, @Param("districtId") Long districtId, @Param("cityId") Long cityId,
                                    @Param("theatreId") Long theatreId, @Param("from") LocalDateTime from, @Param("to") LocalDateTime to);

    @Query("select coalesce(sum(b.totalAmount),0) from Booking b where b.status = com.moviebooking.enums.BookingStatus.CONFIRMED")
    BigDecimal sumConfirmedGross();
    @Query("select coalesce(sum(b.commissionAmount),0) from Booking b where b.commissionAmount is not null")
    BigDecimal sumCommission();
    @Query("select coalesce(sum(b.theatrePayable),0) from Booking b where b.theatrePayable is not null")
    BigDecimal sumTheatrePayable();
    @Query("select coalesce(sum(b.refundAmount),0) from Booking b where b.refundAmount is not null")
    BigDecimal sumRefunds();
}
