package com.moviebooking.repository;

import com.moviebooking.entity.Complaint;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ComplaintRepository extends JpaRepository<Complaint, Long> {
    @Query("select c from Complaint c join fetch c.createdBy left join fetch c.theatre where c.createdBy.id = :userId order by c.createdAt desc")
    List<Complaint> findMine(@Param("userId") Long userId);

    @Query("select c from Complaint c join fetch c.createdBy left join fetch c.theatre where c.type = 'THEATRE' and c.theatre.id = :theatreId order by c.createdAt desc")
    List<Complaint> findForTheatre(@Param("theatreId") Long theatreId);

    @Query("select c from Complaint c join fetch c.createdBy left join fetch c.theatre where c.type in :types order by c.createdAt desc")
    List<Complaint> findByTypes(@Param("types") List<String> types);

    long countByCreatedByIdAndStatusIn(Long userId, List<String> statuses);
}
