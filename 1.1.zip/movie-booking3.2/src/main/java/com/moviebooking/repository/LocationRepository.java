package com.moviebooking.repository;

import com.moviebooking.entity.*;
import com.moviebooking.enums.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

public interface LocationRepository extends JpaRepository<Location, Long> {
    List<Location> findByTypeAndParentIsNullOrderByName(LocationType type);
    List<Location> findByParentIdOrderByName(Long parentId);
    boolean existsByNameIgnoreCaseAndParent(String name, Location parent);
    List<Location> findTop30ByNameContainingIgnoreCaseOrderByName(String query);
}
