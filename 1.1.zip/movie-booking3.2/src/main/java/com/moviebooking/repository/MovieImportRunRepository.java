package com.moviebooking.repository;

import com.moviebooking.entity.MovieImportRun;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MovieImportRunRepository extends JpaRepository<MovieImportRun, Long> {
    List<MovieImportRun> findTop30ByOrderByStartedAtDesc();
    Optional<MovieImportRun> findFirstByProviderOrderByStartedAtDesc(String provider);
    Optional<MovieImportRun> findFirstByProviderAndSuccessTrueOrderByStartedAtDesc(String provider);
}
