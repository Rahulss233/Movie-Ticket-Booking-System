package com.moviebooking.repository;

import com.moviebooking.entity.*;
import com.moviebooking.enums.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

public interface MovieRepository extends JpaRepository<Movie, Long>, JpaSpecificationExecutor<Movie> {
    java.util.Optional<Movie> findByExternalSourceAndExternalId(String externalSource, String externalId);
    java.util.List<Movie> findByTitleIgnoreCaseAndLanguageIgnoreCase(String title, String language);
    java.util.List<Movie> findByProposedByEmailOrderByCreatedAtDesc(String email);
    java.util.List<Movie> findByStatusAndReleaseDateLessThanEqual(MovieStatus status, java.time.LocalDate date);
}
