package com.moviebooking.repository;

import com.moviebooking.entity.*;
import com.moviebooking.enums.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

public interface NotificationRepository extends JpaRepository<Notification, Long> {
    List<Notification> findTop50ByUserIdOrderByCreatedAtDesc(Long userId);
    long countByUserIdAndSeenFalse(Long userId);
    List<Notification> findByUserIdAndSeenFalse(Long userId);
    java.util.Optional<Notification> findByIdAndUserId(Long id, Long userId);
    List<Notification> findByUserIdAndSeenTrue(Long userId);
}
