package com.moviebooking.repository;

import com.moviebooking.entity.OfferRedemption;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface OfferRedemptionRepository extends JpaRepository<OfferRedemption, Long> {
    /** Redemptions that still count: the booking is awaiting payment or confirmed (expired / cancelled bookings free the coupon). */
    @Query("select count(r) from OfferRedemption r where r.offer.id = :offerId and r.booking.status in (com.moviebooking.enums.BookingStatus.PENDING_PAYMENT, com.moviebooking.enums.BookingStatus.CONFIRMED)")
    long countActive(@Param("offerId") Long offerId);

    @Query("select count(r) from OfferRedemption r where r.offer.id = :offerId and r.customer.id = :userId and r.booking.status in (com.moviebooking.enums.BookingStatus.PENDING_PAYMENT, com.moviebooking.enums.BookingStatus.CONFIRMED)")
    long countActiveForUser(@Param("offerId") Long offerId, @Param("userId") Long userId);
}
