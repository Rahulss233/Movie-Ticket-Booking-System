package com.moviebooking.repository;

import com.moviebooking.entity.Offer;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface OfferRepository extends JpaRepository<Offer, Long> {
    Optional<Offer> findByCodeIgnoreCase(String code);
    boolean existsByCodeIgnoreCase(String code);

    @Query("select o from Offer o left join fetch o.theatre left join fetch o.movie where o.status = 'ACTIVE' and o.startsAt <= :now and o.endsAt >= :now order by o.endsAt")
    List<Offer> findLive(@Param("now") LocalDateTime now);

    @Query("select o from Offer o left join fetch o.theatre left join fetch o.movie where (:theatreId is null or o.theatre.id = :theatreId) order by o.createdAt desc")
    List<Offer> findForManager(@Param("theatreId") Long theatreId);
}
