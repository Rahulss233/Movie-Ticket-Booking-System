package com.moviebooking.repository;

import com.moviebooking.entity.*;
import com.moviebooking.enums.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
    Optional<Payment> findByTransactionRef(String transactionRef);
    @Query("select coalesce(sum(p.amount),0) from Payment p where p.status = com.moviebooking.enums.PaymentStatus.SUCCESS")
    BigDecimal sumCollected();
    long countByStatus(PaymentStatus status);

    @Query("select p from Payment p join fetch p.booking b join fetch b.show s join fetch s.movie mv join fetch s.screen sc "
            + "join fetch sc.theatre t join fetch t.city c left join fetch c.parent d left join fetch d.parent st "
            + "where (:theatreId is null or t.id = :theatreId) and (:cityId is null or c.id = :cityId) "
            + "and (:districtId is null or d.id = :districtId) and (:stateId is null or st.id = :stateId) "
            + "and p.createdAt >= :from and p.createdAt < :to")
    List<Payment> financeByCreated(@Param("stateId") Long stateId, @Param("districtId") Long districtId, @Param("cityId") Long cityId,
                                   @Param("theatreId") Long theatreId, @Param("from") LocalDateTime from, @Param("to") LocalDateTime to);

    @Query("select p from Payment p join fetch p.booking b join fetch b.show s join fetch s.movie mv join fetch s.screen sc join fetch sc.theatre t "
            + "where b.customer.id = :customerId order by p.createdAt desc")
    List<Payment> forCustomer(@Param("customerId") Long customerId);
}
