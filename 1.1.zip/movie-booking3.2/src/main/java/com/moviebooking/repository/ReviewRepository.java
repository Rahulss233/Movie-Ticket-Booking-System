package com.moviebooking.repository;

import com.moviebooking.entity.Review;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ReviewRepository extends JpaRepository<Review, Long> {
    boolean existsByBookingId(Long bookingId);

    @Query("select r from Review r join fetch r.booking b join fetch r.customer join fetch r.movie join fetch r.theatre t join fetch b.show where r.customer.id = :userId")
    List<Review> findMine(@Param("userId") Long userId);

    @Query("select r from Review r join fetch r.booking b join fetch r.customer join fetch r.movie join fetch r.theatre t join fetch b.show "
            + "where (:theatreId is null or t.id = :theatreId) and (:reportedOnly = false or r.reported = true) and (:visibleOnly = false or r.status = 'VISIBLE') order by r.createdAt desc")
    List<Review> findFiltered(@Param("theatreId") Long theatreId, @Param("reportedOnly") boolean reportedOnly, @Param("visibleOnly") boolean visibleOnly);

    @Query("select r from Review r join fetch r.theatre t where r.status = 'VISIBLE' and r.createdAt >= :since")
    List<Review> findVisibleSince(@Param("since") LocalDateTime since);
}
