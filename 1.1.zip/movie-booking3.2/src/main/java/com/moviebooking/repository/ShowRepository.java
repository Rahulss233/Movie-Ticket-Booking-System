package com.moviebooking.repository;

import com.moviebooking.entity.*;
import com.moviebooking.enums.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

public interface ShowRepository extends JpaRepository<Show, Long> {
    @Query("select count(s) from Show s where s.screen.id = :screenId and s.status = :status and s.startTime < :end and s.endTime > :start")
    long countOverlapping(@Param("screenId") Long screenId, @Param("status") ShowStatus status,
                          @Param("start") LocalDateTime start, @Param("end") LocalDateTime end);

    @Query("select s from Show s join fetch s.screen sc join fetch sc.theatre t join fetch s.movie m " +
           "where m.id = :movieId and t.city.id = :cityId and t.status = :tstatus and s.status = :sstatus " +
           "and s.startTime >= :from and s.startTime < :to and s.startTime > :now order by t.name, s.startTime")
    List<Show> findBookable(@Param("movieId") Long movieId, @Param("cityId") Long cityId,
                            @Param("tstatus") TheatreStatus tstatus, @Param("sstatus") ShowStatus sstatus,
                            @Param("from") LocalDateTime from, @Param("to") LocalDateTime to,
                            @Param("now") LocalDateTime now);

    List<Show> findByScreen_Theatre_IdOrderByStartTimeDesc(Long theatreId);
    boolean existsByScreenId(Long screenId);

    @Query("select s.movie.id, count(s) from Show s join s.screen sc join sc.theatre t join t.city c left join c.parent d left join d.parent st "
            + "where s.status = com.moviebooking.enums.ShowStatus.SCHEDULED and t.status = com.moviebooking.enums.TheatreStatus.APPROVED and s.startTime > :now "
            + "and (:cityId is null or c.id = :cityId) and (:districtId is null or d.id = :districtId) and (:stateId is null or st.id = :stateId) group by s.movie.id")
    List<Object[]> availableMovies(@Param("cityId") Long cityId, @Param("districtId") Long districtId, @Param("stateId") Long stateId, @Param("now") LocalDateTime now);

    @Query("select count(s) from Show s where s.screen.id = :screenId and s.status = :status and s.startTime < :end and s.endTime > :start and s.id <> :excludeId")
    long countOverlappingExcluding(@Param("screenId") Long screenId, @Param("status") ShowStatus status, @Param("start") LocalDateTime start, @Param("end") LocalDateTime end, @Param("excludeId") Long excludeId);

    @Query("select s from Show s join fetch s.screen sc where sc.theatre.id = :theatreId and s.movie.id = :movieId and s.status = com.moviebooking.enums.ShowStatus.SCHEDULED and s.startTime > :after order by s.startTime")
    List<Show> findUpcomingForMovie(@Param("theatreId") Long theatreId, @Param("movieId") Long movieId, @Param("after") LocalDateTime after);

    @Query("select distinct m.id from Show s join s.movie m join s.screen sc join sc.theatre t " +
           "where t.status = :theatreStatus and s.status = :showStatus and s.startTime > :now " +
           "and (t.city.id = :locationId or t.city.parent.id = :locationId or t.city.parent.parent.id = :locationId)")
    List<Long> findMovieIdsAvailableAtLocation(@Param("locationId") Long locationId,
           @Param("theatreStatus") TheatreStatus theatreStatus, @Param("showStatus") ShowStatus showStatus,
           @Param("now") LocalDateTime now);

    @Query("select s from Show s join fetch s.movie join fetch s.screen sc join fetch sc.theatre where s.status = com.moviebooking.enums.ShowStatus.SCHEDULED and s.startTime > :now")
    List<Show> findAllUpcomingScheduled(@Param("now") LocalDateTime now);

    List<Show> findByMovie_IdAndStatusAndStartTimeAfter(Long movieId, ShowStatus status, LocalDateTime after);
}
