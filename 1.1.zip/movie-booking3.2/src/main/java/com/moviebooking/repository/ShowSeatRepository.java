package com.moviebooking.repository;

import com.moviebooking.entity.*;
import com.moviebooking.enums.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

public interface ShowSeatRepository extends JpaRepository<ShowSeat, Long> {
    /** Row-level pessimistic lock: concurrent requests for the same seats are serialised by the DB. */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select min(ss.price), max(ss.price), count(ss) from ShowSeat ss where ss.show.id = :showId")
    List<Object[]> priceRange(@Param("showId") Long showId);

    @Query("select ss from ShowSeat ss join fetch ss.seat where ss.show.id = :showId and ss.seat.id in :seatIds order by ss.id")
    List<ShowSeat> lockSeats(@Param("showId") Long showId, @Param("seatIds") Collection<Long> seatIds);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select ss from ShowSeat ss join fetch ss.seat where ss.show.id = :showId and ss.seat.id in :seatIds order by ss.id")
    List<ShowSeat> findSeatsNoLock(@Param("showId") Long showId, @Param("seatIds") Collection<Long> seatIds);

    @Query("select ss from ShowSeat ss join fetch ss.seat where ss.booking.id = :bookingId order by ss.id")
    List<ShowSeat> lockByBooking(@Param("bookingId") Long bookingId);

    @Query("select ss from ShowSeat ss join fetch ss.seat st where ss.show.id = :showId order by st.rowLabel, st.seatNumber")
    List<ShowSeat> findMap(@Param("showId") Long showId);

    long countByShowIdAndState(Long showId, SeatState state);

    /** (showId, state, count) for every show of one theatre: one query instead of one per show. */
    @Query("select ss.show.id, ss.state, count(ss) from ShowSeat ss where ss.show.screen.theatre.id = :theatreId group by ss.show.id, ss.state")
    List<Object[]> countsByTheatre(@Param("theatreId") Long theatreId);
}
