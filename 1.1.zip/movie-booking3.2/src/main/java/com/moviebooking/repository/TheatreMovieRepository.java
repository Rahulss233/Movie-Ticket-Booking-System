package com.moviebooking.repository;

import com.moviebooking.entity.TheatreMovie;
import java.time.LocalDate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface TheatreMovieRepository extends JpaRepository<TheatreMovie, Long> {
    @Query("select t from TheatreMovie t join fetch t.movie where t.theatre.id = :theatreId order by t.createdAt desc")
    List<TheatreMovie> findAllForTheatre(@Param("theatreId") Long theatreId);

    /** Live windows (not removed) for this movie at this theatre that overlap [start, end]. */
    @Query("select count(t) from TheatreMovie t where t.theatre.id = :theatreId and t.movie.id = :movieId and t.removedAt is null and t.startDate <= :end and t.endDate >= :start and (:exclude is null or t.id <> :exclude)")
    long countOverlapping(@Param("theatreId") Long theatreId, @Param("movieId") Long movieId, @Param("start") LocalDate start, @Param("end") LocalDate end, @Param("exclude") Long exclude);

    /** Live runs of a movie that still have days left, at approved theatres inside a place (city, district or state id; null = anywhere). */
    @Query("select t from TheatreMovie t join fetch t.theatre th join th.city c left join c.parent d left join d.parent st "
         + "where t.movie.id = :movieId and t.removedAt is null and t.endDate >= :today and th.status = com.moviebooking.enums.TheatreStatus.APPROVED "
         + "and (:locationId is null or c.id = :locationId or d.id = :locationId or st.id = :locationId)")
    List<TheatreMovie> findOpenRuns(@Param("movieId") Long movieId, @Param("today") LocalDate today, @Param("locationId") Long locationId);

    @Query("select count(t) from TheatreMovie t where t.theatre.id = :theatreId and t.movie.id = :movieId and t.removedAt is null and t.startDate <= :day and t.endDate >= :day")
    long countCovering(@Param("theatreId") Long theatreId, @Param("movieId") Long movieId, @Param("day") LocalDate day);

    @Query("select t from TheatreMovie t join fetch t.movie join fetch t.theatre where t.removedAt is null and t.endDate >= :today")
    List<TheatreMovie> findAllLive(@Param("today") LocalDate today);

    List<TheatreMovie> findByMovie_IdAndRemovedAtIsNull(Long movieId);
}
