package com.moviebooking.repository;

import com.moviebooking.entity.*;
import com.moviebooking.enums.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

public interface TheatreStatusHistoryRepository extends JpaRepository<TheatreStatusHistory, Long> {
    List<TheatreStatusHistory> findByTheatreIdOrderByCreatedAtDesc(Long theatreId);
}
