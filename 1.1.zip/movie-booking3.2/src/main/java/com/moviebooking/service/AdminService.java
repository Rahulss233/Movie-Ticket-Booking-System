package com.moviebooking.service;

import com.moviebooking.dto.Dtos.*;
import com.moviebooking.entity.*;
import com.moviebooking.enums.*;
import com.moviebooking.exception.*;
import com.moviebooking.repository.*;
import jakarta.persistence.criteria.Predicate;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AdminService {
    private final TheatreRepository theatres;
    private final TheatreMovieRepository theatreMovies;
    private final ScreenRepository screens;
    private final UserRepository users;
    private final MovieRepository movies;
    private final LocationRepository locations;
    private final BookingRepository bookings;
    private final PaymentRepository payments;
    private final AuditLogRepository auditLogs;
    private final TheatreStatusHistoryRepository history;
    private final NotificationService notifications;
    private final AuditService audit;
    private final ViewMapper mapper;
    private final EmailNotificationService email;

    // ---------------- theatres ----------------
    @Transactional(readOnly = true)
    public List<TheatreView> listTheatres(String status, String q) {
        Specification<Theatre> spec = (root, query, cb) -> {
            List<Predicate> p = new ArrayList<>();
            if (status != null && !status.isBlank()) p.add(cb.equal(root.get("status"), TheatreStatus.valueOf(status)));
            if (q != null && !q.isBlank()) {
                String like = "%" + q.toLowerCase().trim() + "%";
                p.add(cb.or(cb.like(cb.lower(root.get("name")), like), cb.like(cb.lower(root.get("address")), like),
                        cb.like(cb.lower(root.get("city").get("name")), like)));
            }
            return cb.and(p.toArray(new Predicate[0]));
        };
        return theatres.findAll(spec, PageRequest.of(0, 200, Sort.by(Sort.Direction.DESC, "createdAt"))).stream()
                .map(t -> mapper.theatre(t, screens.findByTheatreIdOrderByName(t.getId()))).toList();
    }

    @Transactional
    public TheatreView changeStatus(Long id, StatusActionRequest req, String actorEmail) {
        Theatre t = theatres.findById(id).orElseThrow(() -> new NotFoundException("Theatre not found"));
        TheatreAction action;
        try {
            action = TheatreAction.valueOf(req.action());
        } catch (IllegalArgumentException e) {
            throw new BadRequestException("Unknown action");
        }
        if (!action.canApplyTo(t.getStatus()))
            throw new BadRequestException(action + " is not allowed while the theatre is " + t.getStatus());
        String reason = req.reason() == null ? null : req.reason().trim();
        if (action.isReasonRequired() && (reason == null || reason.isEmpty()))
            throw new BadRequestException("A reason is required for " + action);
        TheatreStatus from = t.getStatus();
        t.setStatus(action.getTarget());
        t.setStatusReason(action.isReasonRequired() ? reason : null);
        TheatreStatusHistory h = new TheatreStatusHistory();
        h.setTheatre(t);
        h.setFromStatus(from);
        h.setToStatus(action.getTarget());
        h.setReason(reason);
        h.setActorEmail(actorEmail);
        history.save(h);
        audit.log(actorEmail, "THEATRE_" + action, "theatre=" + t.getId() + " " + from + "->" + action.getTarget() + (reason == null ? "" : " reason=" + reason));
        notifications.notify(t.getOwner(), "Your theatre '" + t.getName() + "' status is now " + action.getTarget()
                + (reason == null ? "." : ": " + reason));
        email.send(t.getOwner().getEmail(), "CineBook theatre application update",
                "The status of your theatre '" + t.getName() + "' is now " + action.getTarget()
                + (reason == null ? "." : ". Reason: " + reason));
        return mapper.theatre(t, screens.findByTheatreIdOrderByName(t.getId()));
    }

    @Transactional(readOnly = true)
    public List<HistoryView> theatreHistory(Long id) {
        return history.findByTheatreIdOrderByCreatedAtDesc(id).stream()
                .map(h -> new HistoryView(h.getFromStatus() == null ? null : h.getFromStatus().name(),
                        h.getToStatus().name(), h.getReason(), h.getActorEmail(), h.getCreatedAt())).toList();
    }

    @Transactional(readOnly = true)
    public List<ScreenView> theatreScreens(Long id) {
        return screens.findByTheatreIdOrderByName(id).stream().map(mapper::screen).toList();
    }

    @Transactional
    public TheatreView setTheatreCommission(Long id, CommissionRequest r, String actor) {
        Theatre t = theatres.findById(id).orElseThrow(() -> new NotFoundException("Theatre not found"));
        BigDecimal old = t.getCommissionPercent();
        t.setCommissionPercent(r.percent());
        audit.log(actor, "THEATRE_COMMISSION", "theatre=" + id + " old=" + old + " new=" + r.percent());
        return mapper.theatre(t, screens.findByTheatreIdOrderByName(id));
    }

    @Transactional
    public ScreenView setScreenCommission(Long screenId, CommissionRequest r, String actor) {
        Screen s = screens.findById(screenId).orElseThrow(() -> new NotFoundException("Screen not found"));
        BigDecimal old = s.getCommissionPercent();
        s.setCommissionPercent(r.percent());   // null clears the override -> inherits theatre rate
        audit.log(actor, "SCREEN_COMMISSION", "screen=" + screenId + " old=" + old + " new=" + r.percent());
        return mapper.screen(s);
    }

    // ---------------- movies & locations ----------------
    @Transactional(readOnly = true)
    public List<Movie> listMovies(String status) {
        List<Movie> list = movies.findAll(Sort.by(Sort.Direction.ASC, "title"));
        if (status == null || status.isBlank()) return list;
        MovieStatus selected = MovieStatus.valueOf(status);
        return list.stream().filter(m -> m.getStatus() == selected).toList();
    }

    @Transactional
    public Movie saveMovie(Long id, MovieRequest r, String actor) {
        Movie m = id == null ? new Movie() : movies.findById(id).orElseThrow(() -> new NotFoundException("Movie not found"));
        MovieStatus before = id == null ? null : m.getStatus();
        m.setTitle(r.title().trim());
        m.setDescription(r.description());
        m.setPosterUrl(r.posterUrl());
        m.setTrailerUrl(r.trailerUrl());
        m.setGenre(r.genre().trim());
        m.setLanguage(r.language().trim());
        m.setDurationMinutes(r.durationMinutes());
        m.setCertification(r.certification());
        m.setCastInfo(r.castInfo());
        m.setReleaseDate(r.releaseDate());
        m.setStatus(MovieStatus.valueOf(r.status()));
        if (before == MovieStatus.PENDING_REVIEW && m.getStatus() != MovieStatus.PENDING_REVIEW)
            m.setReviewNote((m.getStatus() == MovieStatus.ARCHIVED ? "Rejected by " : "Approved by ") + actor);
        else if (before != null && m.getReviewNote() != null && m.getReviewNote().startsWith(MovieImportService.AUTO))
            m.setReviewNote("Edited by " + actor + " (no longer refreshed by import)");
        movies.save(m);
        if (before == MovieStatus.PENDING_REVIEW && m.getStatus() != MovieStatus.PENDING_REVIEW && m.getProposedByEmail() != null) {
            users.findByEmail(m.getProposedByEmail()).ifPresent(u -> notifications.notify(u, "Movie '" + m.getTitle() + "' was reviewed: "
                    + (m.getStatus() == MovieStatus.ARCHIVED ? "not approved for the catalogue." : "approved and now in the catalogue.")));
        }
        audit.log(actor, id == null ? "MOVIE_CREATE" : "MOVIE_UPDATE", "movie=" + m.getId() + " " + m.getTitle());
        return m;
    }

    /** Theatre admin movie request: stays PENDING_REVIEW until the Super Admin approves it. */
    @Transactional
    public Movie addMovieByTheatre(MovieRequest r, String adderEmail) {
        if (movies.findByTitleIgnoreCaseAndLanguageIgnoreCase(r.title().trim(), r.language().trim()).stream().anyMatch(x -> x.getStatus() != MovieStatus.ARCHIVED))
            throw new ConflictException("This movie is already in the catalogue. Search for it and add it to your theatre instead.");
        boolean released = r.releaseDate() != null && !r.releaseDate().isAfter(java.time.LocalDate.now());
        MovieRequest published = new MovieRequest(r.title(), r.description(), r.posterUrl(), r.trailerUrl(), r.genre(), r.language(), r.durationMinutes(),
                r.certification(), r.castInfo(), r.releaseDate(), released ? "ACTIVE" : "UPCOMING");
        Movie m = saveMovie(null, published, adderEmail);       // no approval step: theatres publish directly
        m.setProposedByEmail(adderEmail);
        movies.save(m);
        return m;
    }

    /** A theatre may correct the details of a film its own theatre added; films added by others stay with the Super Admin. */
    @Transactional
    public Movie editMovieByTheatre(Long id, MovieRequest r, String editorEmail) {
        Movie existing = movies.findById(id).orElseThrow(() -> new NotFoundException("Movie not found"));
        boolean owner = existing.getProposedByEmail() != null && existing.getProposedByEmail().equalsIgnoreCase(editorEmail);
        // A theatre may also edit any movie that is currently on (or booked onto) its own screens.
        boolean running = !owner && users.findByEmail(editorEmail).flatMap(u -> theatres.findByOwnerId(u.getId()))
                .map(t -> theatreMovies.findAllForTheatre(t.getId()).stream()
                        .anyMatch(l -> l.getMovie().getId().equals(id) && l.getRemovedAt() == null))
                .orElse(false);
        if (!owner && !running)
            throw new ForbiddenException("You can edit movies your theatre added or movies running on your screens.");
        if (existing.getStatus() == MovieStatus.ARCHIVED) throw new BadRequestException("Archived movies cannot be edited");
        boolean released = r.releaseDate() != null && !r.releaseDate().isAfter(java.time.LocalDate.now());
        MovieRequest updated = new MovieRequest(r.title(), r.description(), r.posterUrl(), r.trailerUrl(), r.genre(), r.language(), r.durationMinutes(),
                r.certification(), r.castInfo(), r.releaseDate(), released ? "ACTIVE" : "UPCOMING");
        return saveMovie(id, updated, editorEmail);
    }

    @Transactional(readOnly = true)
    public List<Movie> myMovieRequests(String email) { return movies.findByProposedByEmailOrderByCreatedAtDesc(email); }

    @Transactional
    public LocationView addLocation(LocationRequest r, String actor) {
        LocationType type = LocationType.valueOf(r.type());
        Location parent = null;
        if (type == LocationType.STATE) {
            if (r.parentId() != null) throw new BadRequestException("A state has no parent");
        } else {
            parent = locations.findById(r.parentId() == null ? -1L : r.parentId()).orElseThrow(() -> new BadRequestException("Parent location is required"));
            LocationType expected = type == LocationType.DISTRICT ? LocationType.STATE : LocationType.DISTRICT;
            if (parent.getType() != expected) throw new BadRequestException("A " + type + " must belong to a " + expected);
        }
        if (locations.existsByNameIgnoreCaseAndParent(r.name().trim(), parent)) throw new ConflictException("Location already exists");
        Location l = new Location();
        l.setName(r.name().trim());
        l.setType(type);
        l.setParent(parent);
        locations.save(l);
        audit.log(actor, "LOCATION_CREATE", type + " " + l.getName());
        return mapper.location(l);
    }

    // ---------------- users ----------------
    @Transactional(readOnly = true)
    public List<UserView> listUsers() {
        return users.findAll(Sort.by(Sort.Direction.DESC, "createdAt")).stream().map(mapper::user).toList();
    }

    @Transactional
    public UserView setUserActive(Long id, boolean active, String actor) {
        User u = users.findById(id).orElseThrow(() -> new NotFoundException("User not found"));
        if (u.getRole() == Role.SUPER_ADMIN) throw new ForbiddenException("Super admin accounts cannot be changed here");
        u.setActive(active);
        audit.log(actor, active ? "USER_ACTIVATE" : "USER_DEACTIVATE", "user=" + id);
        return mapper.user(u);
    }

    @Transactional(readOnly = true)
    public List<PaymentLedgerView> paymentLedger() {
        return payments.findAll(Sort.by(Sort.Direction.DESC, "createdAt")).stream().limit(500)
                .map(p -> new PaymentLedgerView(p.getId(), p.getBooking().getReference(), p.getTransactionRef(),
                        p.getGatewayRef(), p.getAmount(), p.getStatus().name(), p.getMode(), p.getMessage(), p.getCreatedAt()))
                .toList();
    }

    @Transactional(readOnly = true)
    public List<AuditView> auditTrail() {
        return auditLogs.findTop100ByOrderByCreatedAtDesc().stream()
                .map(a -> new AuditView(a.getActorEmail(), a.getAction(), a.getDetails(), a.getCreatedAt())).toList();
    }

    // ---------------- dashboard (all numbers from the database) ----------------
    @Transactional(readOnly = true)
    public DashboardView dashboard() {
        long pending = theatres.countByStatus(TheatreStatus.PENDING_VERIFICATION) + theatres.countByStatus(TheatreStatus.UNDER_REVIEW)
                + theatres.countByStatus(TheatreStatus.CHANGES_REQUIRED);
        List<String> recent = auditLogs.findTop20ByOrderByCreatedAtDesc().stream()
                .map(a -> a.getCreatedAt().withNano(0) + "  " + a.getActorEmail() + "  " + a.getAction() + "  " + (a.getDetails() == null ? "" : a.getDetails())).toList();
        return new DashboardView(theatres.count(), pending, theatres.countByStatus(TheatreStatus.APPROVED),
                theatres.countByStatus(TheatreStatus.SUSPENDED), theatres.countByStatus(TheatreStatus.DEACTIVATED),
                users.countByRole(Role.CUSTOMER), movies.count(), bookings.countByStatus(BookingStatus.CONFIRMED),
                bookings.countByStatus(BookingStatus.CANCELLED), bookings.sumConfirmedGross(), payments.sumCollected(),
                bookings.sumRefunds(), bookings.sumCommission(), bookings.sumTheatrePayable(),
                payments.countByStatus(PaymentStatus.FAILED), recent);
    }
}
