package com.moviebooking.service;

import com.moviebooking.entity.AuditLog;
import com.moviebooking.repository.AuditLogRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AuditService {
    private final AuditLogRepository repo;

    @Transactional
    public void log(String actorEmail, String action, String details) {
        AuditLog a = new AuditLog();
        a.setActorEmail(actorEmail);
        a.setAction(action);
        a.setDetails(details);
        repo.save(a);
    }
}
