package com.moviebooking.service;

import com.moviebooking.dto.Dtos.*;
import com.moviebooking.entity.*;
import com.moviebooking.enums.*;
import com.moviebooking.exception.*;
import com.moviebooking.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AuthService {
    private final UserRepository users;
    private final TheatreRepository theatres;
    private final LocationRepository locations;
    private final TheatreStatusHistoryRepository history;
    private final PasswordEncoder encoder;
    private final NotificationService notifications;
    private final ViewMapper mapper;

    /** Role is fixed by the endpoint, never taken from the request body. */
    @Transactional
    public User createUser(RegisterRequest r, Role role) {
        String email = r.email().toLowerCase().trim();
        if (users.existsByEmail(email)) throw new ConflictException("An account with this email already exists");
        if (users.existsByPhone(r.phone())) throw new ConflictException("An account with this phone number already exists");
        User u = new User();
        u.setName(r.name().trim());
        u.setEmail(email);
        u.setPhone(r.phone());
        if (r.address() != null && !r.address().isBlank()) u.setAddress(r.address().trim());
        u.setPasswordHash(encoder.encode(r.password()));
        u.setRole(role);
        return users.save(u);
    }

    @Transactional
    public UserView registerCustomer(RegisterRequest r) {
        if (r.address() == null || r.address().isBlank()) throw new BadRequestException("Address is required");
        return mapper.user(createUser(r, Role.CUSTOMER));
    }

    @Transactional
    public UserView registerTheatre(TheatreRegistrationRequest req) {
        TheatreDetails d = req.theatre();
        if (theatres.existsByLicenseNumberIgnoreCase(d.licenseNumber()))
            throw new ConflictException("A theatre with this licence number is already registered");
        Location city = locations.findById(d.cityId()).orElseThrow(() -> new BadRequestException("Unknown city"));
        if (city.getType() != LocationType.CITY) throw new BadRequestException("Location must be a city");
        User owner = createUser(req.owner(), Role.THEATRE_ADMIN);
        Theatre t = new Theatre();
        t.setOwner(owner);
        t.setCity(city);
        TheatreService.apply(t, d);
        theatres.save(t);
        TheatreStatusHistory h = new TheatreStatusHistory();
        h.setTheatre(t);
        h.setToStatus(TheatreStatus.PENDING_VERIFICATION);
        h.setReason("Registration submitted");
        h.setActorEmail(owner.getEmail());
        history.save(h);
        notifications.notify(owner, "Your theatre registration was received and is pending verification.");
        notifications.notifySuperAdmins("New theatre registration: " + t.getName());
        return mapper.user(owner);
    }

    /** A customer (or any user) updates their own name, phone and address. Email stays fixed. */
    @Transactional
    public UserView updateProfile(User current, ProfileUpdate r) {
        User u = users.findById(current.getId()).orElseThrow(() -> new NotFoundException("User not found"));
        if (!u.getPhone().equals(r.phone()) && users.existsByPhone(r.phone()))
            throw new ConflictException("An account with this phone number already exists");
        u.setName(r.name().trim());
        u.setPhone(r.phone());
        u.setAddress(r.address().trim());
        return mapper.user(users.save(u));
    }
}
