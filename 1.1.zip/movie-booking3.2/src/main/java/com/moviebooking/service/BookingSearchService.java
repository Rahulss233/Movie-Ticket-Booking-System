package com.moviebooking.service;

import com.moviebooking.entity.Booking;
import com.moviebooking.exception.BadRequestException;
import com.moviebooking.repository.BookingRepository;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Booking lists with filters. The Super Admin may look at every theatre or pick one; for a Theatre Admin the controller
 * always replaces theatreId with their own theatre, so nothing from the browser can widen the scope.
 */
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class BookingSearchService {
    private final BookingRepository bookings;

    public record BookingRow(String reference, String customer, String customerEmail, Long theatreId, String theatre, Long screenId, String screen, Long movieId, String movie,
                             LocalDateTime showTime, String seats, int tickets, BigDecimal amount, BigDecimal discount, String offerCode, String status, String paymentStatus,
                             BigDecimal refundAmount, String refundStatus, LocalDateTime cancelledAt, LocalDateTime refundCompletedAt, String refundReference,
                             String showCancelReason, LocalDateTime createdAt) {}

    public record Result(long total, int page, int size, Map<String, Object> summary, List<BookingRow> rows) {}

    private static BigDecimal z(BigDecimal v) { return v == null ? BigDecimal.ZERO : v; }

    public Result search(Long theatreId, Long screenId, Long movieId, String status, String paymentStatus, LocalDate from, LocalDate to, String q,
                         boolean showEmail, int page, int size) {
        LocalDate f = from != null ? from : LocalDate.now().minusDays(29), t = to != null ? to : LocalDate.now();
        if (t.isBefore(f)) throw new BadRequestException("End date is before start date");
        if (f.plusYears(2).isBefore(t)) throw new BadRequestException("Choose a range of at most two years");
        String needle = q == null ? "" : q.trim().toLowerCase(Locale.ROOT);
        List<BookingRow> all = bookings.searchBookings(theatreId, screenId, movieId, f.atStartOfDay(), t.plusDays(1).atStartOfDay()).stream()
                .filter(b -> status == null || status.isBlank() || b.getStatus().name().equals(status))
                .filter(b -> paymentStatus == null || paymentStatus.isBlank() || b.getPaymentStatus().name().equals(paymentStatus))
                .map(b -> row(b, showEmail))
                .filter(r -> needle.isEmpty() || (r.reference() + " " + r.customer() + " " + r.movie() + " " + r.theatre() + " " + r.seats()).toLowerCase(Locale.ROOT).contains(needle))
                .toList();
        long confirmed = all.stream().filter(r -> "CONFIRMED".equals(r.status())).count(), cancelled = all.stream().filter(r -> "CANCELLED".equals(r.status())).count();
        BigDecimal revenue = all.stream().filter(r -> "CONFIRMED".equals(r.status())).map(r -> z(r.amount())).reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal refunds = all.stream().map(r -> z(r.refundAmount())).reduce(BigDecimal.ZERO, BigDecimal::add);
        long refundsPending = all.stream().filter(r -> "REFUND_PENDING".equals(r.paymentStatus())).count();
        Map<String, Object> summary = new LinkedHashMap<>();
        summary.put("bookings", all.size()); summary.put("confirmed", confirmed); summary.put("cancelled", cancelled);
        summary.put("revenue", revenue); summary.put("refunds", refunds); summary.put("refundsPending", refundsPending);
        int sz = Math.min(Math.max(size, 1), 200), pg = Math.max(page, 0), start = Math.min(pg * sz, all.size());
        return new Result(all.size(), pg, sz, summary, all.subList(start, Math.min(start + sz, all.size())));
    }

    private BookingRow row(Booking b, boolean showEmail) {
        var sh = b.getShow(); var sc = sh.getScreen(); var th = sc.getTheatre();
        int tickets = b.getSeatLabels() == null || b.getSeatLabels().isBlank() ? 0 : b.getSeatLabels().split(",").length;
        return new BookingRow(b.getReference(), b.getCustomer().getName(), showEmail ? b.getCustomer().getEmail() : null, th.getId(), th.getName(), sc.getId(), sc.getName(),
                sh.getMovie().getId(), sh.getMovie().getTitle(), sh.getStartTime(), b.getSeatLabels(), tickets, z(b.getTotalAmount()), b.getDiscountAmount(), b.getOfferCode(),
                b.getStatus().name(), b.getPaymentStatus().name(), b.getRefundAmount(), b.getRefundStatus(), b.getCancelledAt(), b.getRefundCompletedAt(), b.getRefundReference(),
                sh.getCancelReason(), b.getCreatedAt());
    }
}
