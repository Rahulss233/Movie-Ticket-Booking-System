package com.moviebooking.service;

import com.moviebooking.dto.Dtos.*;
import com.moviebooking.entity.*;
import com.moviebooking.enums.*;
import com.moviebooking.exception.*;
import com.moviebooking.repository.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class BookingService {
    private final BookingRepository bookings;
    private final ShowRepository shows;
    private final ShowSeatRepository showSeats;
    private final PaymentRepository payments;
    private final PaymentGateway gateway;
    private final CommissionPolicy commission;
    private final NotificationService notifications;
    private final ViewMapper mapper;
    private final AuditService audit;
    private final EmailNotificationService email;
    private final OfferService offerService;

    @Value("${app.seat-hold-minutes:5}") private int holdMinutes;
    @Value("${app.max-seats-per-booking:8}") private int maxSeats;
    @Value("${app.cancellation.full-refund-hours:24}") private long fullRefundHours;
    @Value("${app.cancellation.partial-refund-hours:4}") private long partialRefundHours;
    @Value("${app.cancellation.partial-refund-percent:50}") private int partialRefundPercent;

    private static boolean isFree(ShowSeat ss, LocalDateTime now) {
        return ss.getState() == SeatState.AVAILABLE
                || (ss.getState() == SeatState.LOCKED && ss.getLockedUntil() != null && ss.getLockedUntil().isBefore(now));
    }

    private static void release(ShowSeat ss) {
        ss.setState(SeatState.AVAILABLE);
        ss.setLockedUntil(null);
        ss.setBooking(null);
    }

    /** Step 1: temporarily reserve seats. Rows are locked with SELECT ... FOR UPDATE so two customers cannot both win. */
    @Transactional
    public BookingView holdSeats(User customer, HoldRequest req) {
        Show show = shows.findById(req.showId()).orElseThrow(() -> new NotFoundException("Show not found"));
        LocalDateTime now = LocalDateTime.now();
        if (show.getStatus() != ShowStatus.SCHEDULED || !show.getStartTime().isAfter(now))
            throw new BadRequestException("This show is not open for booking");
        if (show.getScreen().getTheatre().getStatus() != TheatreStatus.APPROVED)
            throw new BadRequestException("This theatre is not accepting bookings right now");
        if (!CatalogService.withinWindow(show.getScreen().getTheatre(), show.getStartTime().toLocalDate()))
            throw new BadRequestException("Booking for this date is not open yet. This theatre opens bookings " + show.getScreen().getTheatre().windowDays() + " days ahead.");
        Set<Long> ids = new LinkedHashSet<>(req.seatIds());
        if (ids.size() > maxSeats) throw new BadRequestException("You can book at most " + maxSeats + " seats at a time");

        List<ShowSeat> seats = showSeats.lockSeats(show.getId(), ids);
        if (seats.size() != ids.size()) throw new BadRequestException("One or more seats are invalid for this show");
        BigDecimal total = BigDecimal.ZERO;
        for (ShowSeat ss : seats) {
            if (!isFree(ss, now)) throw new ConflictException("Seat " + ss.getSeat().label() + " is no longer available");
            total = total.add(ss.getPrice());
        }
        Offer appliedOffer = null;
        BigDecimal discount = BigDecimal.ZERO;
        if (req.couponCode() != null && !req.couponCode().isBlank()) {          // validated and calculated here, never taken from the browser
            OfferService.Applied a = offerService.check(req.couponCode(), customer, show, total);
            appliedOffer = a.offer();
            discount = a.discount();
        }
        Booking b = new Booking();
        b.setReference("MB" + UUID.randomUUID().toString().replace("-", "").substring(0, 10).toUpperCase());
        b.setCustomer(customer);
        b.setShow(show);
        b.setTotalAmount(total.subtract(discount));
        if (appliedOffer != null) { b.setOfferCode(appliedOffer.getCode()); b.setDiscountAmount(discount); }
        b.setHoldExpiresAt(now.plusMinutes(holdMinutes));
        b.setSeatLabels(seats.stream().map(ss -> ss.getSeat().label()).collect(Collectors.joining(", ")));
        bookings.save(b);
        if (appliedOffer != null) offerService.recordRedemption(appliedOffer, b, customer, discount);
        for (ShowSeat ss : seats) {
            ss.setState(SeatState.LOCKED);
            ss.setLockedUntil(b.getHoldExpiresAt());
            ss.setBooking(b);
        }
        return mapper.booking(b);
    }

    /** Step 2: pay. Idempotent: a repeated key or an already-confirmed booking never charges twice. */
    @Transactional
    public BookingView pay(User customer, String reference, PayRequest req) {
        Booking b = ownedBooking(customer, reference);
        Optional<Payment> prior = payments.findByTransactionRef(req.idempotencyKey());
        if (prior.isPresent()) {
            if (!prior.get().getBooking().getId().equals(b.getId())) throw new ConflictException("Idempotency key already used");
            return mapper.booking(b, "Duplicate request ignored");
        }
        if (b.getStatus() == BookingStatus.CONFIRMED) return mapper.booking(b, "Already paid");
        if (b.getStatus() != BookingStatus.PENDING_PAYMENT) throw new ConflictException("Booking is " + b.getStatus());

        LocalDateTime now = LocalDateTime.now();
        List<ShowSeat> seats = showSeats.lockByBooking(b.getId());
        boolean valid = b.getHoldExpiresAt().isAfter(now) && !seats.isEmpty()
                && seats.stream().allMatch(ss -> ss.getState() == SeatState.LOCKED)
                && b.getShow().getStatus() == ShowStatus.SCHEDULED;
        if (!valid) {                       // revalidate before charging
            expire(b, seats);
            return mapper.booking(b, "Your seat hold expired. Please select seats again.");
        }

        PaymentGateway.PaymentResult result = gateway.charge(b, req.simulateFailure());
        Payment p = new Payment();
        p.setBooking(b);
        p.setTransactionRef(req.idempotencyKey());
        p.setGatewayRef(result.gatewayRef());
        p.setAmount(b.getTotalAmount());
        p.setMode(gateway.mode());
        p.setMessage(result.message());
        p.setStatus(result.success() ? PaymentStatus.SUCCESS : PaymentStatus.FAILED);
        payments.save(p);

        if (!result.success()) {
            b.setPaymentStatus(PaymentStatus.FAILED);
            notifications.notify(b.getCustomer(), "Payment failed for booking " + b.getReference() + ". Your seats are held until "
                    + b.getHoldExpiresAt().toLocalTime().withNano(0) + ".");
            return mapper.booking(b, result.message());
        }

        seats.forEach(ss -> { ss.setState(SeatState.BOOKED); ss.setLockedUntil(null); });
        if (b.getTicketToken() == null) b.setTicketToken(UUID.randomUUID().toString().replace("-", ""));
        BigDecimal rate = commission.effectiveRate(b.getShow().getScreen());
        BigDecimal comm = commission.commission(b.getTotalAmount(), rate);
        b.setStatus(BookingStatus.CONFIRMED);
        b.setPaymentStatus(PaymentStatus.SUCCESS);
        b.setHoldExpiresAt(null);
        b.setCommissionRate(rate);                       // frozen snapshot
        b.setCommissionBasis(b.getTotalAmount());
        b.setCommissionAmount(comm);
        b.setTheatrePayable(b.getTotalAmount().subtract(comm));
        notifications.notify(b.getCustomer(), "Booking " + b.getReference() + " confirmed for " + b.getShow().getMovie().getTitle()
                + " (seats " + b.getSeatLabels() + ").");
        notifications.notify(b.getShow().getScreen().getTheatre().getOwner(), "New booking " + b.getReference() + ": "
                + b.getSeatLabels() + " for " + b.getShow().getMovie().getTitle());
        email.send(b.getCustomer().getEmail(), "CineBook booking confirmed - " + b.getReference(),
                "Your CineBook booking is confirmed.\nMovie: " + b.getShow().getMovie().getTitle()
                + "\nTheatre: " + b.getShow().getScreen().getTheatre().getName()
                + "\nScreen: " + b.getShow().getScreen().getName() + "\nShow time: " + b.getShow().getStartTime()
                + "\nSeats: " + b.getSeatLabels() + "\nBooking reference: " + b.getReference()
                + "\nAmount: INR " + b.getTotalAmount() + "\nOpen CineBook and show your QR ticket at entry.");
        return mapper.booking(b);
    }

    @Transactional
    public BookingView cancel(User customer, String reference) {
        Booking b = ownedBooking(customer, reference);
        if (b.getStatus() != BookingStatus.CONFIRMED) throw new BadRequestException("Only confirmed bookings can be cancelled");
        if (!b.getShow().getScreen().getTheatre().isCancellable()) throw new BadRequestException("This theatre does not allow cancellations (non-cancellable tickets)");
        LocalDateTime now = LocalDateTime.now();
        long minutes = Duration.between(now, b.getShow().getStartTime()).toMinutes();
        if (minutes <= 0) throw new BadRequestException("The show has already started");
        int percent;
        if (minutes >= fullRefundHours * 60) percent = 100;
        else if (minutes >= partialRefundHours * 60) percent = partialRefundPercent;
        else throw new BadRequestException("Cancellation is not allowed within " + partialRefundHours + " hours of the show");
        BigDecimal refund = b.getTotalAmount().multiply(BigDecimal.valueOf(percent)).divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
        showSeats.lockByBooking(b.getId()).forEach(BookingService::release);
        finishCancellation(b, refund, now);
        notifications.notify(b.getCustomer(), "Booking " + b.getReference() + " cancelled. Refund of " + refund + " (" + percent + "%) is pending.");
        return mapper.booking(b);
    }

    /** Called when a theatre cancels a show: confirmed bookings get 100% refunds, unpaid holds are expired. */
    @Transactional
    public void cancelAllForShow(Show show) {
        LocalDateTime now = LocalDateTime.now();
        for (Booking b : bookings.findByShowIdAndStatusIn(show.getId(), List.of(BookingStatus.CONFIRMED, BookingStatus.PENDING_PAYMENT))) {
            if (b.getStatus() == BookingStatus.CONFIRMED) {
                finishCancellation(b, b.getTotalAmount(), now);
                notifications.notify(b.getCustomer(), "The show for booking " + b.getReference() + " was cancelled by the theatre"
                        + (show.getCancelReason() == null ? "" : " (reason: " + show.getCancelReason() + ")") + ". Full refund is pending.");
            } else {
                expire(b, showSeats.lockByBooking(b.getId()));
            }
        }
    }

    private void finishCancellation(Booking b, BigDecimal refund, LocalDateTime now) {
        b.setStatus(BookingStatus.CANCELLED);
        b.setCancelledAt(now);
        b.setRefundAmount(refund);
        boolean refunding = refund.signum() > 0;
        b.setRefundStatus(refunding ? "PENDING" : "NONE");
        b.setPaymentStatus(refunding ? PaymentStatus.REFUND_PENDING : PaymentStatus.SUCCESS);
        // commission is recalculated only on the amount the platform actually keeps
        BigDecimal retained = b.getTotalAmount().subtract(refund);
        b.setCommissionBasis(retained);
        b.setCommissionAmount(commission.commission(retained, b.getCommissionRate()));
        b.setTheatrePayable(retained.subtract(b.getCommissionAmount()));
    }

    private void expire(Booking b, List<ShowSeat> seats) {
        seats.stream().filter(ss -> ss.getState() == SeatState.LOCKED).forEach(BookingService::release);
        b.setStatus(BookingStatus.EXPIRED);
        b.setHoldExpiresAt(null);
    }


    @Transactional(readOnly = true)
    public String ticketToken(User customer, String reference) {
        Booking b = ownedBooking(customer, reference);
        if (b.getStatus() != BookingStatus.CONFIRMED || b.getTicketToken() == null)
            throw new BadRequestException("A valid QR ticket is available only for confirmed bookings");
        return b.getTicketToken();
    }

    @Transactional
    public TicketValidationView validateTicket(User theatreAdmin, String token) {
        Booking b = bookings.findByTicketToken(token).orElseThrow(() -> new NotFoundException("Ticket token not found"));
        if (!b.getShow().getScreen().getTheatre().getOwner().getId().equals(theatreAdmin.getId()))
            throw new com.moviebooking.exception.ForbiddenException("This ticket belongs to another theatre");
        Show show = b.getShow();
        String status; String message; boolean valid = false;
        if (b.getStatus() != BookingStatus.CONFIRMED) { status = b.getStatus().name(); message = "Booking is not confirmed or has been cancelled"; }
        else if (b.getCheckedInAt() != null) { status = "ALREADY_USED"; message = "This ticket has already been checked in"; }
        else {
            b.setCheckedInAt(LocalDateTime.now());
            status = "VALID"; message = "Ticket validated and check-in recorded"; valid = true;
            audit.log(theatreAdmin.getEmail(), "TICKET_CHECK_IN", "booking=" + b.getReference() + "; show=" + show.getId());
        }
        return new TicketValidationView(valid, status, b.getReference(), show.getMovie().getTitle(),
                show.getScreen().getTheatre().getName(), show.getScreen().getName(), show.getStartTime(),
                b.getSeatLabels(), b.getCheckedInAt(), message);
    }

    /** Scheduler hook: frees seats whose hold expired without payment. */
    @Transactional
    public int releaseExpiredHolds() {
        List<Booking> expired = bookings.findByStatusAndHoldExpiresAtBefore(BookingStatus.PENDING_PAYMENT, LocalDateTime.now());
        expired.forEach(b -> expire(b, showSeats.lockByBooking(b.getId())));
        return expired.size();
    }

    @Transactional(readOnly = true)
    public List<BookingView> myBookings(User customer) {
        return bookings.findByCustomerIdOrderByCreatedAtDesc(customer.getId()).stream()
                .filter(b -> b.getStatus() != BookingStatus.EXPIRED).map(mapper::booking).toList();
    }

    @Transactional(readOnly = true)
    public BookingView get(User customer, String reference) {
        return mapper.booking(ownedBooking(customer, reference));
    }

    private Booking ownedBooking(User customer, String reference) {
        Booking b = bookings.findByReference(reference).orElseThrow(() -> new NotFoundException("Booking not found"));
        if (!b.getCustomer().getId().equals(customer.getId())) throw new NotFoundException("Booking not found");
        return b;
    }

    // ---- Phone-scan test payment: the desktop shows a QR, the phone opens it and taps OK ----
    private final String mobileSecret = UUID.randomUUID().toString();

    private String mobileToken(Booking b) {
        try {
            javax.crypto.Mac mac = javax.crypto.Mac.getInstance("HmacSHA256");
            mac.init(new javax.crypto.spec.SecretKeySpec(mobileSecret.getBytes(java.nio.charset.StandardCharsets.UTF_8), "HmacSHA256"));
            byte[] h = mac.doFinal((b.getReference() + "|" + b.getId()).getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder(); for (int i = 0; i < 12; i++) sb.append(String.format("%02x", h[i]));
            return sb.toString();
        } catch (Exception e) { throw new IllegalStateException(e); }
    }

    @Transactional(readOnly = true)
    public String mobilePayToken(User customer, String reference) {
        Booking b = ownedBooking(customer, reference);
        if (b.getStatus() != BookingStatus.PENDING_PAYMENT) throw new BadRequestException("This booking is not waiting for payment");
        return mobileToken(b);
    }

    private Booking mobileBooking(String reference, String token) {
        Booking b = bookings.findByReference(reference).orElseThrow(() -> new NotFoundException("Booking not found"));
        if (token == null || !java.security.MessageDigest.isEqual(token.getBytes(), mobileToken(b).getBytes())) throw new ForbiddenException("Invalid payment link");
        return b;
    }

    @Transactional(readOnly = true)
    public BookingView mobileInfo(String reference, String token) { return mapper.booking(mobileBooking(reference, token), null); }

    @Transactional
    public BookingView mobileApprove(String reference, String token) {
        Booking b = mobileBooking(reference, token);
        return pay(b.getCustomer(), reference, new PayRequest("MQR-" + reference, false));
    }
}
