package com.moviebooking.service;

import com.moviebooking.dto.Dtos.*;
import com.moviebooking.entity.*;
import com.moviebooking.enums.*;
import com.moviebooking.exception.*;
import com.moviebooking.repository.*;
import jakarta.persistence.criteria.Predicate;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Read-only public browsing: locations, movies, shows, seat maps. */
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class CatalogService {
    private final LocationRepository locations;
    private final MovieRepository movies;
    private final ShowRepository shows;
    private final ShowSeatRepository showSeats;
    private final TheatreMovieRepository runs;
    private final ViewMapper mapper;

    public List<LocationView> searchLocations(String query) {
        if (query == null || query.trim().length() < 2) return List.of();
        return locations.findTop30ByNameContainingIgnoreCaseOrderByName(query.trim()).stream()
                .map(mapper::location).toList();
    }

    public List<LocationView> locations(LocationType type, Long parentId) {
        List<Location> list = parentId != null ? locations.findByParentIdOrderByName(parentId)
                : locations.findByTypeAndParentIsNullOrderByName(LocationType.STATE);
        return list.stream().map(mapper::location).toList();
    }

    public List<Movie> movies(MovieStatus status, String language, String genre, String q, Long locationId) {
        Specification<Movie> spec = (root, query, cb) -> {
            List<Predicate> p = new ArrayList<>();
            // Removed (archived) and pending movies are never listed publicly, whatever status is asked for.
            if (status == MovieStatus.ARCHIVED || status == MovieStatus.PENDING_REVIEW) p.add(cb.disjunction());
            else p.add(root.get("status").in(MovieStatus.UPCOMING, MovieStatus.ACTIVE));
            if (language != null && !language.isBlank()) p.add(cb.like(cb.lower(root.get("language")), "%" + language.toLowerCase().trim() + "%"));
            if (genre != null && !genre.isBlank()) p.add(cb.like(cb.lower(root.get("genre")), "%" + genre.toLowerCase() + "%"));
            if (q != null && !q.isBlank()) {
                String term = "%" + q.toLowerCase().trim() + "%";
                p.add(cb.or(cb.like(cb.lower(root.get("title")), term), cb.like(cb.lower(root.get("castInfo")), term),
                        cb.like(cb.lower(root.get("genre")), term), cb.like(cb.lower(root.get("language")), term),
                        cb.like(cb.lower(root.get("description")), term)));
            }
            return cb.and(p.toArray(new Predicate[0]));
        };
        List<Movie> result = movies.findAll(spec, PageRequest.of(0, 100, Sort.by("title"))).getContent();
        LocalDate today = LocalDate.now();
        // Release-date lifecycle: an upcoming movie becomes active automatically on/after its release date.
        result.forEach(movie -> {
            if (movie.getStatus() == MovieStatus.UPCOMING && movie.getReleaseDate() != null
                    && !movie.getReleaseDate().isAfter(today)) {
                movie.setStatus(MovieStatus.ACTIVE);
            }
        });
        if (status != null) result = result.stream().filter(m -> m.getStatus() == status).toList();
        else result = result.stream().filter(m -> m.getStatus() != MovieStatus.PENDING_REVIEW).toList();
        if (locationId != null) {
            List<Long> availableIds = shows.findMovieIdsAvailableAtLocation(locationId, TheatreStatus.APPROVED,
                    ShowStatus.SCHEDULED, LocalDateTime.now());
            result = result.stream().filter(m -> availableIds.contains(m.getId())).toList();
        }
        return result;
    }

    public Movie movie(Long id) {
        Movie movie = movies.findById(id).orElseThrow(() -> new NotFoundException("Movie not found"));
        if (movie.getStatus() == MovieStatus.PENDING_REVIEW) throw new NotFoundException("Movie is awaiting catalogue review");
        if (movie.getStatus() == MovieStatus.ARCHIVED) throw new NotFoundException("This movie is no longer available");
        if (movie.getStatus() == MovieStatus.UPCOMING && movie.getReleaseDate() != null
                && !movie.getReleaseDate().isAfter(LocalDate.now())) {
            movie.setStatus(MovieStatus.ACTIVE);
        }
        return movie;
    }

    public List<ShowView> showsFor(Long movieId, Long cityId, LocalDate date) {
        LocalDate day = date != null ? date : LocalDate.now();
        if (day.isBefore(LocalDate.now())) return List.of();
        List<Show> list = shows.findBookable(movieId, cityId, TheatreStatus.APPROVED, ShowStatus.SCHEDULED,
                day.atStartOfDay(), day.plusDays(1).atStartOfDay(), LocalDateTime.now());
        return list.stream().map(s -> mapper.show(s, showSeats.countByShowIdAndState(s.getId(), SeatState.AVAILABLE))).toList();
    }

    public SeatMap seatMap(Long showId) {
        Show show = shows.findById(showId).orElseThrow(() -> new NotFoundException("Show not found"));
        if (show.getScreen().getTheatre().getStatus() != TheatreStatus.APPROVED) throw new NotFoundException("Show not found");
        LocalDateTime now = LocalDateTime.now();
        List<ShowSeat> all = showSeats.findMap(showId);
        java.util.Map<String, Integer> rowIndex = new java.util.HashMap<>();
        all.stream().map(x -> x.getSeat().getRowLabel()).distinct().sorted().forEach(r -> rowIndex.put(r, rowIndex.size()));   // seats made before the designer existed
        List<SeatView> seats = all.stream().map(ss -> {
            SeatState st = ss.getState();
            if (st == SeatState.LOCKED && ss.getLockedUntil() != null && ss.getLockedUntil().isBefore(now)) st = SeatState.AVAILABLE;
            if (isBlocked(ss)) st = null;
            Seat s = ss.getSeat();
            String section = s.getSection() != null ? s.getSection() : s.getCategory().name();
            int gr = s.getGridRow() != null ? s.getGridRow() : rowIndex.get(s.getRowLabel());
            int gc = s.getGridCol() != null ? s.getGridCol() : s.getSeatNumber() - 1;
            return new SeatView(s.getId(), s.getRowLabel(), s.getSeatNumber(), s.label(), s.getCategory().name(), st == null ? "BLOCKED" : st.name(), ss.getPrice(), section, gr, gc);
        }).toList();
        long available = seats.stream().filter(s -> s.state().equals("AVAILABLE")).count();
        return new SeatMap(mapper.show(show, available), seats);
    }

    public record PublicShow(Long id, LocalDateTime startTime, String screenName, String audioLanguage, String dimension, List<String> formats,
                             java.math.BigDecimal minPrice, java.math.BigDecimal maxPrice, long available, long total, String availability) {}
    public record TheatreListing(Long theatreId, String theatre, String address, String city, List<String> facilities, boolean cancellable, List<PublicShow> shows) {}

    /** Theatres showing this movie in a city on a date, each with its show times, formats and availability. */
    public List<TheatreListing> listing(Long movieId, Long cityId, LocalDate date) {
        LocalDate day = date != null ? date : LocalDate.now();
        List<Show> list = shows.findBookable(movieId, cityId, TheatreStatus.APPROVED, ShowStatus.SCHEDULED, day.atStartOfDay(), day.plusDays(1).atStartOfDay(), LocalDateTime.now());
        java.util.Map<Long, List<Show>> byTheatre = new java.util.LinkedHashMap<>();
        for (Show s : list) byTheatre.computeIfAbsent(s.getScreen().getTheatre().getId(), k -> new java.util.ArrayList<>()).add(s);
        List<TheatreListing> out = new java.util.ArrayList<>();
        for (List<Show> group : byTheatre.values()) {
            Theatre t = group.get(0).getScreen().getTheatre();
            if (!withinWindow(t, day)) continue;                  // beyond this theatre's booking window: not open yet
            List<PublicShow> ps = new java.util.ArrayList<>();
            for (Show s : group) {
                Object[] pr = showSeats.priceRange(s.getId()).get(0);
                long total = pr[2] == null ? 0 : ((Number) pr[2]).longValue();
                long avail = showSeats.countByShowIdAndState(s.getId(), SeatState.AVAILABLE);
                String a = avail <= 0 ? "SOLD_OUT" : avail * 2 < total ? "FAST_FILLING" : "AVAILABLE";
                List<String> formats = s.getSpecialFormats() == null ? List.of() : java.util.Arrays.stream(s.getSpecialFormats().split(",")).map(String::trim).filter(x -> !x.isEmpty()).toList();
                ps.add(new PublicShow(s.getId(), s.getStartTime(), s.getScreen().getName(), s.getAudioLanguage(), s.getDimension(), formats,
                        (java.math.BigDecimal) pr[0], (java.math.BigDecimal) pr[1], avail, total, a));
            }
            List<String> fac = t.getFacilities() == null ? List.of() : java.util.Arrays.stream(t.getFacilities().split(",")).map(String::trim).filter(x -> !x.isEmpty()).toList();
            out.add(new TheatreListing(t.getId(), t.getName(), t.getAddress(), t.getCity() == null ? "" : t.getCity().getName(), fac, t.isCancellable(), ps));
        }
        return out;
    }

    /** A theatre lets customers book today and the next (window - 1) days only; the window slides forward every day. */
    public static boolean withinWindow(Theatre t, LocalDate day) {
        LocalDate today = LocalDate.now();
        return !day.isBefore(today) && !day.isAfter(today.plusDays(t.windowDays() - 1L));
    }

    /**
     * The dates a customer can pick for a movie: for every theatre (in the given city / district / state, or anywhere when null) that is
     * running it, each day from today until the earlier of the theatre's booking window and the run's end date. Slides forward daily.
     */
    public List<LocalDate> bookingDates(Long movieId, Long locationId) {
        LocalDate today = LocalDate.now();
        java.util.TreeSet<LocalDate> days = new java.util.TreeSet<>();
        for (TheatreMovie r : runs.findOpenRuns(movieId, today, locationId)) {
            LocalDate from = r.getStartDate().isAfter(today) ? r.getStartDate() : today;
            LocalDate windowEnd = today.plusDays(r.getTheatre().windowDays() - 1L);
            LocalDate to = r.getEndDate().isBefore(windowEnd) ? r.getEndDate() : windowEnd;
            for (LocalDate d = from; !d.isAfter(to); d = d.plusDays(1)) days.add(d);
        }
        return new ArrayList<>(days);
    }

    public record MovieAvailability(Long movieId, long shows) {}

    /** Movies that really have future shows at approved theatres in the chosen place (any one of city / district / state may be given). */
    public List<MovieAvailability> availableMovies(Long cityId, Long districtId, Long stateId) {
        return shows.availableMovies(cityId, districtId, stateId, LocalDateTime.now()).stream()
                .map(r -> new MovieAvailability(((Number) r[0]).longValue(), ((Number) r[1]).longValue())).toList();
    }

    /** A seat the theatre keeps back: LOCKED with no booking and a lock that never expires. */
    public static boolean isBlocked(ShowSeat ss) {
        return ss.getState() == SeatState.LOCKED && ss.getBooking() == null && ss.getLockedUntil() != null && ss.getLockedUntil().getYear() >= 9000;
    }
}
