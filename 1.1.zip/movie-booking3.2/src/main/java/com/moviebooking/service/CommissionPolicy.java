package com.moviebooking.service;

import com.moviebooking.entity.Screen;
import com.moviebooking.entity.Theatre;
import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Abstraction for commission rules. Commission basis (Stage 1 rule): the ticket amount only.
 * There are no taxes, convenience fees or discounts in the data model yet, so none are in the basis.
 */
public interface CommissionPolicy {
    BigDecimal effectiveRate(Screen screen);

    BigDecimal effectiveRate(Theatre theatre);

    default BigDecimal commission(BigDecimal basis, BigDecimal ratePercent) {
        return basis.multiply(ratePercent).divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
    }
}
