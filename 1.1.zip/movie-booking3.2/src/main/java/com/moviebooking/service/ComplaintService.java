package com.moviebooking.service;

import com.moviebooking.entity.*;
import com.moviebooking.enums.Role;
import com.moviebooking.exception.*;
import com.moviebooking.repository.*;
import java.time.LocalDateTime;
import java.util.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Complaints: customer -> website, customer -> theatre, theatre -> Super Admin. Each goes to the right handler only. */
@Service
@RequiredArgsConstructor
public class ComplaintService {
    private final ComplaintRepository complaints;
    private final TheatreRepository theatres;
    private final BookingRepository bookings;
    private final NotificationService notifications;
    private final AuditService audit;

    public record ComplaintRequest(String type, Long theatreId, String bookingReference, String subject, String message) {}
    public record ComplaintView(Long id, String type, String from, String fromRole, String theatre, String bookingReference, String subject, String message,
                                String status, String response, String respondedBy, LocalDateTime respondedAt, LocalDateTime createdAt) {}

    private ComplaintView view(Complaint c) {
        return new ComplaintView(c.getId(), c.getType(), c.getCreatedBy().getName(), c.getRaisedAsRole(), c.getTheatre() == null ? null : c.getTheatre().getName(),
                c.getBookingReference(), c.getSubject(), c.getMessage(), c.getStatus(), c.getResponse(), c.getRespondedBy(), c.getRespondedAt(), c.getCreatedAt());
    }

    @Transactional
    public ComplaintView raise(User user, Theatre ownTheatre, ComplaintRequest r) {
        if (r.subject() == null || r.subject().trim().length() < 4) throw new BadRequestException("Add a short subject");
        if (r.message() == null || r.message().trim().length() < 10) throw new BadRequestException("Describe the problem in a few words (at least 10 characters)");
        if (complaints.countByCreatedByIdAndStatusIn(user.getId(), List.of("OPEN", "IN_PROGRESS")) >= 5)
            throw new BadRequestException("You already have 5 open complaints. Please wait for a response.");
        Complaint c = new Complaint();
        c.setCreatedBy(user); c.setRaisedAsRole(user.getRole().name());
        c.setSubject(r.subject().trim()); c.setMessage(r.message().trim());
        if (user.getRole() == Role.THEATRE_ADMIN) {
            c.setType("ADMIN"); c.setTheatre(ownTheatre);
            notifications.notifySuperAdmins("New complaint from theatre " + ownTheatre.getName() + ": " + c.getSubject());
        } else if ("THEATRE".equalsIgnoreCase(r.type())) {
            if (r.bookingReference() == null || r.bookingReference().isBlank()) throw new BadRequestException("Choose the booking this complaint is about");
            Booking bk = bookings.findByReference(r.bookingReference().trim()).orElseThrow(() -> new NotFoundException("Booking not found"));
            if (!bk.getCustomer().getId().equals(user.getId())) throw new ForbiddenException("Not your booking");
            Theatre t = bk.getShow().getScreen().getTheatre();
            c.setType("THEATRE"); c.setTheatre(t); c.setBookingReference(bk.getReference());
            notifications.notify(t.getOwner(), "New complaint from a customer: " + c.getSubject());
        } else {
            c.setType("PLATFORM");
            notifications.notifySuperAdmins("New customer complaint about the website: " + c.getSubject());
        }
        complaints.save(c);
        return view(c);
    }

    @Transactional(readOnly = true)
    public List<ComplaintView> mine(User u) { return complaints.findMine(u.getId()).stream().map(this::view).toList(); }

    /** Theatre admin: complaints about their theatre. Super Admin: website + theatre-to-admin complaints, plus customer-to-theatre ones when includeTheatre is true. */
    @Transactional(readOnly = true)
    public List<ComplaintView> inbox(User u, Theatre ownTheatre, boolean includeTheatre) {
        List<Complaint> list = u.getRole() == Role.THEATRE_ADMIN ? complaints.findForTheatre(ownTheatre.getId())
                : complaints.findByTypes(includeTheatre ? List.of("PLATFORM", "ADMIN", "THEATRE") : List.of("PLATFORM", "ADMIN"));
        return list.stream().map(this::view).toList();
    }

    @Transactional
    public ComplaintView respond(User u, Theatre ownTheatre, Long id, String status, String response) {
        Complaint c = complaints.findById(id).orElseThrow(() -> new NotFoundException("Complaint not found"));
        if (u.getRole() == Role.THEATRE_ADMIN && !("THEATRE".equals(c.getType()) && c.getTheatre() != null && c.getTheatre().getId().equals(ownTheatre.getId())))
            throw new ForbiddenException("This complaint is not for your theatre");
        if (!List.of("IN_PROGRESS", "RESOLVED", "CLOSED").contains(status)) throw new BadRequestException("Status must be IN_PROGRESS, RESOLVED or CLOSED");
        if (response == null || response.trim().length() < 3) throw new BadRequestException("Write a reply for the customer");
        c.setStatus(status); c.setResponse(response.trim()); c.setRespondedBy(u.getName()); c.setRespondedAt(LocalDateTime.now());
        notifications.notify(c.getCreatedBy(), "Your complaint '" + c.getSubject() + "' was updated: " + status.replace('_', ' ').toLowerCase());
        audit.log(u.getEmail(), "COMPLAINT_" + status, "complaint " + id);
        return view(c);
    }
}
