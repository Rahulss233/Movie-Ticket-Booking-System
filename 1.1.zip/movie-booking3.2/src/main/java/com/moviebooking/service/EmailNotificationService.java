package com.moviebooking.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

/** Optional SMTP notifications. Disabled by default; never reports delivery when SMTP is unavailable. */
@Service
@Slf4j
public class EmailNotificationService {
    private final ObjectProvider<JavaMailSender> senderProvider;
    @Value("${app.email.enabled:false}") private boolean enabled;
    @Value("${app.email.from:noreply@cinebook.local}") private String from;

    public EmailNotificationService(ObjectProvider<JavaMailSender> senderProvider) { this.senderProvider = senderProvider; }

    public boolean send(String to, String subject, String body) {
        if (!enabled || to == null || to.isBlank()) return false;
        JavaMailSender sender = senderProvider.getIfAvailable();
        if (sender == null) { log.warn("Email is enabled but no mail sender is configured; message not sent"); return false; }
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(from); message.setTo(to); message.setSubject(subject); message.setText(body);
            sender.send(message);
            return true;
        } catch (Exception ex) {
            log.warn("Email delivery failed for {}: {}", to, ex.getMessage());
            return false;
        }
    }
}
