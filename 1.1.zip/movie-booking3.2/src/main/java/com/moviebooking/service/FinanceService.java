package com.moviebooking.service;

import com.moviebooking.entity.*;
import com.moviebooking.exception.BadRequestException;
import com.moviebooking.repository.BookingRepository;
import com.moviebooking.repository.PaymentRepository;
import java.math.BigDecimal;
import java.time.*;
import java.time.format.TextStyle;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Location- and time-scoped finance and analytics, used by both the Super Admin (any scope) and the Theatre Admin
 * (the controller always forces the scope to the owner's own theatre).
 *
 * Time basis: CREATED = when the booking / payment was created; SHOW = the show's start time.
 * Payment metrics (collected / failed / pending) always use the payment creation time.
 * Settlement (payout) records do not exist yet, so earnings are reported as "pending" and "completed" is always empty.
 */
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class FinanceService {
    private final BookingRepository bookings;
    private final PaymentRepository payments;

    public record Scope(Long stateId, Long districtId, Long cityId, Long theatreId, LocalDate from, LocalDate to,
                        LocalTime fromTime, LocalTime toTime, String basis) {
        Scope withTheatre(Long id) { return new Scope(null, null, null, id, from, to, fromTime, toTime, basis); }
        Scope shifted(LocalDate f, LocalDate t) { return new Scope(stateId, districtId, cityId, theatreId, f, t, fromTime, toTime, basis); }
    }

    public record FinRow(String kind, Long id, String reference, String transactionRef, Long stateId, String state, Long districtId, String district,
                         Long cityId, String city, Long theatreId, String theatre, String movie, String language, String screen,
                         LocalDateTime showTime, LocalDateTime createdAt, BigDecimal amount, BigDecimal commissionRate, BigDecimal commissionAmount,
                         BigDecimal theatrePayable, BigDecimal refundAmount, String bookingStatus, String paymentStatus, String message,
                         String customer, int tickets) {}

    public record Page(long total, int page, int size, BigDecimal totalValue, List<FinRow> rows) {}
    public record Group(String key, Long id, String label, long bookings, long tickets, BigDecimal gross, BigDecimal commission, BigDecimal earnings) {}

    // ------------------------------------------------------------------ data loading
    private static BigDecimal z(BigDecimal v) { return v == null ? BigDecimal.ZERO : v; }

    private boolean inTimeOfDay(LocalDateTime t, Scope s) {
        if (s.fromTime() == null || s.toTime() == null || t == null) return true;
        LocalTime x = t.toLocalTime();
        return s.fromTime().isAfter(s.toTime()) ? (!x.isBefore(s.fromTime()) || !x.isAfter(s.toTime())) : (!x.isBefore(s.fromTime()) && !x.isAfter(s.toTime()));
    }

    private void check(Scope s) {
        if (s.from() == null || s.to() == null) throw new BadRequestException("Choose a start and end date");
        if (s.to().isBefore(s.from())) throw new BadRequestException("End date is before start date");
        if (s.from().plusYears(5).isBefore(s.to())) throw new BadRequestException("Date range is too long (max 5 years)");
    }

    private List<Booking> loadBookings(Scope s) {
        check(s);
        LocalDateTime f = s.from().atStartOfDay(), t = s.to().plusDays(1).atStartOfDay();
        boolean show = "SHOW".equalsIgnoreCase(s.basis());
        List<Booking> list = show ? bookings.financeByShowTime(s.stateId(), s.districtId(), s.cityId(), s.theatreId(), f, t)
                : bookings.financeByCreated(s.stateId(), s.districtId(), s.cityId(), s.theatreId(), f, t);
        return list.stream().filter(b -> inTimeOfDay(show ? b.getShow().getStartTime() : b.getCreatedAt(), s)).toList();
    }

    private List<Payment> loadPayments(Scope s) {
        check(s);
        return payments.financeByCreated(s.stateId(), s.districtId(), s.cityId(), s.theatreId(), s.from().atStartOfDay(), s.to().plusDays(1).atStartOfDay())
                .stream().filter(p -> inTimeOfDay(p.getCreatedAt(), s)).toList();
    }

    private FinRow row(Booking b) {
        Show sh = b.getShow(); Theatre t = sh.getScreen().getTheatre(); Location c = t.getCity(), d = c.getParent(), st = d == null ? null : d.getParent();
        int tickets = b.getSeatLabels() == null || b.getSeatLabels().isBlank() ? 0 : b.getSeatLabels().split(",").length;
        return new FinRow("BOOKING", b.getId(), b.getReference(), null, st == null ? null : st.getId(), st == null ? "" : st.getName(), d == null ? null : d.getId(), d == null ? "" : d.getName(),
                c.getId(), c.getName(), t.getId(), t.getName(), sh.getMovie().getTitle(), sh.getMovie().getLanguage(), sh.getScreen().getName(), sh.getStartTime(), b.getCreatedAt(),
                z(b.getTotalAmount()), b.getCommissionRate(), b.getCommissionAmount(), b.getTheatrePayable(), b.getRefundAmount(), b.getStatus().name(), b.getPaymentStatus().name(),
                b.getRefundStatus(), b.getCustomer().getName(), tickets);
    }

    private FinRow row(Payment p) {
        FinRow r = row(p.getBooking());
        return new FinRow("PAYMENT", p.getId(), r.reference(), p.getTransactionRef(), r.stateId(), r.state(), r.districtId(), r.district(), r.cityId(), r.city(), r.theatreId(), r.theatre(),
                r.movie(), r.language(), r.screen(), r.showTime(), p.getCreatedAt(), z(p.getAmount()), null, null, null, null, r.bookingStatus(), p.getStatus().name(), p.getMessage(), r.customer(), 0);
    }

    /** Every metric as the list of records behind it. */
    private Map<String, List<FinRow>> build(Scope s) {
        List<FinRow> bk = loadBookings(s).stream().map(this::row).toList();
        List<FinRow> pay = loadPayments(s).stream().map(this::row).toList();
        List<FinRow> conf = bk.stream().filter(r -> "CONFIRMED".equals(r.bookingStatus())).toList();
        List<FinRow> earn = conf.stream().filter(r -> r.theatrePayable() != null).toList();
        List<FinRow> refunds = bk.stream().filter(r -> z(r.refundAmount()).signum() > 0).toList();
        Map<String, List<FinRow>> m = new LinkedHashMap<>();
        m.put("gross", conf); m.put("bookings", conf); m.put("tickets", conf); m.put("avgTicket", conf); m.put("net", conf);
        m.put("cancelled", bk.stream().filter(r -> "CANCELLED".equals(r.bookingStatus())).toList());
        m.put("commission", conf.stream().filter(r -> r.commissionAmount() != null).toList());
        m.put("earnings", earn); m.put("payoutsPending", earn); m.put("payoutsCompleted", List.of());
        m.put("refundsRequested", refunds);
        m.put("refundsPending", refunds.stream().filter(r -> "REFUND_PENDING".equals(r.paymentStatus())).toList());
        m.put("refundsCompleted", refunds.stream().filter(r -> "REFUNDED".equals(r.paymentStatus())).toList());
        m.put("collected", pay.stream().filter(r -> "SUCCESS".equals(r.paymentStatus())).toList());
        m.put("failed", pay.stream().filter(r -> "FAILED".equals(r.paymentStatus())).toList());
        m.put("pending", pay.stream().filter(r -> "PENDING".equals(r.paymentStatus())).toList());
        return m;
    }

    private static BigDecimal value(String metric, List<FinRow> rows) {
        BigDecimal sum = BigDecimal.ZERO;
        switch (metric) {
            case "bookings" -> sum = BigDecimal.valueOf(rows.size());
            case "tickets" -> sum = BigDecimal.valueOf(rows.stream().mapToInt(FinRow::tickets).sum());
            case "avgTicket" -> { int t = rows.stream().mapToInt(FinRow::tickets).sum(); BigDecimal g = rows.stream().map(r -> z(r.amount())).reduce(BigDecimal.ZERO, BigDecimal::add);
                sum = t == 0 ? BigDecimal.ZERO : g.divide(BigDecimal.valueOf(t), 2, java.math.RoundingMode.HALF_UP); }
            case "commission" -> sum = rows.stream().map(r -> z(r.commissionAmount())).reduce(BigDecimal.ZERO, BigDecimal::add);
            case "earnings", "payoutsPending", "payoutsCompleted" -> sum = rows.stream().map(r -> z(r.theatrePayable())).reduce(BigDecimal.ZERO, BigDecimal::add);
            case "refundsRequested", "refundsPending", "refundsCompleted" -> sum = rows.stream().map(r -> z(r.refundAmount())).reduce(BigDecimal.ZERO, BigDecimal::add);
            default -> sum = rows.stream().map(r -> z(r.amount())).reduce(BigDecimal.ZERO, BigDecimal::add);
        }
        return sum;
    }

    private Map<String, Map<String, Object>> metrics(Scope s) {
        Map<String, List<FinRow>> all = build(s);
        Map<String, Map<String, Object>> out = new LinkedHashMap<>();
        BigDecimal gross = value("gross", all.get("gross")), refunds = value("refundsRequested", all.get("refundsRequested"));
        all.forEach((k, rows) -> {
            Map<String, Object> e = new LinkedHashMap<>();
            e.put("count", rows.size());
            e.put("value", "net".equals(k) ? gross.subtract(refunds) : value(k, rows));
            out.put(k, e);
        });
        return out;
    }

    // ------------------------------------------------------------------ public API
    public Map<String, Object> summary(Scope s, boolean compare) {
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("metrics", metrics(s));
        if (compare) {
            long days = java.time.temporal.ChronoUnit.DAYS.between(s.from(), s.to()) + 1;
            LocalDate pt = s.from().minusDays(1), pf = pt.minusDays(days - 1);
            out.put("previous", metrics(s.shifted(pf, pt)));
            out.put("previousRange", pf + " to " + pt);
        }
        out.put("timeBasis", "SHOW".equalsIgnoreCase(s.basis()) ? "Show start time" : "Booking / payment creation time");
        out.put("note", "Payout (settlement) records are not tracked yet: theatre earnings are shown as pending and completed payouts as zero.");
        return out;
    }

    public Page records(Scope s, String metric, String q, String sort, boolean asc, int page, int size) {
        List<FinRow> rows = build(s).get(metric);
        if (rows == null) throw new BadRequestException("Unknown metric: " + metric);
        String needle = q == null ? "" : q.trim().toLowerCase(Locale.ROOT);
        List<FinRow> f = rows.stream().filter(r -> needle.isEmpty() || (String.join(" ", nz(r.reference()), nz(r.transactionRef()), nz(r.theatre()), nz(r.movie()), nz(r.customer()), nz(r.city()))).toLowerCase(Locale.ROOT).contains(needle)).collect(Collectors.toList());
        Comparator<FinRow> cmp = switch (sort == null ? "" : sort) {
            case "amount" -> Comparator.comparing(r -> z(r.amount()));
            case "theatre" -> Comparator.comparing(r -> nz(r.theatre()).toLowerCase(Locale.ROOT));
            case "showTime" -> Comparator.comparing(r -> r.showTime() == null ? LocalDateTime.MIN : r.showTime());
            default -> Comparator.comparing(r -> r.createdAt() == null ? LocalDateTime.MIN : r.createdAt());
        };
        f.sort(asc ? cmp : cmp.reversed());
        int sz = Math.min(Math.max(size, 1), 1000), pg = Math.max(page, 0), from = Math.min(pg * sz, f.size());
        return new Page(f.size(), pg, sz, value(metric, f), f.subList(from, Math.min(from + sz, f.size())));
    }

    /** Groups confirmed bookings. by = auto | state | district | city | theatre | movie | language | screen | day | month | hour | weekday */
    public List<Group> breakdown(Scope s, String by) {
        String mode = by == null || by.isBlank() || "auto".equals(by) ? (s.theatreId() != null ? "movie" : s.cityId() != null ? "theatre" : s.districtId() != null ? "city" : s.stateId() != null ? "district" : "state") : by;
        List<FinRow> conf = build(s).get("gross");
        Function<FinRow, String[]> key = switch (mode) {
            case "state" -> r -> new String[]{String.valueOf(r.stateId()), r.state()};
            case "district" -> r -> new String[]{String.valueOf(r.districtId()), r.district()};
            case "city" -> r -> new String[]{String.valueOf(r.cityId()), r.city()};
            case "theatre" -> r -> new String[]{String.valueOf(r.theatreId()), r.theatre()};
            case "movie" -> r -> new String[]{r.movie(), r.movie()};
            case "language" -> r -> new String[]{r.language(), r.language()};
            case "screen" -> r -> new String[]{r.screen(), r.screen()};
            case "day" -> r -> new String[]{String.valueOf(r.createdAt().toLocalDate()), String.valueOf(r.createdAt().toLocalDate())};
            case "month" -> r -> { String m = r.createdAt().getYear() + "-" + String.format("%02d", r.createdAt().getMonthValue()); return new String[]{m, m}; };
            case "hour" -> r -> { String h = String.format("%02d:00", r.showTime() == null ? 0 : r.showTime().getHour()); return new String[]{h, h}; };
            case "weekday" -> r -> { DayOfWeek d = r.showTime() == null ? DayOfWeek.MONDAY : r.showTime().getDayOfWeek(); return new String[]{String.valueOf(d.getValue()), d.getDisplayName(TextStyle.FULL, Locale.ENGLISH)}; };
            default -> throw new BadRequestException("Unknown grouping: " + by);
        };
        Map<String, List<FinRow>> g = new LinkedHashMap<>();
        Map<String, String> labels = new HashMap<>();
        for (FinRow r : conf) { String[] k = key.apply(r); g.computeIfAbsent(k[0], x -> new ArrayList<>()).add(r); labels.put(k[0], k[1]); }
        boolean timeline = List.of("day", "month", "hour", "weekday").contains(mode);
        List<Group> out = g.entrySet().stream().map(e -> {
            List<FinRow> rs = e.getValue();
            Long id = List.of("state", "district", "city", "theatre").contains(mode) && !"null".equals(e.getKey()) ? Long.valueOf(e.getKey()) : null;
            return new Group(e.getKey(), id, labels.get(e.getKey()), rs.size(), rs.stream().mapToInt(FinRow::tickets).sum(), value("gross", rs), value("commission", rs), value("earnings", rs));
        }).collect(Collectors.toList());
        Comparator<Group> order = timeline ? Comparator.comparing(Group::key) : Comparator.comparing(Group::gross, Comparator.reverseOrder());
        out.sort(order);
        return out;
    }

    private static String nz(String s) { return s == null ? "" : s; }
}
