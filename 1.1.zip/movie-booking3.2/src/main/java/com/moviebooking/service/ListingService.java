package com.moviebooking.service;

import com.moviebooking.entity.*;
import com.moviebooking.enums.MovieStatus;
import com.moviebooking.exception.*;
import com.moviebooking.repository.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * A theatre puts a movie on its screens for a date window (start and end are both required when adding).
 * No Super Admin approval is needed. Removing a movie keeps the row (that is the history) and cancels its upcoming shows with refunds.
 */
@Service
@RequiredArgsConstructor
public class ListingService {
    private final TheatreMovieRepository listings;
    private final MovieRepository movies;
    private final ShowRepository shows;
    private final ShowService showService;
    private final TheatreService theatreService;
    private final AuditService audit;

    public record ListingRequest(Long movieId, LocalDate startDate, LocalDate endDate) {}
    public record ListingUpdate(LocalDate endDate) {}
    public record ListingView(Long id, Long movieId, String title, String posterUrl, String language, LocalDate startDate, LocalDate endDate, String status,
                              LocalDateTime addedAt, String addedBy, LocalDateTime removedAt, String removedBy, String removeReason, int upcomingShows, int durationMinutes) {}

    private ListingView view(TheatreMovie t) {
        LocalDate today = LocalDate.now();
        String st = t.getRemovedAt() != null ? "REMOVED" : t.getEndDate().isBefore(today) ? "ENDED" : t.getStartDate().isAfter(today) ? "UPCOMING" : "RUNNING";
        int up = t.getRemovedAt() != null ? 0 : shows.findUpcomingForMovie(t.getTheatre().getId(), t.getMovie().getId(), LocalDateTime.now()).size();
        return new ListingView(t.getId(), t.getMovie().getId(), t.getMovie().getTitle(), t.getMovie().getPosterUrl(), t.getMovie().getLanguage(), t.getStartDate(), t.getEndDate(), st,
                t.getCreatedAt(), t.getAddedBy(), t.getRemovedAt(), t.getRemovedBy(), t.getRemoveReason(), up, t.getMovie().getDurationMinutes());
    }

    @Transactional(readOnly = true)
    public List<ListingView> list(User owner, boolean historyOnly) {
        Theatre t = theatreService.requireOwned(owner);
        return listings.findAllForTheatre(t.getId()).stream().map(this::view)
                .filter(v -> historyOnly ? ("REMOVED".equals(v.status()) || "ENDED".equals(v.status())) : !("REMOVED".equals(v.status()) || "ENDED".equals(v.status()))).toList();
    }

    @Transactional
    public ListingView add(User owner, ListingRequest r) {
        Theatre t = theatreService.requireApproved(owner);
        if (r.movieId() == null) throw new BadRequestException("Choose a movie");
        if (r.startDate() == null || r.endDate() == null) throw new BadRequestException("Start date and end date are both required");
        if (r.startDate().isBefore(LocalDate.now())) throw new BadRequestException("Start date cannot be in the past");
        if (r.endDate().isBefore(r.startDate())) throw new BadRequestException("End date must be on or after the start date");
        if (r.startDate().plusDays(366).isBefore(r.endDate())) throw new BadRequestException("A run can be at most one year; you can extend it later");
        Movie m = movies.findById(r.movieId()).orElseThrow(() -> new NotFoundException("Movie not found"));
        if (m.getStatus() == MovieStatus.ARCHIVED || m.getStatus() == MovieStatus.PENDING_REVIEW) throw new BadRequestException("This movie is not available in the catalogue");
        if (listings.countOverlapping(t.getId(), m.getId(), r.startDate(), r.endDate(), null) > 0)
            throw new ConflictException("This movie is already on your screens for those dates. Edit its end date instead.");
        TheatreMovie tm = new TheatreMovie();
        tm.setTheatre(t); tm.setMovie(m); tm.setStartDate(r.startDate()); tm.setEndDate(r.endDate()); tm.setAddedBy(owner.getEmail());
        listings.save(tm);
        audit.log(owner.getEmail(), "THEATRE_MOVIE_ADDED", t.getName() + ": " + m.getTitle() + " " + r.startDate() + " to " + r.endDate());
        return view(tm);
    }

    /** The end date is optional when updating: leave it empty to keep it. */
    @Transactional
    public ListingView update(User owner, Long id, ListingUpdate r) {
        Theatre t = theatreService.requireApproved(owner);
        TheatreMovie tm = listings.findById(id).orElseThrow(() -> new NotFoundException("Listing not found"));
        if (!tm.getTheatre().getId().equals(t.getId())) throw new ForbiddenException("Not your listing");
        if (tm.getRemovedAt() != null) throw new BadRequestException("This movie was removed. Add it again to restart.");
        if (r.endDate() != null && !r.endDate().equals(tm.getEndDate())) {
            if (r.endDate().isBefore(tm.getStartDate())) throw new BadRequestException("End date must be on or after the start date");
            if (r.endDate().isBefore(tm.getEndDate())) {
                long late = shows.findUpcomingForMovie(t.getId(), tm.getMovie().getId(), LocalDateTime.now()).stream().filter(s -> s.getStartTime().toLocalDate().isAfter(r.endDate())).count();
                if (late > 0) throw new ConflictException(late + " scheduled show(s) fall after that date. Cancel them first, or choose a later end date.");
            }
            if (listings.countOverlapping(t.getId(), tm.getMovie().getId(), tm.getStartDate(), r.endDate(), tm.getId()) > 0) throw new ConflictException("That overlaps another run of this movie");
            tm.setEndDate(r.endDate());
            audit.log(owner.getEmail(), "THEATRE_MOVIE_END_CHANGED", t.getName() + ": " + tm.getMovie().getTitle() + " now ends " + r.endDate());
        }
        return view(tm);
    }

    @Transactional
    public ListingView remove(User owner, Long id, String reason) {
        Theatre t = theatreService.requireApproved(owner);
        TheatreMovie tm = listings.findById(id).orElseThrow(() -> new NotFoundException("Listing not found"));
        if (!tm.getTheatre().getId().equals(t.getId())) throw new ForbiddenException("Not your listing");
        if (tm.getRemovedAt() != null) throw new BadRequestException("Already removed");
        if (reason == null || reason.trim().length() < 3) throw new BadRequestException("Give a short reason for removing the movie");
        String why = reason.trim().length() > 280 ? reason.trim().substring(0, 280) : reason.trim();
        int cancelled = showService.cancelUpcomingForMovie(t, tm.getMovie().getId(), "Movie removed by the theatre: " + why);
        tm.setRemovedAt(LocalDateTime.now()); tm.setRemovedBy(owner.getEmail()); tm.setRemoveReason(why);
        audit.log(owner.getEmail(), "THEATRE_MOVIE_REMOVED", t.getName() + ": " + tm.getMovie().getTitle() + " (" + cancelled + " shows cancelled) " + why);
        return view(tm);
    }
}
