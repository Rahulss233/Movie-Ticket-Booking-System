package com.moviebooking.service;

import com.moviebooking.entity.Booking;
import java.util.UUID;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

/** TEST MODE ONLY. No money moves. Enabled only when app.payment.mode=mock. */
@Component
@ConditionalOnProperty(name = "app.payment.mode", havingValue = "mock")
public class MockPaymentGateway implements PaymentGateway {
    @Override
    public String mode() { return "MOCK"; }

    @Override
    public PaymentResult charge(Booking booking, boolean simulateFailure) {
        if (simulateFailure) return new PaymentResult(false, null, "Mock payment declined (test mode)");
        return new PaymentResult(true, "MOCK-" + UUID.randomUUID(), "Mock payment accepted (test mode)");
    }
}
