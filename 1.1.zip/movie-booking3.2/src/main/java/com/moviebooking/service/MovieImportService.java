package com.moviebooking.service;

import com.moviebooking.entity.Movie;
import com.moviebooking.entity.MovieImportRun;
import com.moviebooking.enums.MovieStatus;
import com.moviebooking.exception.BadRequestException;
import com.moviebooking.repository.MovieImportRunRepository;
import com.moviebooking.repository.MovieRepository;
import com.moviebooking.service.metadata.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Automatic movie entry. Each provider is run independently (one failing never blocks the others).
 * A record that passes every validation rule is published automatically (UPCOMING, or ACTIVE if already released);
 * anything else waits in the Super Admin review queue with the exact reason.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class MovieImportService {
    public static final String AUTO = "Auto-published";

    private final List<MovieMetadataProvider> providers;
    private final MovieRepository movies;
    private final MovieImportRunRepository runs;
    private final NotificationService notifications;
    private final OmdbEnricher omdb;
    @Value("${app.movies.import-enabled:true}") private boolean enabled;
    @Value("${app.movies.auto-publish:true}") private boolean autoPublish;
    @Value("${app.movies.import-on-startup:true}") private boolean startupImport;
    @Value("${app.movies.min-description-length:40}") private int minDescription;
    @Value("${app.movies.providers:tmdb,wikidata}") private String providerOrder;

    private List<MovieMetadataProvider> ordered() {
        List<String> order = Arrays.stream(providerOrder.split(",")).map(s -> s.trim().toUpperCase(Locale.ROOT)).toList();
        return providers.stream().filter(p -> order.contains(p.name())).sorted(Comparator.comparingInt(p -> order.indexOf(p.name()))).toList();
    }

    /** Releases move from Coming soon to Now showing on their release date. */
    @Scheduled(cron = "0 5 0 * * *")
    @Transactional
    public void promoteReleasedMovies() {
        movies.findByStatusAndReleaseDateLessThanEqual(MovieStatus.UPCOMING, LocalDate.now()).forEach(m -> m.setStatus(MovieStatus.ACTIVE));
    }

    /** After startup, fetch movies once in the background (if none was fetched in the last 20 hours) so nobody has to click anything. */
    @org.springframework.context.event.EventListener(org.springframework.boot.context.event.ApplicationReadyEvent.class)
    public void importOnStartup() {
        if (!enabled || !startupImport) return;
        Thread t = new Thread(() -> {
            try {
                boolean recent = runs.findTop30ByOrderByStartedAtDesc().stream().anyMatch(r -> r.isSuccess() && r.getStartedAt().isAfter(LocalDateTime.now().minusHours(20)));
                if (!recent) runAll("STARTUP", null);
            } catch (Exception e) { log.warn("Startup movie import skipped: {}", e.getMessage()); }
        }, "movie-import-startup");
        t.setDaemon(true);
        t.start();
    }

    @Scheduled(cron = "${app.movies.import-cron:0 30 3 * * *}")
    public void scheduledImport() { if (enabled) runAll("SCHEDULED", null); }

    /** Hourly: re-run any provider whose latest run failed in the last 12 hours (transient network or provider errors). */
    @Scheduled(fixedDelay = 3_600_000L, initialDelay = 600_000L)
    public void retryFailed() {
        if (!enabled) return;
        for (MovieMetadataProvider p : ordered()) {
            if (!p.isConfigured()) continue;
            runs.findFirstByProviderOrderByStartedAtDesc(p.name()).filter(r -> !r.isSuccess() && r.getStartedAt().isAfter(LocalDateTime.now().minusHours(12)))
                    .ifPresent(r -> runAll("RETRY", p.name()));
        }
    }

    public List<MovieImportRun> runAll(String trigger, String only) {
        List<MovieImportRun> done = new ArrayList<>();
        for (MovieMetadataProvider p : ordered()) {
            if (only != null && !p.name().equalsIgnoreCase(only)) continue;
            if (!p.isConfigured()) { if (only != null) throw new BadRequestException(p.name() + " is not configured"); continue; }
            done.add(runProvider(p, trigger));
        }
        if (only != null && done.isEmpty()) throw new BadRequestException("Unknown provider: " + only);
        int review = done.stream().mapToInt(MovieImportRun::getSentToReview).sum();
        int auto = done.stream().mapToInt(MovieImportRun::getAutoPublished).sum();
        if (auto > 0) notifications.notifySuperAdmins("Movie import: " + auto + " movies were published automatically.");
        if (review > 0) notifications.notifySuperAdmins("Movie import: " + review + " new movies need your review.");
        done.stream().filter(r -> !r.isSuccess()).forEach(r -> notifications.notifySuperAdmins("Movie import failed for " + r.getProvider() + ": " + r.getErrorMessage()));
        return done;
    }

    private MovieImportRun runProvider(MovieMetadataProvider p, String trigger) {
        MovieImportRun run = new MovieImportRun();
        run.setProvider(p.name()); run.setTriggerType(trigger); run.setStartedAt(LocalDateTime.now());
        try {
            List<ImportedMovie> list = p.fetchUpcoming();
            run.setFetched(list.size());
            for (ImportedMovie im : list) {
                try { apply(im, run); }
                catch (Exception e) { run.setFailed(run.getFailed() + 1); log.warn("Skipped one {} record: {}", p.name(), e.getMessage()); }
            }
            run.setSuccess(true);
        } catch (Exception e) {
            run.setSuccess(false);
            String msg = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
            run.setErrorMessage(msg.length() > 450 ? msg.substring(0, 450) : msg);
            log.warn("Movie import failed for {}: {}", p.name(), msg);
        }
        run.setFinishedAt(LocalDateTime.now());
        return runs.save(run);
    }

    private void apply(ImportedMovie im, MovieImportRun run) {
        omdb.enrich(im);
        LocalDate today = LocalDate.now();
        List<String> problems = validate(im, today);
        Optional<Movie> existing = movies.findByExternalSourceAndExternalId(im.getSource(), im.getExternalId());
        Movie m;
        if (existing.isPresent()) {
            m = existing.get();
            boolean ours = m.getReviewNote() != null && m.getReviewNote().startsWith(AUTO) && (m.getStatus() == MovieStatus.UPCOMING || m.getStatus() == MovieStatus.ACTIVE);
            if (m.getStatus() != MovieStatus.PENDING_REVIEW && !ours) return; // human-managed record: never overwritten
            run.setUpdated(run.getUpdated() + 1);
        } else {
            if (im.getTitle() == null || im.getTitle().isBlank()) return;
            String lang = im.getLanguage() == null ? "" : im.getLanguage();
            boolean duplicate = movies.findByTitleIgnoreCaseAndLanguageIgnoreCase(im.getTitle().trim(), lang).stream().anyMatch(x -> sameFilm(x, im));
            if (duplicate) { run.setDuplicates(run.getDuplicates() + 1); return; }
            m = new Movie();
            run.setCreated(run.getCreated() + 1);
        }
        m.setExternalSource(im.getSource()); m.setExternalId(im.getExternalId());
        m.setTitle(cut(im.getTitle().trim(), 200)); m.setDescription(cut(im.getDescription(), 2000)); m.setPosterUrl(cut(im.getPosterUrl(), 500));
        m.setGenre(cut(im.getGenre() == null ? "Unspecified" : im.getGenre(), 100));
        m.setLanguage(cut(im.getLanguage() == null ? "Unknown" : im.getLanguage(), 50));
        m.setDurationMinutes(im.getRuntimeMinutes() == null ? 0 : im.getRuntimeMinutes());
        m.setReleaseDate(im.getReleaseDate());
        if (m.getCertification() == null || m.getCertification().isBlank()) m.setCertification("NR");   // not rated: free sources rarely provide it
        if (problems.isEmpty() && autoPublish) {
            m.setStatus(im.getReleaseDate().isAfter(today) ? MovieStatus.UPCOMING : MovieStatus.ACTIVE);
            m.setReviewNote(AUTO + ": all checks passed (source " + im.getSource() + ")");
            run.setAutoPublished(run.getAutoPublished() + 1);
        } else {
            m.setStatus(MovieStatus.PENDING_REVIEW);
            m.setReviewNote(problems.isEmpty() ? "Ready for review: all checks passed" : "Needs attention: " + String.join("; ", problems));
            run.setSentToReview(run.getSentToReview() + 1);
        }
        movies.save(m);
    }

    private static boolean sameFilm(Movie x, ImportedMovie im) {
        if (x.getReleaseDate() == null || im.getReleaseDate() == null) return true;
        return Math.abs(java.time.temporal.ChronoUnit.DAYS.between(x.getReleaseDate(), im.getReleaseDate())) <= 60;
    }

    /** Validation rules. An empty list means the record is safe to publish automatically. */
    List<String> validate(ImportedMovie m, LocalDate today) {
        List<String> p = new ArrayList<>();
        if (m.getTitle() == null || m.getTitle().isBlank()) p.add("title missing");
        if (m.getLanguage() == null || m.getLanguage().isBlank()) p.add("language unknown");
        if (m.getReleaseDate() == null) p.add("release date missing");
        else if (m.getReleaseDate().isBefore(today.minusDays(90)) || m.getReleaseDate().isAfter(today.plusDays(400))) p.add("release date outside the expected window");
        // Poster, trailer, cast and description are optional: theatres and the Super Admin can add them later.
        if (m.getGenre() == null || m.getGenre().isBlank()) p.add("genre missing");
        if (m.getRuntimeMinutes() == null || m.getRuntimeMinutes() < 40 || m.getRuntimeMinutes() > 300) p.add("runtime missing or unrealistic");
        return p;
    }

    private static String cut(String s, int max) { return s == null ? null : (s.length() > max ? s.substring(0, max) : s); }

    public Map<String, Object> status() {
        List<Map<String, Object>> list = new ArrayList<>();
        for (MovieMetadataProvider p : ordered()) {
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("name", p.name()); row.put("configured", p.isConfigured());
            Optional<MovieImportRun> last = runs.findFirstByProviderOrderByStartedAtDesc(p.name());
            row.put("lastRunAt", last.map(MovieImportRun::getStartedAt).orElse(null));
            row.put("lastRunOk", last.map(MovieImportRun::isSuccess).orElse(null));
            row.put("lastError", last.map(MovieImportRun::getErrorMessage).orElse(null));
            row.put("lastSuccessAt", runs.findFirstByProviderAndSuccessTrueOrderByStartedAtDesc(p.name()).map(MovieImportRun::getStartedAt).orElse(null));
            list.add(row);
        }
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("enabled", enabled); out.put("autoPublish", autoPublish); out.put("omdbEnrichment", omdb.isConfigured()); out.put("providers", list);
        return out;
    }

    public List<MovieImportRun> history() { return runs.findTop30ByOrderByStartedAtDesc(); }
}
