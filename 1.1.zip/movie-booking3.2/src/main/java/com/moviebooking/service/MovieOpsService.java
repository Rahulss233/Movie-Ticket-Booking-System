package com.moviebooking.service;

import com.moviebooking.entity.*;
import com.moviebooking.enums.*;
import com.moviebooking.exception.*;
import com.moviebooking.repository.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Super Admin: movies that are currently in booking, and removing one platform-wide with remarks. */
@Service
@RequiredArgsConstructor
public class MovieOpsService {
    private final MovieRepository movies;
    private final ShowRepository shows;
    private final TheatreMovieRepository listings;
    private final BookingRepository bookings;
    private final BookingService bookingService;
    private final NotificationService notifications;
    private final AuditService audit;

    /** Movies with a live theatre run or upcoming scheduled shows, with simple counts. */
    @Transactional(readOnly = true)
    public List<Map<String, Object>> inBooking() {
        Map<Long, Map<String, Object>> out = new LinkedHashMap<>();
        Map<Long, Set<Long>> theatreIds = new HashMap<>();
        for (TheatreMovie l : listings.findAllLive(LocalDate.now())) {
            Movie m = l.getMovie();
            if (m.getStatus() == MovieStatus.ARCHIVED) continue;
            Map<String, Object> row = row(out, m);
            theatreIds.computeIfAbsent(m.getId(), k -> new HashSet<>()).add(l.getTheatre().getId());
            LocalDate from = (LocalDate) row.get("runFrom"), to = (LocalDate) row.get("runTo");
            if (from == null || l.getStartDate().isBefore(from)) row.put("runFrom", l.getStartDate());
            if (to == null || l.getEndDate().isAfter(to)) row.put("runTo", l.getEndDate());
        }
        for (Show s : shows.findAllUpcomingScheduled(LocalDateTime.now())) {
            Movie m = s.getMovie();
            if (m.getStatus() == MovieStatus.ARCHIVED) continue;
            Map<String, Object> row = row(out, m);
            theatreIds.computeIfAbsent(m.getId(), k -> new HashSet<>()).add(s.getScreen().getTheatre().getId());
            row.put("upcomingShows", (Integer) row.get("upcomingShows") + 1);
            row.put("bookings", (Long) row.get("bookings") + bookings.countLiveByShow(s.getId()));
        }
        out.forEach((id, row) -> row.put("theatres", theatreIds.getOrDefault(id, Set.of()).size()));
        List<Map<String, Object>> list = new ArrayList<>(out.values());
        list.sort(Comparator.comparing(r -> String.valueOf(r.get("title")).toLowerCase()));
        return list;
    }

    private Map<String, Object> row(Map<Long, Map<String, Object>> out, Movie m) {
        return out.computeIfAbsent(m.getId(), k -> {
            Map<String, Object> r = new LinkedHashMap<>();
            r.put("id", m.getId()); r.put("title", m.getTitle()); r.put("language", m.getLanguage());
            r.put("genre", m.getGenre()); r.put("status", m.getStatus().name());
            r.put("theatres", 0); r.put("upcomingShows", 0); r.put("bookings", 0L);
            r.put("runFrom", null); r.put("runTo", null);
            return r;
        });
    }

    /** Archives the movie, ends every theatre's run, cancels upcoming shows (customers are refunded) and tells the theatres. */
    @Transactional
    public Map<String, Object> remove(Long id, String remarks, User admin) {
        String why = remarks == null ? "" : remarks.trim();
        if (why.length() < 5) throw new BadRequestException("Please enter remarks (at least 5 characters)");
        if (why.length() > 250) why = why.substring(0, 250);
        Movie movie = movies.findById(id).orElseThrow(() -> new NotFoundException("Movie not found"));
        if (movie.getStatus() == MovieStatus.ARCHIVED) throw new BadRequestException("This movie is already removed");

        Map<Long, User> owners = new LinkedHashMap<>();
        int cancelled = 0;
        for (Show s : shows.findByMovie_IdAndStatusAndStartTimeAfter(id, ShowStatus.SCHEDULED, LocalDateTime.now())) {
            s.setStatus(ShowStatus.CANCELLED);
            s.setCancelReason("Movie removed by the platform: " + why);
            bookingService.cancelAllForShow(s);
            shows.save(s);
            cancelled++;
            Theatre t = s.getScreen().getTheatre();
            if (t.getOwner() != null) owners.put(t.getId(), t.getOwner());
        }
        for (TheatreMovie l : listings.findByMovie_IdAndRemovedAtIsNull(id)) {
            l.setRemovedAt(LocalDateTime.now()); l.setRemovedBy(admin.getEmail()); l.setRemoveReason("Removed by Super Admin: " + why);
            listings.save(l);
            if (l.getTheatre().getOwner() != null) owners.put(l.getTheatre().getId(), l.getTheatre().getOwner());
        }
        movie.setStatus(MovieStatus.ARCHIVED);
        movie.setReviewNote("Removed by " + admin.getEmail() + ": " + why);
        movies.save(movie);

        final String note = why;
        owners.values().forEach(o -> notifications.notify(o, "Movie '" + movie.getTitle() + "' was removed by the Super Admin (" + note
                + "). Its upcoming shows were cancelled and customers refunded. You can add a replacement movie from Movies."));
        audit.log(admin.getEmail(), "MOVIE_REMOVED_BY_ADMIN", "movie=" + id + " " + movie.getTitle() + " (" + cancelled + " shows cancelled) " + why);
        Map<String, Object> res = new LinkedHashMap<>();
        res.put("movie", movie.getTitle()); res.put("cancelledShows", cancelled); res.put("theatresNotified", owners.size());
        return res;
    }
}
