package com.moviebooking.service;

import com.moviebooking.dto.Dtos.NotificationView;
import com.moviebooking.entity.Notification;
import com.moviebooking.entity.User;
import com.moviebooking.enums.Role;
import com.moviebooking.repository.NotificationRepository;
import com.moviebooking.repository.UserRepository;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class NotificationService {
    private final NotificationRepository repo;
    private final UserRepository users;

    @Transactional
    public void notify(User user, String message) {
        Notification n = new Notification();
        n.setUser(user);
        n.setMessage(message);
        repo.save(n);
    }

    @Transactional
    public void notifySuperAdmins(String message) {
        users.findByRole(Role.SUPER_ADMIN).forEach(u -> notify(u, message));
    }

    @Transactional(readOnly = true)
    public List<NotificationView> list(User user) {
        return repo.findTop50ByUserIdOrderByCreatedAtDesc(user.getId()).stream()
                .map(n -> new NotificationView(n.getId(), n.getMessage(), n.isSeen(), n.getCreatedAt(), categorize(n.getMessage()))).toList();
    }

    @Transactional(readOnly = true)
    public long unread(User user) {
        return repo.countByUserIdAndSeenFalse(user.getId());
    }

    @Transactional
    public void markAllRead(User user) {
        repo.findByUserIdAndSeenFalse(user.getId()).forEach(n -> n.setSeen(true));
    }

    @Transactional
    public void markRead(User user, Long id) {
        repo.findByIdAndUserId(id, user.getId()).ifPresent(n -> n.setSeen(true));
    }

    @Transactional
    public void delete(User user, Long id) {
        repo.findByIdAndUserId(id, user.getId()).ifPresent(repo::delete);
    }

    @Transactional
    public void clearRead(User user) {
        repo.deleteAll(repo.findByUserIdAndSeenTrue(user.getId()));
    }

    /** Groups notifications so each person sees them in the right place (BOOKING, PAYMENT, THEATRE, MOVIE, SYSTEM). */
    static String categorize(String m) {
        String t = m == null ? "" : m.toLowerCase();
        if (t.contains("complaint")) return "COMPLAINT";
        if (t.contains("cancel")) return "CANCELLATION";
        if (t.contains("refund")) return "REFUND";
        if (t.contains("review") || t.contains("rating")) return "REVIEW";
        if (t.contains("offer") || t.contains("coupon")) return "OFFER";
        if (t.startsWith("movie") || t.contains("movie request") || t.contains("new movies")) return "MOVIE";
        if (t.contains("booking") || t.contains("show ")) return t.startsWith("payment") ? "PAYMENT" : "BOOKING";
        if (t.contains("payment") || t.contains("refund")) return "PAYMENT";
        if (t.contains("theatre")) return "THEATRE";
        return "SYSTEM";
    }
}
