package com.moviebooking.service;

import com.moviebooking.entity.*;
import com.moviebooking.exception.BadRequestException;
import com.moviebooking.exception.ConflictException;
import com.moviebooking.exception.ForbiddenException;
import com.moviebooking.exception.NotFoundException;
import com.moviebooking.repository.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Coupons. Every rule is enforced here on the server; the browser only ever sends a code, a show and seat ids. */
@Service
@RequiredArgsConstructor
public class OfferService {
    private final OfferRepository offers;
    private final OfferRedemptionRepository redemptions;
    private final MovieRepository movies;
    private final TheatreRepository theatres;
    private final ShowSeatRepository showSeats;
    private final AuditService audit;

    public record OfferRequest(String code, String title, String description, String discountType, BigDecimal discountValue, BigDecimal minAmount,
                               BigDecimal maxDiscount, LocalDateTime startsAt, LocalDateTime endsAt, Integer totalLimit, Integer perUserLimit,
                               Long theatreId, Long movieId) {}

    public record OfferView(Long id, String code, String title, String description, String discountType, BigDecimal discountValue, BigDecimal minAmount,
                            BigDecimal maxDiscount, LocalDateTime startsAt, LocalDateTime endsAt, Integer totalLimit, int perUserLimit, String status,
                            String effectiveStatus, String scope, String movieTitle, long redeemed) {}

    public record Applied(Offer offer, BigDecimal discount) {}

    private static BigDecimal money(BigDecimal v) { return v.setScale(2, RoundingMode.HALF_UP); }

    private OfferView view(Offer o) {
        LocalDateTime now = LocalDateTime.now();
        String eff = "PAUSED".equals(o.getStatus()) ? "PAUSED" : now.isBefore(o.getStartsAt()) ? "SCHEDULED" : now.isAfter(o.getEndsAt()) ? "EXPIRED" : "ACTIVE";
        return new OfferView(o.getId(), o.getCode(), o.getTitle(), o.getDescription(), o.getDiscountType(), o.getDiscountValue(), o.getMinAmount(), o.getMaxDiscount(),
                o.getStartsAt(), o.getEndsAt(), o.getTotalLimit(), o.getPerUserLimit(), o.getStatus(), eff,
                o.getTheatre() == null ? "All theatres" : o.getTheatre().getName(), o.getMovie() == null ? null : o.getMovie().getTitle(), redemptions.countActive(o.getId()));
    }

    // ---------------------------------------------------------------- management
    @Transactional(readOnly = true)
    public List<OfferView> manage(Long theatreIdOrNullForAll) { return offers.findForManager(theatreIdOrNullForAll).stream().map(this::view).toList(); }

    /** theatreScope: the owner's theatre for a Theatre Admin (forced); null for the Super Admin, who may use req.theatreId() or leave it platform-wide. */
    @Transactional
    public OfferView create(User actor, Theatre theatreScope, OfferRequest r) {
        String code = r.code() == null ? "" : r.code().trim().toUpperCase(Locale.ROOT);
        if (!code.matches("[A-Z0-9_-]{3,30}")) throw new BadRequestException("Coupon code must be 3-30 letters, numbers, - or _");
        if (offers.existsByCodeIgnoreCase(code)) throw new ConflictException("This coupon code already exists");
        if (r.title() == null || r.title().isBlank()) throw new BadRequestException("Give the offer a title");
        String type = r.discountType() == null ? "" : r.discountType().toUpperCase(Locale.ROOT);
        if (!type.equals("PERCENT") && !type.equals("FLAT")) throw new BadRequestException("Discount type must be PERCENT or FLAT");
        if (r.discountValue() == null || r.discountValue().signum() <= 0) throw new BadRequestException("Discount must be greater than zero");
        if (type.equals("PERCENT") && r.discountValue().compareTo(BigDecimal.valueOf(90)) > 0) throw new BadRequestException("Percentage discount cannot exceed 90%");
        if (r.startsAt() == null || r.endsAt() == null || !r.endsAt().isAfter(r.startsAt())) throw new BadRequestException("End must be after start");
        if (r.perUserLimit() != null && r.perUserLimit() < 1) throw new BadRequestException("Per-customer limit must be at least 1");
        if (r.totalLimit() != null && r.totalLimit() < 1) throw new BadRequestException("Total limit must be at least 1");
        Offer o = new Offer();
        o.setCode(code); o.setTitle(r.title().trim()); o.setDescription(r.description() == null ? null : r.description().trim());
        o.setDiscountType(type); o.setDiscountValue(money(r.discountValue()));
        o.setMinAmount(r.minAmount() == null ? BigDecimal.ZERO : money(r.minAmount().max(BigDecimal.ZERO)));
        o.setMaxDiscount(r.maxDiscount() == null || r.maxDiscount().signum() <= 0 ? null : money(r.maxDiscount()));
        o.setStartsAt(r.startsAt()); o.setEndsAt(r.endsAt()); o.setTotalLimit(r.totalLimit());
        o.setPerUserLimit(r.perUserLimit() == null ? 1 : r.perUserLimit());
        o.setCreatedBy(actor);
        if (theatreScope != null) o.setTheatre(theatreScope);
        else if (r.theatreId() != null) o.setTheatre(theatres.findById(r.theatreId()).orElseThrow(() -> new NotFoundException("Theatre not found")));
        if (r.movieId() != null) o.setMovie(movies.findById(r.movieId()).orElseThrow(() -> new NotFoundException("Movie not found")));
        offers.save(o);
        audit.log(actor.getEmail(), "OFFER_CREATE", code);
        return view(o);
    }

    @Transactional
    public OfferView setStatus(User actor, Theatre theatreScope, Long id, String status) {
        Offer o = offers.findById(id).orElseThrow(() -> new NotFoundException("Offer not found"));
        if (theatreScope != null && (o.getTheatre() == null || !o.getTheatre().getId().equals(theatreScope.getId()))) throw new ForbiddenException("Not your offer");
        if (!"ACTIVE".equals(status) && !"PAUSED".equals(status)) throw new BadRequestException("Status must be ACTIVE or PAUSED");
        o.setStatus(status);
        audit.log(actor.getEmail(), "OFFER_" + status, o.getCode());
        return view(o);
    }

    // ---------------------------------------------------------------- customers
    @Transactional(readOnly = true)
    public List<OfferView> live() { return offers.findLive(LocalDateTime.now()).stream().map(this::view).toList(); }

    /** The only place a discount is calculated. Throws BadRequestException with the exact reason when a coupon cannot be used. */
    @Transactional(readOnly = true)
    public Applied check(String rawCode, User customer, Show show, BigDecimal total) {
        String code = rawCode == null ? "" : rawCode.trim();
        if (code.isEmpty()) throw new BadRequestException("Enter a coupon code");
        Offer o = offers.findByCodeIgnoreCase(code).orElseThrow(() -> new BadRequestException("This coupon code does not exist"));
        LocalDateTime now = LocalDateTime.now();
        if ("PAUSED".equals(o.getStatus())) throw new BadRequestException("This coupon is currently not active");
        if (now.isBefore(o.getStartsAt())) throw new BadRequestException("This coupon is not valid yet (starts " + o.getStartsAt().toLocalDate() + ")");
        if (now.isAfter(o.getEndsAt())) throw new BadRequestException("This coupon has expired");
        if (o.getTheatre() != null && !o.getTheatre().getId().equals(show.getScreen().getTheatre().getId()))
            throw new BadRequestException("This coupon is only valid at " + o.getTheatre().getName());
        if (o.getMovie() != null && !o.getMovie().getId().equals(show.getMovie().getId()))
            throw new BadRequestException("This coupon is only valid for " + o.getMovie().getTitle());
        if (total.compareTo(o.getMinAmount()) < 0) throw new BadRequestException("Minimum booking amount for this coupon is \u20B9" + o.getMinAmount().stripTrailingZeros().toPlainString());
        if (o.getTotalLimit() != null && redemptions.countActive(o.getId()) >= o.getTotalLimit()) throw new BadRequestException("This coupon has been fully redeemed");
        if (redemptions.countActiveForUser(o.getId(), customer.getId()) >= o.getPerUserLimit()) throw new BadRequestException("You have already used this coupon the maximum number of times");
        BigDecimal d = "PERCENT".equals(o.getDiscountType()) ? total.multiply(o.getDiscountValue()).divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP) : o.getDiscountValue();
        if (o.getMaxDiscount() != null) d = d.min(o.getMaxDiscount());
        d = d.min(total.subtract(BigDecimal.ONE).max(BigDecimal.ZERO));   // customer always pays at least \u20B91
        return new Applied(o, money(d));
    }

    @Transactional(readOnly = true)
    public Map<String, Object> preview(User customer, String code, Long showId, List<Long> seatIds, ShowRepository shows) {
        Show show = shows.findById(showId).orElseThrow(() -> new NotFoundException("Show not found"));
        List<ShowSeat> seats = showSeats.findSeatsNoLock(showId, new LinkedHashSet<>(seatIds));
        if (seats.isEmpty()) throw new BadRequestException("Select seats first");
        BigDecimal total = seats.stream().map(ShowSeat::getPrice).reduce(BigDecimal.ZERO, BigDecimal::add);
        Applied a = check(code, customer, show, total);
        return Map.of("code", a.offer().getCode(), "title", a.offer().getTitle(), "total", total, "discount", a.discount(), "payable", total.subtract(a.discount()));
    }

    @Transactional
    public void recordRedemption(Offer offer, Booking booking, User customer, BigDecimal discount) {
        OfferRedemption r = new OfferRedemption();
        r.setOffer(offer); r.setBooking(booking); r.setCustomer(customer); r.setDiscount(discount);
        redemptions.save(r);
    }
}
