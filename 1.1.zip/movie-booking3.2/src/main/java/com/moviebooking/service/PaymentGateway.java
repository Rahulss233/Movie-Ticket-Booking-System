package com.moviebooking.service;

import com.moviebooking.entity.Booking;

/** Payment provider abstraction. A real gateway (Razorpay, Stripe...) implements this in Stage 2. */
public interface PaymentGateway {
    record PaymentResult(boolean success, String gatewayRef, String message) {}

    String mode();

    /** @param simulateFailure honoured by the mock gateway only (test mode). */
    PaymentResult charge(Booking booking, boolean simulateFailure);
}
