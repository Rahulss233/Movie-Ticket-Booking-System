package com.moviebooking.service;

import com.moviebooking.entity.*;
import com.moviebooking.enums.PaymentStatus;
import com.moviebooking.exception.BadRequestException;
import com.moviebooking.exception.NotFoundException;
import com.moviebooking.repository.BookingRepository;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Refund tracker. Payments run in test mode, so no money moves automatically: the Super Admin pays the refund
 * outside the system and then marks it completed here (with a reference). That updates finance reports and notifies the customer.
 */
@Service
@RequiredArgsConstructor
public class RefundService {
    private final BookingRepository bookings;
    private final NotificationService notifications;
    private final AuditService audit;

    public record RefundView(String reference, String customer, String movie, String theatre, LocalDateTime showTime, BigDecimal amount,
                             String paymentStatus, LocalDateTime cancelledAt, LocalDateTime refundedAt, String refundReference, String reason) {}

    @Transactional(readOnly = true)
    public List<RefundView> list(boolean pendingOnly) {
        List<PaymentStatus> st = pendingOnly ? List.of(PaymentStatus.REFUND_PENDING) : List.of(PaymentStatus.REFUND_PENDING, PaymentStatus.REFUNDED);
        return bookings.findByPaymentStatuses(st).stream().map(b -> new RefundView(b.getReference(), b.getCustomer().getName(), b.getShow().getMovie().getTitle(),
                b.getShow().getScreen().getTheatre().getName(), b.getShow().getStartTime(), b.getRefundAmount(), b.getPaymentStatus().name(), b.getCancelledAt(),
                b.getRefundCompletedAt(), b.getRefundReference(),
                b.getShow().getCancelReason() != null ? "Show cancelled: " + b.getShow().getCancelReason() : "Cancelled by customer")).toList();
    }

    @Transactional
    public RefundView complete(User admin, String reference, String refundRef) {
        Booking b = bookings.findByReference(reference).orElseThrow(() -> new NotFoundException("Booking not found"));
        if (b.getPaymentStatus() != PaymentStatus.REFUND_PENDING) throw new BadRequestException("This refund is not pending");
        String ref = refundRef == null ? "" : refundRef.trim();
        if (ref.isEmpty()) ref = "RF" + UUID.randomUUID().toString().replace("-", "").substring(0, 10).toUpperCase();
        if (ref.length() > 60) throw new BadRequestException("Refund reference is too long");
        b.setPaymentStatus(PaymentStatus.REFUNDED);
        b.setRefundStatus("COMPLETED");
        b.setRefundCompletedAt(LocalDateTime.now());
        b.setRefundReference(ref);
        notifications.notify(b.getCustomer(), "Refund of \u20B9" + b.getRefundAmount() + " for booking " + b.getReference() + " has been completed (ref " + ref + ").");
        audit.log(admin.getEmail(), "REFUND_COMPLETED", b.getReference() + " " + b.getRefundAmount() + " ref " + ref);
        return new RefundView(b.getReference(), b.getCustomer().getName(), b.getShow().getMovie().getTitle(), b.getShow().getScreen().getTheatre().getName(),
                b.getShow().getStartTime(), b.getRefundAmount(), b.getPaymentStatus().name(), b.getCancelledAt(), b.getRefundCompletedAt(), ref, null);
    }
}
