package com.moviebooking.service;

import com.moviebooking.entity.*;
import com.moviebooking.enums.BookingStatus;
import com.moviebooking.exception.*;
import com.moviebooking.repository.*;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Verified reviews. Policy: one review per confirmed booking, only after the show has ended; reviews are final (no edits);
 * the Super Admin can hide a review (with a reason) and a theatre can report one. Low ratings never suspend a theatre automatically:
 * they only raise an alert for the Super Admin, who looks at the evidence and decides.
 */
@Service
@RequiredArgsConstructor
public class ReviewService {
    private final ReviewRepository reviews;
    private final BookingRepository bookings;
    private final TheatreRepository theatres;
    private final NotificationService notifications;
    private final AuditService audit;
    @Value("${app.reviews.window-days:30}") private int windowDays;
    @Value("${app.reviews.low-average:2.5}") private double lowAverage;
    @Value("${app.reviews.min-count:5}") private int minCount;

    public record ReviewView(Long id, int rating, String comment, String customer, String movie, String theatre, Long theatreId, java.time.LocalDateTime showTime,
                             LocalDateTime createdAt, String status, boolean reported, String reportReason, String hiddenReason, boolean verified) {}
    public record Summary(double average, long count, long[] distribution) {}
    public record TheatreRating(Long theatreId, String theatre, String city, double average, long count, long lowCount, boolean flagged) {}

    private ReviewView view(Review r, boolean showName) {
        String first = r.getCustomer().getName() == null ? "Customer" : r.getCustomer().getName().trim().split("\\s+")[0];
        return new ReviewView(r.getId(), r.getRating(), r.getComment(), showName ? first : "Verified customer", r.getMovie().getTitle(), r.getTheatre().getName(), r.getTheatre().getId(),
                r.getBooking().getShow().getStartTime(), r.getCreatedAt(), r.getStatus(), r.isReported(), r.getReportReason(), r.getHiddenReason(), true);
    }

    // ---- customer
    @Transactional
    public ReviewView create(User customer, String reference, int rating, String comment) {
        Booking b = bookings.findByReference(reference).orElseThrow(() -> new NotFoundException("Booking not found"));
        if (!b.getCustomer().getId().equals(customer.getId())) throw new ForbiddenException("Not your booking");
        if (b.getStatus() != BookingStatus.CONFIRMED) throw new BadRequestException("Only confirmed bookings can be reviewed");
        if (b.getShow().getEndTime().isAfter(LocalDateTime.now())) throw new BadRequestException("You can review after the show has ended");
        if (reviews.existsByBookingId(b.getId())) throw new ConflictException("You have already reviewed this booking");
        if (rating < 1 || rating > 5) throw new BadRequestException("Rating must be 1 to 5 stars");
        String text = comment == null ? null : comment.trim();
        if (text != null && text.length() > 1000) throw new BadRequestException("Review is too long (max 1000 characters)");
        Review r = new Review();
        r.setBooking(b); r.setCustomer(customer); r.setMovie(b.getShow().getMovie()); r.setTheatre(b.getShow().getScreen().getTheatre());
        r.setRating(rating); r.setComment(text == null || text.isEmpty() ? null : text);
        reviews.save(r);
        notifications.notify(r.getTheatre().getOwner(), "New review (" + rating + "\u2605) for " + r.getMovie().getTitle() + " at your theatre.");
        return view(r, true);
    }

    @Transactional(readOnly = true)
    public List<String> reviewedReferences(User customer) { return reviews.findMine(customer.getId()).stream().map(r -> r.getBooking().getReference()).toList(); }

    // ---- theatre
    @Transactional(readOnly = true)
    public Map<String, Object> forTheatre(Theatre t) {
        List<Review> list = reviews.findFiltered(t.getId(), false, true);
        return Map.of("summary", summarize(list), "reviews", list.stream().map(r -> view(r, true)).toList());
    }

    @Transactional
    public void report(User owner, Theatre t, Long id, String reason) {
        Review r = reviews.findById(id).orElseThrow(() -> new NotFoundException("Review not found"));
        if (!r.getTheatre().getId().equals(t.getId())) throw new ForbiddenException("Not a review for your theatre");
        if (reason == null || reason.trim().length() < 5) throw new BadRequestException("Tell us why this review should be checked");
        r.setReported(true); r.setReportReason(reason.trim().substring(0, Math.min(300, reason.trim().length())));
        notifications.notifySuperAdmins("A theatre reported a review for moderation: " + t.getName());
    }

    // ---- super admin
    @Transactional(readOnly = true)
    public List<TheatreRating> ratings() {
        List<Review> list = reviews.findVisibleSince(LocalDateTime.now().minusDays(windowDays));
        Map<Theatre, List<Review>> by = list.stream().collect(Collectors.groupingBy(Review::getTheatre));
        return by.entrySet().stream().map(e -> {
            List<Review> rs = e.getValue();
            double avg = rs.stream().mapToInt(Review::getRating).average().orElse(0);
            long low = rs.stream().filter(r -> r.getRating() <= 2).count();
            boolean flagged = rs.size() >= minCount && (avg <= lowAverage || low * 2 >= rs.size());
            Location city = e.getKey().getCity();
            return new TheatreRating(e.getKey().getId(), e.getKey().getName(), city == null ? "" : city.getName(), Math.round(avg * 100.0) / 100.0, rs.size(), low, flagged);
        }).sorted(Comparator.comparing(TheatreRating::flagged).reversed().thenComparingDouble(TheatreRating::average)).toList();
    }

    @Transactional(readOnly = true)
    public Map<String, Object> thresholds() { return Map.of("windowDays", windowDays, "lowAverage", lowAverage, "minReviews", minCount); }

    @Transactional(readOnly = true)
    public List<ReviewView> evidence(Long theatreId, boolean reportedOnly) { return reviews.findFiltered(theatreId, reportedOnly, false).stream().map(r -> view(r, true)).toList(); }

    @Transactional
    public void moderate(User admin, Long id, boolean hide, String reason) {
        Review r = reviews.findById(id).orElseThrow(() -> new NotFoundException("Review not found"));
        if (hide && (reason == null || reason.trim().length() < 5)) throw new BadRequestException("Give a reason for hiding the review");
        r.setStatus(hide ? "HIDDEN" : "VISIBLE");
        r.setHiddenReason(hide ? reason.trim() : null);
        r.setReported(false);
        audit.log(admin.getEmail(), hide ? "REVIEW_HIDDEN" : "REVIEW_RESTORED", "review " + id + (hide ? ": " + reason.trim() : ""));
    }

    /** Weekly alert only: shows the Super Admin which theatres need a look. Never changes a theatre's status. */
    @Scheduled(cron = "0 0 9 * * MON")
    public void weeklyAlert() {
        ratings().stream().filter(TheatreRating::flagged).forEach(t -> notifications.notifySuperAdmins("Low rating alert: " + t.theatre() + " averages " + t.average()
                + " from " + t.count() + " reviews in the last " + windowDays + " days. Review the evidence."));
    }

    private static Summary summarize(List<Review> list) {
        long[] d = new long[5];
        list.forEach(r -> d[r.getRating() - 1]++);
        return new Summary(Math.round(list.stream().mapToInt(Review::getRating).average().orElse(0) * 100.0) / 100.0, list.size(), d);
    }
}
