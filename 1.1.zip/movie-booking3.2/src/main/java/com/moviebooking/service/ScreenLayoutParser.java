package com.moviebooking.service;

import com.moviebooking.dto.Dtos.RowDef;
import com.moviebooking.exception.BadRequestException;
import java.util.*;

/**
 * Turns the theatre's designed rows into seats. Each row has a label (A, B, AA...), a pricing section and a pattern:
 *   "1-18"          seats 1 to 18
 *   "1-4,_,5-17,_,18-21"   an aisle ("_" = one empty column, "_3" = three) between blocks
 *   "*5" = 5 seats (1-5), "*-5" = reversed (5-1), "18-10" = reversed range; the label box also accepts A*5 / Z*-5
 *   "1,2,3,7,8"     any numbers you like (missing numbers are simply not there)
 * A row with no label and no pattern is a blank line between blocks.
 */
public final class ScreenLayoutParser {
    private ScreenLayoutParser() {}

    public record SeatSpec(String row, String section, int number, int gridRow, int gridCol) {}

    public static final int MAX_SEATS = 1500, MAX_ROWS = 80;

    public static List<SeatSpec> parse(List<RowDef> rows) {
        if (rows == null || rows.isEmpty()) throw new BadRequestException("Add at least one row of seats");
        if (rows.size() > MAX_ROWS) throw new BadRequestException("A screen can have at most " + MAX_ROWS + " rows");
        List<SeatSpec> out = new ArrayList<>();
        Set<String> used = new HashSet<>();
        int gridRow = 0;
        for (RowDef r : rows) {
            String label = r.label() == null ? "" : r.label().trim().toUpperCase(Locale.ROOT);
            String pattern = r.pattern() == null ? "" : r.pattern().trim();
            if (pattern.isEmpty() && label.contains("*")) {            // shorthand typed in the label box: A*5 or Z*-5
                int i = label.indexOf('*'); pattern = label.substring(i); label = label.substring(0, i).trim();
            }
            if (label.isEmpty() && pattern.isEmpty()) { gridRow++; continue; }      // blank spacer line
            if (!label.matches("[A-Z0-9]{1,3}")) throw new BadRequestException("Row label \"" + r.label() + "\" must be 1-3 letters or digits");
            String section = r.section() == null ? "" : r.section().trim();
            if (section.isEmpty()) throw new BadRequestException("Row " + label + " needs a section name (for pricing), e.g. REGULAR or FIRST CLASS");
            if (pattern.isEmpty()) throw new BadRequestException("Row " + label + " has no seats. Write e.g. 1-12");
            int col = 0;
            for (String raw : pattern.split(",")) {
                String t = raw.trim();
                if (t.isEmpty()) continue;
                if (t.startsWith("_")) {
                    int n = 1;
                    if (t.length() > 1) n = parse(t.substring(1), label, raw);
                    if (n < 1 || n > 30) throw new BadRequestException("Row " + label + ": a gap must be between 1 and 30 columns");
                    col += n;
                } else if (t.startsWith("*")) {                      // *5 = seats 1..5, *-5 = seats 5..1
                    boolean rev = t.startsWith("*-");
                    int n = parse(t.substring(rev ? 2 : 1), label, raw);
                    if (n < 1 || n > 99) throw new BadRequestException("Row " + label + ": \"" + t + "\" needs a count of 1-99");
                    for (int k = 0; k < n; k++) col = add(out, used, label, section, rev ? n - k : k + 1, gridRow, col);
                } else if (t.contains("-")) {
                    String[] ab = t.split("-", 2);
                    int a = parse(ab[0], label, raw), b = parse(ab[1], label, raw);
                    if (a < 1 || b < 1 || a > 99 || b > 99) throw new BadRequestException("Row " + label + ": \"" + t + "\" is not a valid range (1-99)");
                    int step = a <= b ? 1 : -1;        // 18-10 counts downwards (reverse numbering)
                    for (int n = a; n != b + step; n += step) col = add(out, used, label, section, n, gridRow, col);
                } else {
                    int n = parse(t, label, raw);
                    if (n < 1 || n > 99) throw new BadRequestException("Row " + label + ": seat numbers must be 1-99");
                    col = add(out, used, label, section, n, gridRow, col);
                }
            }
            gridRow++;
        }
        if (out.isEmpty()) throw new BadRequestException("The layout has no seats");
        if (out.size() > MAX_SEATS) throw new BadRequestException("A screen can have at most " + MAX_SEATS + " seats");
        return out;
    }

    private static int add(List<SeatSpec> out, Set<String> used, String row, String section, int n, int gridRow, int col) {
        if (!used.add(row + "#" + n)) throw new BadRequestException("Seat " + row + n + " appears twice");
        out.add(new SeatSpec(row, section, n, gridRow, col));
        return col + 1;
    }

    private static int parse(String s, String label, String raw) {
        try { return Integer.parseInt(s.trim()); }
        catch (NumberFormatException e) { throw new BadRequestException("Row " + label + ": cannot read \"" + raw.trim() + "\". Use numbers like 1-12, gaps like _ and commas between blocks"); }
    }

    /** Section names in the order they first appear. */
    public static List<String> sections(List<SeatSpec> seats) {
        LinkedHashSet<String> s = new LinkedHashSet<>();
        seats.forEach(x -> s.add(x.section()));
        return new ArrayList<>(s);
    }
}
