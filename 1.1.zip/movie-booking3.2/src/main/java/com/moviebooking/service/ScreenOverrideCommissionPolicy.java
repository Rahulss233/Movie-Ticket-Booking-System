package com.moviebooking.service;

import com.moviebooking.entity.Screen;
import com.moviebooking.entity.Theatre;
import java.math.BigDecimal;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/** Screen rate overrides theatre rate, which overrides the platform default. */
@Component
public class ScreenOverrideCommissionPolicy implements CommissionPolicy {
    private final BigDecimal platformDefault;

    public ScreenOverrideCommissionPolicy(@Value("${app.default-commission:10.00}") BigDecimal platformDefault) {
        this.platformDefault = platformDefault;
    }

    @Override
    public BigDecimal effectiveRate(Screen screen) {
        if (screen.getCommissionPercent() != null) return screen.getCommissionPercent();
        return effectiveRate(screen.getTheatre());
    }

    @Override
    public BigDecimal effectiveRate(Theatre theatre) {
        return theatre.getCommissionPercent() != null ? theatre.getCommissionPercent() : platformDefault;
    }
}
