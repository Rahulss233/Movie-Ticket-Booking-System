package com.moviebooking.service;

import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class SeatHoldScheduler {
    private static final Logger log = LoggerFactory.getLogger(SeatHoldScheduler.class);
    private final BookingService bookingService;

    @Scheduled(fixedDelay = 60_000)
    public void releaseExpired() {
        int n = bookingService.releaseExpiredHolds();
        if (n > 0) log.info("Released {} expired seat holds", n);
    }
}
