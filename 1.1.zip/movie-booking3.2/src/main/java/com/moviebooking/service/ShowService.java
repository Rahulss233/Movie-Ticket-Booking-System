package com.moviebooking.service;

import com.moviebooking.dto.Dtos.*;
import com.moviebooking.entity.*;
import com.moviebooking.enums.*;
import com.moviebooking.exception.*;
import com.moviebooking.repository.*;
import java.time.LocalDateTime;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class ShowService {
    private final ShowRepository shows;
    private final ShowSeatRepository showSeats;
    private final ScreenRepository screens;
    private final SeatRepository seats;
    private final MovieRepository movies;
    private final TheatreService theatreService;
    private final BookingService bookingService;
    private final ViewMapper mapper;

    @Value("${app.show-buffer-minutes:15}")
    private int bufferMinutes;

    private final TheatreMovieRepository listings;
    private final BookingRepository bookings;

    private static String clean(String v, String dflt) { return v == null || v.isBlank() ? dflt : v.trim(); }

    /** price per section: explicit section prices first, then the old regular/premium prices, otherwise the theatre must set one. */
    private java.math.BigDecimal priceFor(Seat seat, java.util.Map<String, java.math.BigDecimal> sectionPrices, java.math.BigDecimal regular, java.math.BigDecimal premium) {
        String sec = seat.getSection() != null ? seat.getSection() : (seat.getCategory() == SeatCategory.PREMIUM ? "PREMIUM" : "REGULAR");
        if (sectionPrices != null) {
            for (var e : sectionPrices.entrySet()) if (e.getKey() != null && e.getKey().trim().equalsIgnoreCase(sec) && e.getValue() != null) return e.getValue();
        }
        java.math.BigDecimal legacy = seat.getCategory() == SeatCategory.PREMIUM ? premium : regular;
        if (legacy == null) legacy = regular != null ? regular : premium;
        if (legacy != null && (sectionPrices == null || sectionPrices.isEmpty())) return legacy;
        throw new BadRequestException("Set a ticket price for the section \"" + sec + "\"");
    }

    private void checkListing(Theatre theatre, Movie movie, LocalDateTime start) {
        if (listings.countCovering(theatre.getId(), movie.getId(), start.toLocalDate()) == 0)
            throw new BadRequestException("Add \"" + movie.getTitle() + "\" to your theatre first (Movies page) with a start and end date that includes " + start.toLocalDate());
    }

    private void checkLanguage(Movie movie, String lang) {
        if (lang == null) return;
        boolean ok = java.util.Arrays.stream(movie.getLanguage().split(",")).anyMatch(l -> l.trim().equalsIgnoreCase(lang));
        if (!ok) throw new BadRequestException("\"" + lang + "\" is not one of this movie's languages (" + movie.getLanguage() + ")");
    }

    @Transactional
    public ShowView create(User owner, ShowRequest r) {
        Theatre theatre = theatreService.requireApproved(owner);
        Screen screen = screens.findById(r.screenId()).orElseThrow(() -> new NotFoundException("Screen not found"));
        if (!screen.getTheatre().getId().equals(theatre.getId())) throw new ForbiddenException("This screen belongs to another theatre");
        if (!screen.isActive()) throw new BadRequestException("Screen is not active");
        Movie movie = movies.findById(r.movieId()).orElseThrow(() -> new NotFoundException("Movie not found"));
        if (movie.getStatus() == MovieStatus.ARCHIVED) throw new BadRequestException("Archived movies cannot be scheduled");
        if (movie.getStatus() == MovieStatus.PENDING_REVIEW) throw new BadRequestException("This movie is not in the catalogue yet");
        if (!r.startTime().isAfter(LocalDateTime.now())) throw new BadRequestException("Show must start in the future");
        if (movie.getReleaseDate() != null && r.startTime().toLocalDate().isBefore(movie.getReleaseDate()))
            throw new BadRequestException("Movie releases on " + movie.getReleaseDate());
        checkListing(theatre, movie, r.startTime());
        checkLanguage(movie, r.audioLanguage());
        LocalDateTime end = r.startTime().plusMinutes(movie.getDurationMinutes() + bufferMinutes);
        if (shows.countOverlapping(screen.getId(), ShowStatus.SCHEDULED, r.startTime(), end) > 0)
            throw new ConflictException("This screen already has a show overlapping " + r.startTime().toLocalTime());
        List<Seat> active = seats.findByScreenIdAndActiveTrue(screen.getId());
        if (active.isEmpty()) throw new BadRequestException("Screen has no active seats");
        List<java.math.BigDecimal> prices = new java.util.ArrayList<>();
        for (Seat seat : active) prices.add(priceFor(seat, r.sectionPrices(), r.regularPrice(), r.premiumPrice()));

        Show s = new Show();
        s.setMovie(movie);
        s.setScreen(screen);
        s.setStartTime(r.startTime());
        s.setEndTime(end);
        s.setRegularPrice(java.util.Collections.min(prices));
        s.setPremiumPrice(java.util.Collections.max(prices));
        s.setAudioLanguage(clean(r.audioLanguage(), movie.getLanguage().split(",")[0].trim()));
        s.setDimension(clean(r.dimension(), "2D"));
        s.setSpecialFormats(clean(r.specialFormats(), screen.getSpecialFormats()));
        shows.save(s);
        List<ShowSeat> inventory = new java.util.ArrayList<>();
        for (int i = 0; i < active.size(); i++) {
            ShowSeat ss = new ShowSeat();
            ss.setShow(s);
            ss.setSeat(active.get(i));
            ss.setPrice(prices.get(i));
            inventory.add(ss);
        }
        showSeats.saveAll(inventory);
        return mapper.show(s, inventory.size());
    }

    public record BulkResult(int created, List<String> skipped) {}

    /** Several show times over a range of dates in one go (e.g. 10:00, 13:30, 19:00 every day for a week). Clashing times are skipped and reported. */
    @Transactional
    public BulkResult createMany(User owner, BulkShowRequest r) {
        if (r.toDate().isBefore(r.fromDate())) throw new BadRequestException("End date is before start date");
        if (r.fromDate().plusDays(62).isBefore(r.toDate())) throw new BadRequestException("Choose at most about two months at a time");
        if (r.times().size() > 12) throw new BadRequestException("At most 12 show times per day");
        List<java.time.LocalTime> times = new java.util.ArrayList<>();
        for (String t : r.times()) {
            try { times.add(java.time.LocalTime.parse(t.trim())); } catch (Exception e) { throw new BadRequestException("\"" + t + "\" is not a valid time (use HH:mm)"); }
        }
        int created = 0;
        List<String> skipped = new java.util.ArrayList<>();
        for (java.time.LocalDate d = r.fromDate(); !d.isAfter(r.toDate()); d = d.plusDays(1)) {
            for (java.time.LocalTime t : times) {
                try {
                    create(owner, new ShowRequest(r.movieId(), r.screenId(), d.atTime(t), r.regularPrice(), r.premiumPrice(), r.sectionPrices(), r.audioLanguage(), r.dimension(), r.specialFormats()));
                    created++;
                } catch (BadRequestException | ConflictException e) {
                    if (e.getMessage() != null && e.getMessage().startsWith("Set a ticket price")) throw e;
                    skipped.add(d + " " + t + ": " + e.getMessage());
                }
            }
        }
        return new BulkResult(created, skipped);
    }

    private static String sectionOf(Seat seat) {
        return seat.getSection() != null ? seat.getSection() : (seat.getCategory() == SeatCategory.PREMIUM ? "PREMIUM" : "REGULAR");
    }

    /**
     * Edit a scheduled show: movie, screen, start time, prices, language and formats.
     * Language and formats can always change. Time and prices are locked once someone holds or has booked seats.
     * Movie and screen are locked once the show has ANY booking (even a cancelled one), so no ticket ever changes after it was issued.
     * Changing the screen rebuilds the seat inventory; prices carry over by section name, and a section with no price must be given one.
     */
    @Transactional
    public ShowView update(User owner, Long showId, ShowUpdateRequest r) {
        Theatre theatre = theatreService.requireApproved(owner);
        Show s = shows.findById(showId).orElseThrow(() -> new NotFoundException("Show not found"));
        if (!s.getScreen().getTheatre().getId().equals(theatre.getId())) throw new ForbiddenException("Not your show");
        if (s.getStatus() != ShowStatus.SCHEDULED) throw new BadRequestException("Only scheduled shows can be edited");
        LocalDateTime now = LocalDateTime.now();

        boolean movieChange = r.movieId() != null && !r.movieId().equals(s.getMovie().getId());
        boolean screenChange = r.screenId() != null && !r.screenId().equals(s.getScreen().getId());
        boolean timeChange = r.startTime() != null && !r.startTime().equals(s.getStartTime());
        boolean priceChange = r.sectionPrices() != null && !r.sectionPrices().isEmpty();
        boolean placement = movieChange || screenChange;

        if (placement || timeChange || priceChange) {
            if (!s.getStartTime().isAfter(now)) throw new BadRequestException("This show has already started, so its movie, screen, time and prices can no longer change.");
            if (placement && bookings.countByShowId(s.getId()) > 0)
                throw new ConflictException("This show already has bookings, so its movie and screen are locked. Cancel the show (customers are refunded) and create a new one.");
            if (bookings.countLiveByShow(s.getId()) > 0)
                throw new ConflictException("This show already has bookings, so its time and prices are locked. You can cancel the show (customers are refunded) and create a new one.");
        }

        Movie movie = s.getMovie();
        if (movieChange) {
            movie = movies.findById(r.movieId()).orElseThrow(() -> new NotFoundException("Movie not found"));
            if (movie.getStatus() == MovieStatus.ARCHIVED) throw new BadRequestException("Archived movies cannot be scheduled");
            if (movie.getStatus() == MovieStatus.PENDING_REVIEW) throw new BadRequestException("This movie is not in the catalogue yet");
        }
        Screen screen = s.getScreen();
        if (screenChange) {
            screen = screens.findById(r.screenId()).orElseThrow(() -> new NotFoundException("Screen not found"));
            if (!screen.getTheatre().getId().equals(theatre.getId())) throw new ForbiddenException("This screen belongs to another theatre");
            if (!screen.isActive()) throw new BadRequestException("Screen is not active");
        }
        LocalDateTime start = timeChange ? r.startTime() : s.getStartTime();
        if (timeChange && !start.isAfter(now)) throw new BadRequestException("Show must start in the future");

        // language: an explicit choice wins; a new movie falls back to its first language when the old one does not exist there
        String lang = r.audioLanguage() != null && !r.audioLanguage().isBlank() ? r.audioLanguage().trim() : null;
        if (lang == null && movieChange) {
            String cur = s.getAudioLanguage();
            boolean stillValid = cur != null && java.util.Arrays.stream(movie.getLanguage().split(",")).anyMatch(l -> l.trim().equalsIgnoreCase(cur));
            lang = stillValid ? cur : movie.getLanguage().split(",")[0].trim();
        }
        if (lang != null) checkLanguage(movie, lang);

        if (placement || timeChange) {
            if (movieChange && movie.getReleaseDate() != null && start.toLocalDate().isBefore(movie.getReleaseDate()))
                throw new BadRequestException("Movie releases on " + movie.getReleaseDate());
            checkListing(theatre, movie, start);
            LocalDateTime end = start.plusMinutes(movie.getDurationMinutes() + bufferMinutes);
            if (shows.countOverlappingExcluding(screen.getId(), ShowStatus.SCHEDULED, start, end, s.getId()) > 0)
                throw new ConflictException("Screen \"" + screen.getName() + "\" already has a show overlapping that time");
            s.setStartTime(start);
            s.setEndTime(end);
        }
        s.setMovie(movie);
        if (lang != null) s.setAudioLanguage(lang);
        if (r.dimension() != null && !r.dimension().isBlank()) s.setDimension(r.dimension().trim());
        if (r.specialFormats() != null) s.setSpecialFormats(r.specialFormats().isBlank() ? null : r.specialFormats().trim());

        List<ShowSeat> inv = showSeats.findMap(s.getId());
        if (screenChange) {
            java.util.Map<String, java.math.BigDecimal> merged = new java.util.LinkedHashMap<>();
            for (ShowSeat ss : inv) merged.putIfAbsent(sectionOf(ss.getSeat()), ss.getPrice());      // keep today's prices for sections the new screen shares
            if (priceChange) r.sectionPrices().forEach((k, v) -> {
                if (k == null || v == null) return;
                merged.keySet().removeIf(x -> x.trim().equalsIgnoreCase(k.trim()));
                merged.put(k.trim(), v);
            });
            List<Seat> active = seats.findByScreenIdAndActiveTrue(screen.getId());
            if (active.isEmpty()) throw new BadRequestException("Screen has no active seats");
            List<java.math.BigDecimal> prices = new java.util.ArrayList<>();
            for (Seat seat : active) prices.add(priceFor(seat, merged, null, null));                 // throws "Set a ticket price for the section ..." when one is missing
            showSeats.deleteAll(inv);
            showSeats.flush();
            s.setScreen(screen);
            List<ShowSeat> fresh = new java.util.ArrayList<>();
            for (int i = 0; i < active.size(); i++) {
                ShowSeat ss = new ShowSeat();
                ss.setShow(s); ss.setSeat(active.get(i)); ss.setPrice(prices.get(i));
                fresh.add(ss);
            }
            showSeats.saveAll(fresh);
            s.setRegularPrice(java.util.Collections.min(prices));
            s.setPremiumPrice(java.util.Collections.max(prices));
            return mapper.show(s, fresh.size(), fresh.size(), 0);
        }
        if (priceChange) {
            List<java.math.BigDecimal> all = new java.util.ArrayList<>();
            for (ShowSeat ss : inv) { java.math.BigDecimal p = priceFor(ss.getSeat(), r.sectionPrices(), null, null); ss.setPrice(p); all.add(p); }
            if (!all.isEmpty()) { s.setRegularPrice(java.util.Collections.min(all)); s.setPremiumPrice(java.util.Collections.max(all)); }
        }
        long total = inv.size(), booked = inv.stream().filter(x -> x.getState() == SeatState.BOOKED).count();
        return mapper.show(s, showSeats.countByShowIdAndState(s.getId(), SeatState.AVAILABLE), total, booked);
    }

    /** Used when a theatre removes a movie: every upcoming show of it is cancelled and its bookings refunded. Returns how many shows were cancelled. */
    @Transactional
    public int cancelUpcomingForMovie(Theatre theatre, Long movieId, String reason) {
        List<Show> upcoming = shows.findUpcomingForMovie(theatre.getId(), movieId, LocalDateTime.now());
        for (Show s : upcoming) {
            s.setStatus(ShowStatus.CANCELLED);
            s.setCancelReason(reason.length() > 300 ? reason.substring(0, 300) : reason);
            bookingService.cancelAllForShow(s);
        }
        return upcoming.size();
    }

    @Transactional(readOnly = true)
    public List<ShowView> list(User owner) {
        Theatre t = theatreService.requireOwned(owner);
        java.util.Map<Long, long[]> counts = new java.util.HashMap<>();          // showId -> {total, available, booked}
        for (Object[] row : showSeats.countsByTheatre(t.getId())) {
            long[] c = counts.computeIfAbsent(((Number) row[0]).longValue(), k -> new long[3]);
            long n = ((Number) row[2]).longValue();
            c[0] += n;
            if (row[1] == SeatState.AVAILABLE) c[1] += n;
            if (row[1] == SeatState.BOOKED) c[2] += n;
        }
        return shows.findByScreen_Theatre_IdOrderByStartTimeDesc(t.getId()).stream().map(s -> {
            long[] c = counts.getOrDefault(s.getId(), new long[3]);
            return mapper.show(s, c[1], c[0], c[2]);
        }).toList();
    }

    public record ScreeningRun(Long screenId, String screenName, Long movieId, String title, String posterUrl, String language,
                               java.time.LocalDate fromDate, java.time.LocalDate toDate, int shows, String status) {}

    /**
     * Every movie that has played (or is booked to play) on each screen, with its dates. A run is a stretch of days with shows;
     * a gap of more than one day starts a new run, so a movie that came back later appears twice. Cancelled shows are not counted.
     */
    @Transactional(readOnly = true)
    public List<ScreeningRun> screenHistory(User owner) {
        Theatre t = theatreService.requireOwned(owner);
        java.time.LocalDate today = java.time.LocalDate.now();
        java.util.Map<String, List<Show>> groups = new java.util.LinkedHashMap<>();
        for (Show s : shows.findByScreen_Theatre_IdOrderByStartTimeDesc(t.getId())) {
            if (s.getStatus() != ShowStatus.SCHEDULED) continue;
            groups.computeIfAbsent(s.getScreen().getId() + ":" + s.getMovie().getId(), k -> new java.util.ArrayList<>()).add(s);
        }
        List<ScreeningRun> out = new java.util.ArrayList<>();
        for (List<Show> g : groups.values()) {
            g.sort(java.util.Comparator.comparing(Show::getStartTime));
            Show first = g.get(0);
            java.time.LocalDate from = null, to = null;
            int count = 0;
            for (Show s : g) {
                java.time.LocalDate d = s.getStartTime().toLocalDate();
                if (from != null && d.isAfter(to.plusDays(1))) { out.add(run(first, from, to, count, today)); from = null; count = 0; }
                if (from == null) from = d;
                to = d; count++;
            }
            if (from != null) out.add(run(first, from, to, count, today));
        }
        out.sort(java.util.Comparator.comparing(ScreeningRun::toDate).reversed().thenComparing(ScreeningRun::screenName));
        return out;
    }

    private ScreeningRun run(Show s, java.time.LocalDate from, java.time.LocalDate to, int count, java.time.LocalDate today) {
        String st = to.isBefore(today) ? "COMPLETED" : from.isAfter(today) ? "UPCOMING" : "RUNNING";
        Movie m = s.getMovie();
        return new ScreeningRun(s.getScreen().getId(), s.getScreen().getName(), m.getId(), m.getTitle(), m.getPosterUrl(), m.getLanguage(), from, to, count, st);
    }

    @Transactional
    public void cancel(User owner, Long showId, String reason) {
        Theatre t = theatreService.requireOwned(owner);
        Show s = shows.findById(showId).orElseThrow(() -> new NotFoundException("Show not found"));
        if (!s.getScreen().getTheatre().getId().equals(t.getId())) throw new ForbiddenException("Not your show");
        if (s.getStatus() == ShowStatus.CANCELLED) throw new BadRequestException("Show already cancelled");
        if (reason == null || reason.trim().length() < 5) throw new BadRequestException("Please give a reason for cancelling the show");
        s.setStatus(ShowStatus.CANCELLED);
        s.setCancelReason(reason.trim());
        bookingService.cancelAllForShow(s);
    }

    public record BlockRequest(List<Long> seatIds, boolean block) {}

    /** Theatre keeps back (or releases) individual seats of one show. Booked/held-by-customer seats are never touched. */
    @Transactional
    public int blockSeats(User owner, Long showId, BlockRequest r) {
        Theatre theatre = theatreService.requireApproved(owner);
        Show s = shows.findById(showId).orElseThrow(() -> new NotFoundException("Show not found"));
        if (!s.getScreen().getTheatre().getId().equals(theatre.getId())) throw new ForbiddenException("Not your show");
        if (s.getStatus() != ShowStatus.SCHEDULED) throw new BadRequestException("Only scheduled shows can be changed");
        if (r.seatIds() == null || r.seatIds().isEmpty()) throw new BadRequestException("Select at least one seat");
        int changed = 0;
        for (ShowSeat ss : showSeats.findSeatsNoLock(showId, r.seatIds())) {
            if (r.block() && ss.getState() == SeatState.AVAILABLE) {
                ss.setState(SeatState.LOCKED); ss.setBooking(null); ss.setLockedUntil(LocalDateTime.of(9999, 12, 31, 0, 0)); changed++;
            } else if (!r.block() && CatalogService.isBlocked(ss)) {
                ss.setState(SeatState.AVAILABLE); ss.setLockedUntil(null); changed++;
            }
        }
        return changed;
    }
}
