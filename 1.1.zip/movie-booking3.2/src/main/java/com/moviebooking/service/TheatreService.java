package com.moviebooking.service;

import com.moviebooking.dto.Dtos.*;
import com.moviebooking.entity.*;
import com.moviebooking.enums.*;
import com.moviebooking.exception.*;
import com.moviebooking.repository.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Theatre-admin operations. The theatre is always derived from the logged-in owner (ownership check). */
@Service
@RequiredArgsConstructor
public class TheatreService {
    private final TheatreRepository theatres;
    private final ScreenRepository screens;
    private final SeatRepository seats;
    private final LocationRepository locations;
    private final BookingRepository bookings;
    private final ShowRepository shows;
    private final TheatreStatusHistoryRepository history;
    private final NotificationService notifications;
    private final ViewMapper mapper;

    static void apply(Theatre t, TheatreDetails d) {
        t.setName(d.theatreName().trim());
        t.setAddress(d.address().trim());
        t.setManagerName(d.managerName());
        t.setContactPhone(d.contactPhone());
        t.setLicenseNumber(d.licenseNumber().trim());
        t.setLicenseExpiry(d.licenseExpiry());
        t.setBankAccountHolder(d.bankAccountHolder());
        t.setBankAccountNumber(d.bankAccountNumber());
        t.setBankIfsc(d.bankIfsc());
        t.setFacilities(d.facilities());
    }

    public Theatre requireOwned(User owner) {
        return theatres.findByOwnerId(owner.getId()).orElseThrow(() -> new NotFoundException("No theatre registered for this account"));
    }

    public Theatre requireApproved(User owner) {
        Theatre t = requireOwned(owner);
        if (t.getStatus() != TheatreStatus.APPROVED)
            throw new ForbiddenException("Your theatre is " + t.getStatus() + ". This action needs an approved theatre.");
        return t;
    }

    @Transactional(readOnly = true)
    public TheatreView myTheatre(User owner) {
        Theatre t = requireOwned(owner);
        return mapper.theatre(t, screens.findByTheatreIdOrderByName(t.getId()));
    }

    @Transactional(readOnly = true)
    public List<HistoryView> myHistory(User owner) {
        Theatre t = requireOwned(owner);
        return history.findByTheatreIdOrderByCreatedAtDesc(t.getId()).stream()
                .map(h -> new HistoryView(h.getFromStatus() == null ? null : h.getFromStatus().name(),
                        h.getToStatus().name(), h.getReason(), h.getActorEmail(), h.getCreatedAt())).toList();
    }

    /**
     * CHANGES_REQUIRED / REJECTED theatres may correct everything and resubmit (-> PENDING_VERIFICATION).
     * Approved/suspended theatres may only change contact details and facilities; licence, bank and
     * location changes need a new verification and are not allowed through this call.
     */
    @Transactional
    public TheatreView update(User owner, TheatreDetails d) {
        Theatre t = requireOwned(owner);
        TheatreStatus before = t.getStatus();
        if (before == TheatreStatus.CHANGES_REQUIRED) {
            Location city = locations.findById(d.cityId()).orElseThrow(() -> new BadRequestException("Unknown city"));
            if (city.getType() != LocationType.CITY) throw new BadRequestException("Location must be a city");
            t.setCity(city);
            apply(t, d);
            t.setStatus(TheatreStatus.PENDING_VERIFICATION);
            t.setStatusReason(null);
            TheatreStatusHistory h = new TheatreStatusHistory();
            h.setTheatre(t);
            h.setFromStatus(before);
            h.setToStatus(TheatreStatus.PENDING_VERIFICATION);
            h.setReason("Corrections submitted by owner");
            h.setActorEmail(owner.getEmail());
            history.save(h);
            notifications.notifySuperAdmins("Theatre resubmitted after corrections: " + t.getName());
        } else if (before == TheatreStatus.APPROVED || before == TheatreStatus.SUSPENDED) {
            t.setManagerName(d.managerName());
            t.setContactPhone(d.contactPhone());
            t.setFacilities(d.facilities());
        } else {
            throw new ForbiddenException("Theatre cannot be edited while " + before);
        }
        return mapper.theatre(t, screens.findByTheatreIdOrderByName(t.getId()));
    }

    @Transactional
    public ScreenView addScreen(User owner, ScreenRequest r) {
        Theatre t = requireApproved(owner);
        if (r.premiumRows() > r.rows()) throw new BadRequestException("Premium rows cannot exceed total rows");
        if (screens.existsByTheatreIdAndNameIgnoreCase(t.getId(), r.name().trim()))
            throw new ConflictException("A screen with this name already exists");
        Screen s = new Screen();
        s.setTheatre(t);
        s.setName(r.name().trim());
        s.setTotalSeats(r.rows() * r.seatsPerRow());
        screens.save(s);
        List<Seat> layout = new ArrayList<>();
        for (int row = 0; row < r.rows(); row++) {
            boolean premium = row >= r.rows() - r.premiumRows();   // back rows are premium
            for (int n = 1; n <= r.seatsPerRow(); n++) {
                Seat seat = new Seat();
                seat.setScreen(s);
                seat.setRowLabel(String.valueOf((char) ('A' + row)));
                seat.setSeatNumber(n);
                seat.setCategory(premium ? SeatCategory.PREMIUM : SeatCategory.REGULAR);
                layout.add(seat);
            }
        }
        seats.saveAll(layout);
        return mapper.screen(s);
    }

    /** Rename always; the seat layout can only change while the screen has never had a show. */
    @Transactional
    public ScreenView updateScreen(User owner, Long screenId, ScreenUpdateRequest r) {
        Theatre t = requireApproved(owner);
        Screen s = screens.findById(screenId).orElseThrow(() -> new NotFoundException("Screen not found"));
        if (!s.getTheatre().getId().equals(t.getId())) throw new ForbiddenException("Not your screen");
        String name = r.name().trim();
        if (!name.equalsIgnoreCase(s.getName()) && screens.existsByTheatreIdAndNameIgnoreCase(t.getId(), name))
            throw new ConflictException("A screen with this name already exists");
        s.setName(name);
        boolean layout = r.rows() != null && r.seatsPerRow() != null;
        if (layout) {
            int premium = r.premiumRows() == null ? 0 : r.premiumRows();
            if (premium > r.rows()) throw new BadRequestException("Premium rows cannot exceed total rows");
            if (shows.existsByScreenId(s.getId())) throw new ConflictException("The seat layout is locked because this screen already has shows. You can still rename it.");
            seats.deleteByScreenId(s.getId());
            seats.flush();
            List<Seat> fresh = new ArrayList<>();
            for (int row = 0; row < r.rows(); row++) {
                boolean prem = row >= r.rows() - premium;
                for (int n = 1; n <= r.seatsPerRow(); n++) {
                    Seat seat = new Seat();
                    seat.setScreen(s);
                    seat.setRowLabel(String.valueOf((char) ('A' + row)));
                    seat.setSeatNumber(n);
                    seat.setCategory(prem ? SeatCategory.PREMIUM : SeatCategory.REGULAR);
                    fresh.add(seat);
                }
            }
            seats.saveAll(fresh);
            s.setTotalSeats(r.rows() * r.seatsPerRow());
        }
        return mapper.screen(s);
    }

    private static final com.fasterxml.jackson.databind.ObjectMapper JSON = new com.fasterxml.jackson.databind.ObjectMapper();

    /** Create (screenId == null) or edit a screen with a fully custom seating plan. Layout is locked once the screen has shows; name and formats can always change. */
    @Transactional
    public ScreenView saveLayout(User owner, Long screenId, LayoutRequest r) {
        Theatre t = requireApproved(owner);
        String name = r.name().trim();
        List<ScreenLayoutParser.SeatSpec> specs = ScreenLayoutParser.parse(r.rows());
        String json;
        try { json = JSON.writeValueAsString(r.rows()); } catch (Exception e) { throw new BadRequestException("Could not read the layout"); }
        if (json.length() > 15000) throw new BadRequestException("The layout is too large");
        Screen s;
        boolean replaceSeats = true;
        if (screenId == null) {
            if (screens.existsByTheatreIdAndNameIgnoreCase(t.getId(), name)) throw new ConflictException("A screen with this name already exists");
            s = new Screen();
            s.setTheatre(t);
        } else {
            s = screens.findById(screenId).orElseThrow(() -> new NotFoundException("Screen not found"));
            if (!s.getTheatre().getId().equals(t.getId())) throw new ForbiddenException("Not your screen");
            if (!name.equalsIgnoreCase(s.getName()) && screens.existsByTheatreIdAndNameIgnoreCase(t.getId(), name)) throw new ConflictException("A screen with this name already exists");
            if (shows.existsByScreenId(s.getId())) {
                if (!json.equals(s.getLayoutJson())) throw new ConflictException("The seating plan is locked because this screen already has shows. You can still rename it or change its formats.");
                replaceSeats = false;
            }
        }
        s.setName(name);
        s.setSpecialFormats(r.specialFormats() == null || r.specialFormats().isBlank() ? null : r.specialFormats().trim());
        if (replaceSeats) { s.setLayoutJson(json); s.setTotalSeats(specs.size()); }
        screens.save(s);
        if (replaceSeats) {
            if (screenId != null) { seats.deleteByScreenId(s.getId()); seats.flush(); }
            List<Seat> fresh = new ArrayList<>();
            for (ScreenLayoutParser.SeatSpec sp : specs) {
                Seat seat = new Seat();
                seat.setScreen(s);
                seat.setRowLabel(sp.row());
                seat.setSeatNumber(sp.number());
                seat.setCategory(SeatCategory.REGULAR);
                seat.setSection(sp.section());
                seat.setGridRow(sp.gridRow());
                seat.setGridCol(sp.gridCol());
                fresh.add(seat);
            }
            seats.saveAll(fresh);
        }
        return mapper.screen(s);
    }

    /** The rows as designed, for re-opening the designer. */
    @Transactional(readOnly = true)
    public Map<String, Object> layoutOf(User owner, Long screenId) {
        Theatre t = requireOwned(owner);
        Screen s = screens.findById(screenId).orElseThrow(() -> new NotFoundException("Screen not found"));
        if (!s.getTheatre().getId().equals(t.getId())) throw new ForbiddenException("Not your screen");
        List<RowDef> rows = List.of();
        try { if (s.getLayoutJson() != null) rows = JSON.readValue(s.getLayoutJson(), new com.fasterxml.jackson.core.type.TypeReference<List<RowDef>>() {}); } catch (Exception ignored) { }
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("id", s.getId()); out.put("name", s.getName()); out.put("specialFormats", s.getSpecialFormats()); out.put("rows", rows);
        out.put("locked", shows.existsByScreenId(s.getId())); out.put("designed", s.getLayoutJson() != null);
        return out;
    }

    @Transactional
    public void updateSpecs(User owner, SpecsRequest r) {
        Theatre t = requireApproved(owner);
        t.setFacilities(r.facilities() == null || r.facilities().isBlank() ? null : r.facilities().trim());
        if (r.cancellationAvailable() != null) t.setCancellationAvailable(r.cancellationAvailable());
    }

    @Transactional(readOnly = true)
    public Map<String, Object> specsOf(User owner) {
        Theatre t = requireOwned(owner);
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("facilities", t.getFacilities()); out.put("cancellationAvailable", t.isCancellable());
        out.put("bookingWindowDays", t.windowDays());
        return out;
    }

    /** How many days ahead customers can book (4 to 7, today included). The date strip on the customer side follows this. */
    @Transactional
    public int setBookingWindow(User owner, int days) {
        if (days < 4 || days > 7) throw new BadRequestException("Choose between 4 and 7 days");
        Theatre t = requireApproved(owner);
        t.setBookingWindowDays(days);
        return t.windowDays();
    }

    @Transactional(readOnly = true)
    public List<ScreenView> myScreens(User owner) {
        Theatre t = requireOwned(owner);
        return screens.findByTheatreIdOrderByName(t.getId()).stream().map(mapper::screen).toList();
    }

    @Transactional(readOnly = true)
    public List<BookingView> myBookings(User owner) {
        Theatre t = requireOwned(owner);
        return bookings.findByShow_Screen_Theatre_IdOrderByCreatedAtDesc(t.getId()).stream()
                .filter(b -> b.getStatus() != BookingStatus.EXPIRED).map(mapper::booking).toList();
    }
}
