package com.moviebooking.service;

import com.moviebooking.dto.Dtos.*;
import com.moviebooking.entity.*;
import com.moviebooking.enums.TheatreAction;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/** Entity -> DTO conversion. Call only inside a transaction (lazy associations are read here). */
@Component
@RequiredArgsConstructor
public class ViewMapper {
    private final CommissionPolicy commission;

    public UserView user(User u) {
        return new UserView(u.getId(), u.getName(), u.getEmail(), u.getPhone(), u.getAddress(), u.getRole().name(), u.isActive());
    }

    public LocationView location(Location l) {
        return new LocationView(l.getId(), l.getName(), l.getType().name(), l.getParent() == null ? null : l.getParent().getId());
    }

    public TheatreView theatre(Theatre t, List<Screen> screens) {
        Location city = t.getCity();
        Location district = city.getParent();
        Location state = district == null ? null : district.getParent();
        return new TheatreView(t.getId(), t.getName(), t.getAddress(), city.getName(),
                district == null ? null : district.getName(), state == null ? null : state.getName(),
                t.getOwner().getName(), t.getOwner().getEmail(), t.getContactPhone(), t.getLicenseNumber(),
                t.getLicenseExpiry(), t.getFacilities(), t.getStatus().name(), t.getStatusReason(),
                t.getCommissionPercent(), commission.effectiveRate(t), screens.size(),
                screens.stream().mapToInt(Screen::getTotalSeats).sum(),
                TheatreAction.availableFor(t.getStatus()).stream().map(Enum::name).toList(), t.getCreatedAt());
    }

    public ScreenView screen(Screen s) {
        return new ScreenView(s.getId(), s.getName(), s.getTotalSeats(), s.isActive(),
                s.getCommissionPercent(), commission.effectiveRate(s));
    }

    public ShowView show(Show s, long available) { return show(s, available, 0, 0); }

    /** totalSeats / bookedSeats let the theatre dashboard show occupancy; 0 means "not counted" for the public lists. */
    public ShowView show(Show s, long available, long totalSeats, long bookedSeats) {
        Theatre t = s.getScreen().getTheatre();
        return new ShowView(s.getId(), s.getMovie().getId(), s.getMovie().getTitle(), t.getId(), t.getName(),
                s.getScreen().getName(), s.getStartTime(), s.getEndTime(), s.getRegularPrice(), s.getPremiumPrice(),
                s.getStatus().name(), available, s.getAudioLanguage(), s.getDimension(), s.getSpecialFormats(), totalSeats, bookedSeats);
    }

    public BookingView booking(Booking b) {
        return booking(b, null);
    }

    public BookingView booking(Booking b, String message) {
        Show s = b.getShow();
        return new BookingView(b.getReference(), b.getStatus().name(), b.getPaymentStatus().name(),
                s.getMovie().getTitle(), s.getScreen().getTheatre().getName(), s.getScreen().getName(),
                s.getStartTime(), b.getSeatLabels(), b.getTotalAmount(), b.getHoldExpiresAt(),
                b.getRefundAmount(), b.getRefundStatus(), b.getCustomer().getName(), b.getCustomer().getId(), message);
    }
}
