package com.moviebooking.service.metadata;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Map;
import org.springframework.stereotype.Component;

/** Small HTTP helper: timeouts, 3 attempts for transient failures, and error messages that never contain the URL (it may hold an API key). */
@Component
public class HttpFetcher {
    private static final class Fatal extends IOException { Fatal(String m) { super(m); } }

    private final HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();

    public String get(String url, Map<String, String> headers) throws IOException {
        String host = URI.create(url).getHost();
        IOException last = null;
        for (int attempt = 1; attempt <= 3; attempt++) {
            try {
                HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(25))
                        .header("Accept", "application/json").header("User-Agent", "CineBook/1.0 (movie booking project)");
                headers.forEach(b::header);
                HttpResponse<String> r = client.send(b.GET().build(), HttpResponse.BodyHandlers.ofString());
                int c = r.statusCode();
                if (c >= 200 && c < 300) return r.body();
                if (c == 429 || c >= 500) last = new IOException(host + " returned HTTP " + c);
                else throw new Fatal(host + " returned HTTP " + c + (c == 401 || c == 403 ? " (check the API key)" : ""));
            } catch (Fatal f) {
                throw f;
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new IOException("Import interrupted");
            } catch (IOException e) {
                last = new IOException("Cannot reach " + host + " (" + e.getClass().getSimpleName() + "). The site may be blocked by your network.");
            }
            try { Thread.sleep(attempt * 1500L); } catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new IOException("Import interrupted"); }
        }
        throw last;
    }
}
