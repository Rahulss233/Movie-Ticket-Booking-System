package com.moviebooking.service.metadata;

import java.time.LocalDate;
import lombok.Getter;
import lombok.Setter;

/** Provider-neutral movie record produced by any metadata source. */
@Getter
@Setter
public class ImportedMovie {
    private String source;
    private String externalId;
    private String title;
    private String language;
    private LocalDate releaseDate;
    private String description;
    private String posterUrl;
    private String genre;
    private Integer runtimeMinutes;

    public boolean isIncomplete() {
        return description == null || description.length() < 40 || posterUrl == null || genre == null || runtimeMinutes == null;
    }
}
