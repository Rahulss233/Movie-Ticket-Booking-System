package com.moviebooking.service.metadata;

import java.util.Map;

final class LanguageNames {
    private static final Map<String, String> NAMES = Map.ofEntries(
            Map.entry("hi", "Hindi"), Map.entry("ta", "Tamil"), Map.entry("te", "Telugu"), Map.entry("ml", "Malayalam"),
            Map.entry("kn", "Kannada"), Map.entry("bn", "Bengali"), Map.entry("mr", "Marathi"), Map.entry("pa", "Punjabi"),
            Map.entry("gu", "Gujarati"), Map.entry("en", "English"), Map.entry("or", "Odia"), Map.entry("as", "Assamese"));

    private LanguageNames() {}

    static String of(String code) { return code == null ? null : NAMES.getOrDefault(code.toLowerCase(), null); }
}
