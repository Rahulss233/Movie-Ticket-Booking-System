package com.moviebooking.service.metadata;

import java.util.List;

/** Implement this to plug in a new movie data source. Register it as a Spring @Component. */
public interface MovieMetadataProvider {
    /** Short unique name, e.g. TMDB. Stored on imported movies as externalSource. */
    String name();

    /** False when a required API key is missing; unconfigured providers are skipped. */
    boolean isConfigured();

    /** Upcoming and recently released Indian films. Throw an exception on failure (the caller records it). */
    List<ImportedMovie> fetchUpcoming() throws Exception;
}
