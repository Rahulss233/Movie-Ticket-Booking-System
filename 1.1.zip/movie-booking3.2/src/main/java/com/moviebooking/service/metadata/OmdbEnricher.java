package com.moviebooking.service.metadata;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/** Optional: fills missing plot/poster/runtime/genre by title+year using OMDb. OMDb cannot list upcoming films, so it only enriches. */
@Component
@RequiredArgsConstructor
public class OmdbEnricher {
    private final HttpFetcher http;
    private final ObjectMapper mapper;
    @Value("${app.omdb.api-key:}") private String key;

    public boolean isConfigured() { return key != null && !key.isBlank() && !key.startsWith("PASTE_"); }

    public void enrich(ImportedMovie m) {
        if (!isConfigured() || !m.isIncomplete() || m.getTitle() == null) return;
        try {
            String url = "https://www.omdbapi.com/?apikey=" + URLEncoder.encode(key, StandardCharsets.UTF_8) + "&type=movie&plot=full&t="
                    + URLEncoder.encode(m.getTitle(), StandardCharsets.UTF_8) + (m.getReleaseDate() != null ? "&y=" + m.getReleaseDate().getYear() : "");
            JsonNode n = mapper.readTree(http.get(url, Map.of()));
            if (!"True".equals(n.path("Response").asText())) return;
            String plot = n.path("Plot").asText("N/A");
            if ((m.getDescription() == null || m.getDescription().length() < 40) && !"N/A".equals(plot)) m.setDescription(plot);
            String poster = n.path("Poster").asText("N/A");
            if (m.getPosterUrl() == null && poster.startsWith("http")) m.setPosterUrl(poster);
            String genre = n.path("Genre").asText("N/A");
            if (m.getGenre() == null && !"N/A".equals(genre)) m.setGenre(genre);
            String rt = n.path("Runtime").asText("").replaceAll("\\D", "");
            if (m.getRuntimeMinutes() == null && !rt.isBlank()) m.setRuntimeMinutes(Integer.parseInt(rt));
        } catch (Exception ignored) { /* enrichment is best effort */ }
    }
}
