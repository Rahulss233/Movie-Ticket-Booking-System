package com.moviebooking.service.metadata;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.*;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/** TMDB: best data (posters, plots, runtime). Needs a key; some Indian ISPs block it, so the base URL is configurable (proxy). */
@Component
@RequiredArgsConstructor
public class TmdbProvider implements MovieMetadataProvider {
    private static final List<String> LANGS = List.of("hi", "ta", "te", "ml", "kn", "bn", "mr", "en");
    private static final int MAX_DETAIL_CALLS = 80;

    private final HttpFetcher http;
    private final ObjectMapper mapper;
    @Value("${app.tmdb.api-key:}") private String apiKey;
    @Value("${app.tmdb.base-url:https://api.themoviedb.org/3}") private String baseUrl;
    @Value("${app.tmdb.image-base-url:https://image.tmdb.org/t/p/w500}") private String imageBase;

    @Override public String name() { return "TMDB"; }

    @Override public boolean isConfigured() { return apiKey != null && !apiKey.isBlank() && !apiKey.startsWith("PASTE_"); }

    private boolean bearer() { return apiKey.startsWith("eyJ"); } // v4 read-access token

    private volatile String activeBase;

    /** Uses the configured address; if it cannot be reached (ISP block), tries TMDB's backup address api.tmdb.org and remembers whichever works. */
    private JsonNode call(String path, String query) throws Exception {
        String q = query + (bearer() ? "" : "&api_key=" + URLEncoder.encode(apiKey, StandardCharsets.UTF_8));
        Map<String, String> h = bearer() ? Map.of("Authorization", "Bearer " + apiKey) : Map.of();
        String first = activeBase != null ? activeBase : baseUrl;
        try {
            return mapper.readTree(http.get(first + path + "?" + q, h));
        } catch (java.io.IOException e) {
            String backup = baseUrl.contains("api.themoviedb.org") ? baseUrl.replace("api.themoviedb.org", "api.tmdb.org") : null;
            if (backup == null || backup.equals(first)) throw e;
            JsonNode ok = mapper.readTree(http.get(backup + path + "?" + q, h));
            activeBase = backup;
            return ok;
        }
    }

    @Override
    public List<ImportedMovie> fetchUpcoming() throws Exception {
        LocalDate from = LocalDate.now().minusDays(21), to = LocalDate.now().plusDays(120);
        Map<Integer, String> genres = new HashMap<>();
        for (JsonNode g : call("/genre/movie/list", "language=en-US").path("genres")) genres.put(g.path("id").asInt(), g.path("name").asText());
        Map<String, ImportedMovie> byId = new LinkedHashMap<>();
        for (String lang : LANGS) {
            for (int page = 1; page <= 2; page++) {
                JsonNode res = call("/discover/movie", "region=IN&language=en-US&include_adult=false&sort_by=primary_release_date.asc&with_release_type=2%7C3"
                        + "&release_date.gte=" + from + "&release_date.lte=" + to + "&with_original_language=" + lang + "&page=" + page).path("results");
                for (JsonNode row : res) {
                    String id = row.path("id").asText("");
                    if (id.isBlank() || byId.containsKey(id)) continue;
                    ImportedMovie m = new ImportedMovie();
                    m.setSource(name()); m.setExternalId(id);
                    m.setTitle(row.path("title").asText("").trim());
                    m.setLanguage(LanguageNames.of(row.path("original_language").asText("")));
                    m.setDescription(blankToNull(row.path("overview").asText("")));
                    String poster = row.path("poster_path").asText("");
                    m.setPosterUrl(poster.isBlank() ? null : imageBase + poster);
                    String date = row.path("release_date").asText("");
                    if (date.matches("\\d{4}-\\d{2}-\\d{2}")) m.setReleaseDate(LocalDate.parse(date));
                    List<String> gn = new ArrayList<>();
                    for (JsonNode gid : row.path("genre_ids")) { String n = genres.get(gid.asInt()); if (n != null) gn.add(n); }
                    m.setGenre(gn.isEmpty() ? null : String.join(", ", gn.subList(0, Math.min(3, gn.size()))));
                    byId.put(id, m);
                }
                if (res.size() < 20) break;
            }
        }
        int detailCalls = 0; // runtime is only in the detail endpoint
        for (ImportedMovie m : byId.values()) {
            if (detailCalls++ >= MAX_DETAIL_CALLS) break;
            try {
                int rt = call("/movie/" + m.getExternalId(), "language=en-US").path("runtime").asInt(0);
                if (rt > 0) m.setRuntimeMinutes(rt);
            } catch (Exception ignored) { /* runtime stays null -> record goes to review */ }
        }
        return new ArrayList<>(byId.values());
    }

    private static String blankToNull(String s) { return s == null || s.isBlank() ? null : s.trim(); }
}
