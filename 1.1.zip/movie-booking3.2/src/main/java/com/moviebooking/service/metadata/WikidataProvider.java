package com.moviebooking.service.metadata;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.*;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/** Wikidata SPARQL: free, no key, so import never depends on TMDB alone. Coverage of unreleased Indian films is partial and
 *  plots are rarely present, so most of its records will wait in the review queue unless OMDb enrichment fills the gaps. */
@Component
@RequiredArgsConstructor
public class WikidataProvider implements MovieMetadataProvider {
    private final HttpFetcher http;
    private final ObjectMapper mapper;
    @Value("${app.wikidata.enabled:true}") private boolean enabled;
    @Value("${app.wikidata.endpoint:https://query.wikidata.org/sparql}") private String endpoint;

    @Override public String name() { return "WIKIDATA"; }

    @Override public boolean isConfigured() { return enabled; }

    @Override
    public List<ImportedMovie> fetchUpcoming() throws Exception {
        LocalDate from = LocalDate.now().minusDays(21), to = LocalDate.now().plusDays(120);
        String q = "SELECT ?film ?filmLabel ?date ?langLabel ?genreLabel ?poster ?dur WHERE { "
                + "?film wdt:P31 wd:Q11424; wdt:P495 wd:Q668; wdt:P577 ?date. "
                + "FILTER(?date >= \"" + from + "T00:00:00Z\"^^xsd:dateTime && ?date <= \"" + to + "T00:00:00Z\"^^xsd:dateTime) "
                + "OPTIONAL { ?film wdt:P364 ?lang } OPTIONAL { ?film wdt:P136 ?genre } OPTIONAL { ?film wdt:P3383 ?poster } "
                + "OPTIONAL { ?film p:P2047/psn:P2047/wikibase:quantityAmount ?dur } "
                + "SERVICE wikibase:label { bd:serviceParam wikibase:language \"en\". } } LIMIT 500";
        String url = endpoint + "?format=json&query=" + URLEncoder.encode(q, StandardCharsets.UTF_8);
        JsonNode rows = mapper.readTree(http.get(url, Map.of())).path("results").path("bindings");
        Map<String, ImportedMovie> byId = new LinkedHashMap<>();
        Map<String, LinkedHashSet<String>> genres = new HashMap<>();
        for (JsonNode r : rows) {
            String uri = r.path("film").path("value").asText("");
            String id = uri.substring(uri.lastIndexOf('/') + 1);
            String title = r.path("filmLabel").path("value").asText("").trim();
            if (id.isBlank() || title.isBlank() || title.matches("Q\\d+")) continue; // no English label yet
            ImportedMovie m = byId.computeIfAbsent(id, k -> new ImportedMovie());
            m.setSource(name()); m.setExternalId(id); m.setTitle(title);
            String d = r.path("date").path("value").asText("");
            if (d.length() >= 10 && m.getReleaseDate() == null) m.setReleaseDate(LocalDate.parse(d.substring(0, 10)));
            String lang = r.path("langLabel").path("value").asText("");
            if (!lang.isBlank() && !lang.matches("Q\\d+")) m.setLanguage(lang.replace(" language", ""));
            String g = r.path("genreLabel").path("value").asText("");
            if (!g.isBlank() && !g.matches("Q\\d+")) genres.computeIfAbsent(id, k -> new LinkedHashSet<>()).add(g.replace(" film", ""));
            String poster = r.path("poster").path("value").asText("");
            if (!poster.isBlank() && m.getPosterUrl() == null)
                m.setPosterUrl("https://commons.wikimedia.org/wiki/Special:FilePath/" + URLEncoder.encode(poster, StandardCharsets.UTF_8).replace("+", "%20") + "?width=500");
            double dur = r.path("dur").path("value").asDouble(0);
            if (dur > 0 && m.getRuntimeMinutes() == null) m.setRuntimeMinutes((int) Math.round(dur > 1000 ? dur / 60 : dur)); // normalized value is in seconds
        }
        genres.forEach((id, set) -> byId.get(id).setGenre(String.join(", ", set.stream().limit(3).toList())));
        return new ArrayList<>(byId.values());
    }
}
