'use strict';
/* ---------- helpers ---------- */
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money = n => '₹' + Number(n ?? 0).toFixed(2);
const fmt = d => d ? new Date(d).toLocaleString([], {dateStyle:'medium', timeStyle:'short'}) : '';
const badge = s => `<span class="badge ${esc(s)}">${esc(String(s).replace(/_/g,' '))}</span>`;
let me = null, timer = null;

async function api(path, o = {}) {
  const init = { method: o.method || 'GET', headers: {}, credentials: 'same-origin' };
  if (o.body !== undefined) { init.headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(o.body); }
  const r = await fetch('/api' + path, init);
  let data = null; try { data = await r.json(); } catch (e) {}
  if (!r.ok) { const e = new Error((data && data.message) || ('Request failed (' + r.status + ')')); e.status = r.status; throw e; }
  return data;
}
function toast(msg, type = 'ok') {
  const t = $('#toast'); t.textContent = msg; t.className = 'toast ' + type;
  clearTimeout(toast.h); toast.h = setTimeout(() => t.classList.add('hidden'), 4000);
}
const view = html => { clearInterval(timer); $('#app').innerHTML = html; };
const loading = () => view('<div class="loader">Loading…</div>');
async function run(fn) {
  try { await fn(); }
  catch (e) {
    if (e.status === 401) { me = null; renderNav(); location.hash = '#/login'; toast('Please log in', 'err'); }
    else toast(e.message, 'err');
  }
}
const val = id => { const el = document.getElementById(id); return el ? el.value.trim() : ''; };
const num = id => { const v = val(id); return v === '' ? null : Number(v); };

/* ---------- location picker (data comes from the API, nothing hardcoded) ---------- */
const pickerHtml = p => `<div class="row">
  <select id="${p}-state" hidden aria-hidden="true"><option value="">Tamil Nadu</option></select>
  <div><label>District</label><select id="${p}-district" disabled><option value="">Select district</option></select></div>
  <div><label>Area / Town</label><select id="${p}-city" disabled><option value="">Select area / town</option></select></div></div>`;
async function fill(sel, parentId, placeholder, districtName) {
  const list = await api('/public/locations' + (parentId ? '?parentId=' + parentId : ''));
  const dn = String(districtName || '').toLowerCase(); if (dn) list.sort((a, b) => (b.name.toLowerCase() === dn) - (a.name.toLowerCase() === dn) || a.name.localeCompare(b.name));
  sel.innerHTML = `<option value="">${placeholder}</option>` + list.map(l => `<option value="${l.id}">${esc(l.name)}${dn && l.name.toLowerCase() === dn ? ' (main town)' : ''}</option>`).join('');
  sel.disabled = false;
}
async function initPicker(p, onCity) {
  const st = $('#' + p + '-state'), di = $('#' + p + '-district'), ci = $('#' + p + '-city');
  await fill(st, null, 'Select');
  const tn = [...st.options].find(o => o.value && /tamil\s*nadu/i.test(o.text)); if (tn) st.value = tn.value;
  if (st.value) await fill(di, st.value, 'Select district');   // Tamil Nadu only: no state choice
  di.onchange = async () => { ci.innerHTML = ''; ci.disabled = true; if (di.value) await fill(ci, di.value, 'Select area / town', di.selectedOptions[0].text); onCity(null); };
  ci.onchange = () => onCity(ci.value || null);
}

/* ---------- navigation ---------- */
async function logout() { await run(async () => { await api('/auth/logout', { method: 'POST' }); me = null; renderNav(); location.hash = '#/home'; toast('Logged out'); }); }

const routes = [
  [/^#?\/?(home)?$/, pgHome], [/^#\/search$/, pgSearch], [/^#\/shortlist$/, pgShortlist], [/^#\/movies$/, pgMovies], [/^#\/login$/, pgLogin], [/^#\/register$/, pgRegister], [/^#\/register-theatre$/, pgRegTheatre],
  [/^#\/movie\/(\d+)$/, pgMovie], [/^#\/show\/(\d+)$/, pgSeats], [/^#\/profile$/, pgProfile], [/^#\/bookings$/, pgBookings], [/^#\/payments$/, pgPayments], [/^#\/notifications$/, pgNotifications],
  [/^#\/t\/dashboard$/, pgTDash], [/^#\/t\/screens$/, pgTScreens], [/^#\/t\/shows$/, pgTShows], [/^#\/t\/movies$/, pgTMovies], [/^#\/t\/bookings$/, pgTBookings], [/^#\/t\/customers$/, pgTCustomers],
  [/^#\/a\/dashboard$/, pgADash], [/^#\/a\/theatres$/, pgATheatres], [/^#\/a\/movies$/, pgAMovies], [/^#\/a\/locations$/, pgALocations], [/^#\/a\/users$/, pgAUsers], [/^#\/a\/reports$/, pgAReports], [/^#\/a\/payments$/, pgAPayments], [/^#\/a\/finance$/, () => pgFinance('a')], [/^#\/a\/finance\/m\/(\w+)$/, m => pgFinMetric('a', m)], [/^#\/a\/activity$/, pgAActivity], [/^#\/a\/bookings$/, pgABookings], [/^#\/offers$/, pgOffers], [/^#\/movie\/(\d+)\/shows$/, pgMovieShows], [/^#\/complaints$/, pgCComplaints], [/^#\/a\/offers$/, () => pgManageOffers('a')], [/^#\/t\/offers$/, () => pgManageOffers('t')], [/^#\/a\/reviews$/, pgAReviews], [/^#\/t\/reviews$/, pgTReviews], [/^#\/a\/complaints$/, pgAComplaints], [/^#\/t\/complaints$/, pgTComplaints], [/^#\/a\/refunds$/, pgARefunds], [/^#\/t\/finance$/, () => pgFinance('t')], [/^#\/t\/finance\/m\/(\w+)$/, m => pgFinMetric('t', m)]
];
function router() { const h=location.hash||'#/home'; for(const [re,fn] of routes){const m=h.match(re);if(m){renderNav();loading();run(()=>fn(m[1]));return;}} view('<div class="empty">Page not found</div>'); }
window.addEventListener('hashchange', router);
(async function init(){ const toggle=$('#sidebar-toggle'); if(toggle)toggle.onclick=()=>document.body.classList.toggle('sidebar-open'); try{me=await api('/auth/me')}catch(e){me=null} restoreUserLoc(); renderNav();router(); })();

/* ---------- auth pages ---------- */
function pgLogin() {
  view(`<div class="card" style="max-width:420px;margin:auto"><h2>Login</h2>
    <label>Email</label><input id="em" type="email" autocomplete="username">
    <label>Password</label><input id="pw" type="password" autocomplete="current-password">
    <button class="btn" id="go">Login</button></div>`);
  $('#go').onclick = () => run(async () => {
    me = await api('/auth/login', { method: 'POST', body: { email: val('em'), password: $('#pw').value } }); restoreUserLoc();
    renderNav(); toast('Welcome ' + me.name);
    location.hash = me.role === 'SUPER_ADMIN' ? '#/a/dashboard' : me.role === 'THEATRE_ADMIN' ? '#/t/dashboard' : '#/home';
  });
}
async function pgProfile() {
  me = await api('/auth/me');
  view(pageHead('My account', 'My profile', 'Your details are used for bookings and receipts.')
    + `<div class="card" style="max-width:560px"><label>Name</label><input id="pn" value="${esc(me.name)}" maxlength="100">
    <label>Email <span class="muted">(cannot be changed)</span></label><input value="${esc(me.email)}" disabled>
    <label>Phone</label><input id="pp" value="${esc(me.phone)}">
    <label>Address</label><textarea id="pa" rows="3" maxlength="300" placeholder="House / street, area, city, pincode">${esc(me.address || '')}</textarea>
    <div class="actions"><button class="btn" id="psave" type="button">Save changes</button></div></div>`);
  $('#psave').onclick = () => run(async () => {
    if (!val('pa')) throw new Error('Please enter your address');
    me = await api('/auth/me', { method: 'PUT', body: { name: val('pn'), phone: val('pp'), address: val('pa') } });
    renderNav(); toast('Profile updated');
  });
}
function pgRegister() {
  view(`<div class="card" style="max-width:480px;margin:auto"><h2>Create account</h2>
    <label>Name</label><input id="n"><label>Email</label><input id="e" type="email"><label>Phone</label><input id="p">
    <label>Address</label><textarea id="ad" rows="3" maxlength="300" placeholder="House / street, area, city, pincode"></textarea>
    <label>Password (8+ chars, letter and digit)</label><input id="pw" type="password" autocomplete="new-password">
    <button class="btn" id="go">Sign up</button></div>`);
  $('#go').onclick = () => run(async () => {
    await api('/auth/register', { method: 'POST', body: { name: val('n'), email: val('e'), phone: val('p'), address: val('ad'), password: $('#pw').value } });
    toast('Account created. Please log in.'); location.hash = '#/login';
  });
}
const detailsForm = (d = {}) => `
  <h3>Theatre details</h3>
  <div class="row"><div><label>Theatre name</label><input id="tn" value="${esc(d.name)}"></div>
  <div><label>Manager name</label><input id="tm"></div>
  <div><label>Contact phone</label><input id="tp" value="${esc(d.contactPhone)}"></div></div>
  <label>Address</label><input id="ta" value="${esc(d.address)}">
  ${pickerHtml('t')}
  <div class="row"><div><label>Licence number</label><input id="tl" value="${esc(d.licenseNumber)}"></div>
  <div><label>Licence expiry</label><input id="tx" type="date" value="${esc(d.licenseExpiry)}"></div></div>
  <h3>Bank (for settlements)</h3>
  <div class="row"><div><label>Account holder</label><input id="bh"></div><div><label>Account number</label><input id="ba"></div><div><label>IFSC</label><input id="bi" placeholder="HDFC0001234"></div></div>
  <label>Facilities (parking, wheelchair access, ...)</label><input id="tf" value="${esc(d.facilities)}">`;
const readDetails = cityId => ({ theatreName: val('tn'), managerName: val('tm'), contactPhone: val('tp'), address: val('ta'), cityId: Number(cityId),
  licenseNumber: val('tl'), licenseExpiry: val('tx'), bankAccountHolder: val('bh'), bankAccountNumber: val('ba'), bankIfsc: val('bi').toUpperCase(), facilities: val('tf') });
async function pgRegTheatre() {
  view(`<div class="card"><h2>Register your theatre</h2><p class="muted">Your theatre becomes bookable only after Super Admin verification.</p>
    <h3>Owner account</h3><div class="row"><div><label>Name</label><input id="on"></div><div><label>Email</label><input id="oe" type="email"></div>
    <div><label>Phone</label><input id="op"></div><div><label>Password</label><input id="opw" type="password" autocomplete="new-password"></div></div>
    ${detailsForm()}<button class="btn" id="go">Submit registration</button></div>`);
  let city = null; await initPicker('t', c => city = c);
  $('#go').onclick = () => run(async () => {
    if (!city) throw new Error('Please select district and city');
    await api('/auth/register-theatre', { method: 'POST', body: { owner: { name: val('on'), email: val('oe'), phone: val('op'), password: $('#opw').value }, theatre: readDetails(city) } });
    toast('Registration submitted. Log in to track its status.'); location.hash = '#/login';
  });
}

/* ---------- customer: browse ---------- */

/* ---------- customer: seats, hold, pay ---------- */
async function pgSeats(showId) {
  if (!me) { location.hash = '#/login'; toast('Log in to book seats', 'err'); return; }
  if (me.role !== 'CUSTOMER') { view('<div class="empty">Only customer accounts can book tickets.</div>'); return; }
  const map = await api('/public/shows/' + showId + '/seats');
  const sel = new Set(); const seatById = {}; map.seats.forEach(s => seatById[s.seatId] = s);
  const rows = {}; map.seats.forEach(s => (rows[s.rowLabel] = rows[s.rowLabel] || []).push(s));
  view(`${stepperHtml(1)}<div class="card"><h2>${esc(map.show.movieTitle)}</h2><p class="muted">${esc(map.show.theatreName)} · ${esc(map.show.screenName)} · ${fmt(map.show.startTime)}${map.show.audioLanguage ? ' · ' + esc(map.show.audioLanguage) : ''}${map.show.dimension ? ' ' + esc(map.show.dimension) : ''}${map.show.specialFormats ? ' · ' + esc(map.show.specialFormats) : ''}</p>
    <div class="legend"><span><i style="background:#cfe6d6;border:1px solid #7fb596"></i>Available</span><span><i style="background:#F3D9D7;border:1px solid #D99A9C"></i>Premium</span><span><i style="background:#9B6B66"></i>Selected</span><span><i style="background:#F3E7B9;border:1px solid #E0C46C"></i>Held</span><span><i style="background:#E9DDD2;border:1px solid #d4c2b4"></i>Booked</span><span><i class="blk"></i>Unavailable</span></div>
    <div class="bestbar"><b>✨ Best seats together</b> <select id="bn">${[1, 2, 3, 4, 5, 6, 7, 8].map(n => `<option value="${n}" ${n === 2 ? 'selected' : ''}>${n} seat${n > 1 ? 's' : ''}</option>`).join('')}</select> <button class="btn sec small" id="bbest" type="button">Pick for me</button> <small class="muted">Free cancellation as per theatre policy · final price, no hidden fees</small></div>
    <div class="screen-bar"></div><div class="muted" style="text-align:center">SCREEN</div>
    <div class="seatmap2">${seatGridHtml(map.seats, {})}</div>
    <div id="sum" class="muted">Select up to 8 seats.</div><div class="coupon-row"><input id="coupon" placeholder="Coupon code (optional)" maxlength="40"><button class="btn sec small" id="apply-coupon" type="button">Apply</button></div><div id="coupon-msg" class="muted"></div><button class="btn" id="hold" disabled>Hold seats &amp; continue</button></div><div id="pay"></div>`);
  const refresh = () => {
    document.querySelectorAll('.seat:not([disabled])').forEach(b => b.classList.toggle('sel', sel.has(Number(b.dataset.id))));
    const total = [...sel].reduce((x, i) => x + Number(seatById[i].price), 0);
    $('#sum').innerHTML = sel.size ? `<b>${[...sel].map(i => seatById[i].label).join(', ')}</b> · ${sel.size} seat${sel.size > 1 ? 's' : ''} · <b>Total ${money(total)}</b> <small>(final price)</small>` : 'Select up to 8 seats.';
    $('#hold').disabled = !sel.size;
  };
  document.querySelectorAll('.seat:not([disabled])').forEach(b => b.onclick = () => {
    const id = Number(b.dataset.id);
    if (sel.has(id)) sel.delete(id); else { if (sel.size >= 8) return toast('Maximum 8 seats', 'err'); sel.add(id); }
    refresh();
  });
  $('#bbest').onclick = () => {                      // best contiguous block: middle columns, about two-thirds back
    const n = Number($('#bn').value), free = map.seats.filter(x => x.state === 'AVAILABLE'), gridRows = [...new Set(map.seats.map(x => x.gridRow))].sort((p, q) => p - q);
    const maxCol = Math.max(...map.seats.map(x => x.gridCol)), target = (gridRows.length - 1) * 0.65; let best = null, bs = 1e9;
    gridRows.forEach((gr, ri) => { const rs = free.filter(x => x.gridRow === gr).sort((p, q) => p.gridCol - q.gridCol);
      for (let i = 0; i + n <= rs.length; i++) { const w = rs.slice(i, i + n); if (w[n - 1].gridCol - w[0].gridCol !== n - 1) continue;
        const sc = Math.abs(ri - target) * 3 + Math.abs((w[0].gridCol + w[n - 1].gridCol) / 2 - maxCol / 2); if (sc < bs) { bs = sc; best = w; } } });
    if (!best) return toast(`No ${n} seats together are free. Try fewer seats.`, 'err');
    sel.clear(); best.forEach(x => sel.add(x.seatId)); refresh();
  };
  $('#apply-coupon').onclick = async () => {
    const m = $('#coupon-msg'); if (!sel.size) { m.textContent = 'Select seats first.'; return; } if (!val('coupon').trim()) { m.textContent = 'Enter a coupon code.'; return; }
    try { const r = await api('/customer/offers/validate', { method: 'POST', body: { code: val('coupon').trim(), showId: Number(showId), seatIds: [...sel] } });
      m.innerHTML = `<span class="ok">✓ ${esc(r.code)} applied — you save ${money(r.discount)}. You pay <b>${money(r.payable)}</b>.</span>`; }
    catch (e) { m.innerHTML = `<span class="err">✕ ${esc(e.message)}</span>`; }
  };
  $('#hold').onclick = () => run(async () => {
    const b = await api('/customer/bookings/hold', { method: 'POST', body: { showId: Number(showId), seatIds: [...sel], couponCode: val('coupon').trim() || null } });
    $('#hold').disabled = true; document.querySelectorAll('.seat').forEach(x => x.disabled = true);
    showPayment(b);
  });
}
function showPayment(b) {
  const ref = encodeURIComponent(b.reference);
  $('#pay').innerHTML = `<div class="card paycard"><h3>Booking summary</h3><p><b>${esc(b.movieTitle)}</b> · ${esc(b.theatreName)} · ${esc(b.screenName)}<br>${fmt(b.showTime)}<br>Seats: ${esc(b.seats)}</p>
    <h2>Payable: ${money(b.totalAmount)}</h2><p class="muted">🎁 You will earn <b>${Math.floor(Number(b.totalAmount) / 10)}</b> reward points</p>
    <div class="payqr"><div class="qrbox"><img id="payqr" src="/api/customer/bookings/${ref}/pay-qr" width="190" height="190" alt="Scan to pay"><p class="muted small-note">Scan with your phone camera (same Wi-Fi), then tap <b>OK, Pay</b>. This page confirms by itself.</p></div>
    <div class="payside"><p class="warn">⚠️ TEST MODE: payments are simulated. No real money is charged.</p><p>Seats held for <b id="cd"></b></p>
    <label>Split between <input type="number" id="spn" value="1" min="1" max="8" style="width:70px"> → each pays <b id="spv">${money(b.totalAmount)}</b></label>
    <a class="btn sec small" id="spwa" target="_blank" rel="noopener">Share on WhatsApp</a>
    <label><input type="checkbox" id="fail" style="width:auto"> Simulate a failed payment (test mode)</label>
    <button class="btn" id="paybtn">Or pay here ${money(b.totalAmount)} (mock)</button></div></div></div>`;
  const split = () => { const n = Math.max(1, Math.min(8, Number($('#spn').value) || 1)), each = Math.ceil(Number(b.totalAmount) / n);
    $('#spv').textContent = money(each); $('#spwa').href = 'https://wa.me/?text=' + encodeURIComponent(`Join me for ${b.movieTitle} at ${b.theatreName}, ${fmt(b.showTime)}. Seats ${b.seats}. Your share: ₹${each}`); };
  $('#spn').oninput = split; split();
  const end = new Date(b.holdExpiresAt).getTime();
  clearInterval(timer); clearInterval(window.payPoll);
  timer = setInterval(() => { const s = Math.max(0, Math.floor((end - Date.now()) / 1000)); const el = $('#cd'); if (el) el.textContent = Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); if (!s) { clearInterval(timer); clearInterval(window.payPoll); toast('Hold expired', 'err'); } }, 500);
  window.payPoll = setInterval(async () => {             // the phone confirms the payment; we notice here
    if (!$('#payqr')) return clearInterval(window.payPoll);
    try { const r = await api('/customer/bookings/' + ref); if (r.status === 'CONFIRMED') { clearInterval(window.payPoll); clearInterval(timer); toast('Payment received on your phone. Booking confirmed!'); view(ticketHtml(r)); } else if (r.status !== 'PENDING_PAYMENT') clearInterval(window.payPoll); } catch (e) { }
  }, 2000);
  const key = crypto.randomUUID();
  $('#paybtn').onclick = () => run(async () => {
    $('#paybtn').disabled = true;
    const r = await api(`/customer/bookings/${b.reference}/pay`, { method: 'POST', body: { idempotencyKey: $('#fail').checked ? crypto.randomUUID() : key, simulateFailure: $('#fail').checked } });
    if (r.status === 'CONFIRMED') { clearInterval(window.payPoll); toast('Booking confirmed!'); view(ticketHtml(r)); }
    else if (r.status === 'EXPIRED') { toast(r.message, 'err'); location.hash = '#/home'; }
    else { toast(r.message || 'Payment failed', 'err'); $('#paybtn').disabled = false; }
  });
}
const ticketHtml = b => `<div class="ticket" id="print-ticket"><div class="ticket-head"><div><p class="eyebrow">CINEBOOK DIGITAL TICKET</p><h2>${esc(b.movieTitle)}</h2><p><b>${esc(b.theatreName)}</b> · ${esc(b.screenName)}<br>${fmt(b.showTime)}<br>Seats: <b>${esc(b.seats)}</b></p></div>
  ${b.status === 'CONFIRMED' ? `<img class="ticket-qr" src="/api/customer/bookings/${encodeURIComponent(b.reference)}/qr" alt="Unique booking verification QR code" width="150" height="150">` : ''}</div>
  <div class="ticket-meta"><span>Booking reference</span><b>${esc(b.reference)}</b><span>Total paid</span><b>${money(b.totalAmount)}</b><span>Booking status</span><b>${badge(b.status)}</b><span>Payment status</span><b>${badge(b.paymentStatus)}</b></div>
  ${b.refundAmount != null ? `<p>Refund: ${money(b.refundAmount)} (${esc(b.refundStatus)})</p>` : ''}<p class="muted">Keep this QR code ready at the theatre entrance. It can be checked in only once.</p></div>
  <p><button class="btn" onclick="window.print()">Print / Save ticket</button> <a class="btn sec" href="#/bookings">My bookings</a></p>`;
async function showExistingTicket(ref) { await run(async () => { const b = await api('/customer/bookings/' + encodeURIComponent(ref)); view(ticketHtml(b)); }); }
function cancelBooking(ref) {
  if (!confirm('Cancel this booking? Refund depends on how close the show is.')) return;
  run(async () => { const r = await api(`/customer/bookings/${ref}/cancel`, { method: 'POST' }); toast('Cancelled. Refund ' + money(r.refundAmount) + ' pending.'); pgBookings(); });
}

/* ---------- theatre admin ---------- */
async function pgTBookings() {
  const list = await api('/theatre/bookings');
  view(`  <div class="card"><div class="page-heading"><h2>Bookings</h2><div class="head-actions"><button class="btn sec small" id="tbx" type="button">Export CSV</button><button class="btn small" id="tar" type="button">Activity report</button></div></div><div class="row filter-grid"><div><label>Show time</label><select id="bk-time" class="nocombo"><option value="">Any time</option>${[...new Set(list.map(b => String(b.showTime).slice(11, 16)))].sort().map(t => `<option value="${t}">${new Date('2000-01-01T' + t).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}</option>`).join('')}</select></div><div><label>Search</label><input id="booking-search" placeholder="Reference, customer or movie"></div><div><label>Status</label><select id="booking-status"><option value="">All statuses</option><option>CONFIRMED</option><option>CANCELLED</option><option>PENDING_PAYMENT</option></select></div><div><label>Screen</label><select id="bk-screen"><option value="">All screens</option>${[...new Set(list.map(b => b.screenName))].sort().map(x => `<option>${esc(x)}</option>`).join('')}</select></div><div><label>Movie</label><select id="bk-movie"><option value="">All movies</option>${[...new Set(list.map(b => b.movieTitle))].sort().map(x => `<option>${esc(x)}</option>`).join('')}</select></div><div><label>Show date</label><select id="booking-period"><option value="">All time</option>${PERIODS.filter(p => p[0] !== 'custom').map(p => `<option value="${p[0]}">${p[1]}</option>`).join('')}</select></div><div><label>From</label><input type="date" id="bk-from"></div><div><label>To</label><input type="date" id="bk-to"></div></div>
  <p class="muted" id="bk-count"></p><div class="tablewrap"><table id="booking-table"><thead><tr><th>Ref</th><th>Customer</th><th>Movie</th><th>Show</th><th>Seats</th><th>Amount</th><th>Status</th></tr></thead><tbody>${list.map(b =>
    `<tr data-search="${esc((b.reference+' '+b.customerName+' '+b.movieTitle).toLowerCase())}" data-status="${esc(b.status)}" data-show="${esc(b.showTime)}" data-screen="${esc(b.screenName)}" data-movie="${esc(b.movieTitle)}"><td>${esc(b.reference)}</td><td>${esc(b.customerName)}</td><td>${esc(b.movieTitle)}</td><td>${fmt(b.showTime)}</td><td>${esc(b.seats)}</td><td>${money(b.totalAmount)}</td><td>${badge(b.status)}</td></tr>`).join('')}</tbody></table></div>${list.length ? '' : '<div class="empty">No bookings yet.</div>'}</div>`);
  const filter = () => { const q = val('booking-search').toLowerCase(), st = val('booking-status'); let f = val('bk-from'), to = val('bk-to');
    if (!f && !to && val('booking-period')) { const [a, b] = presetRange(val('booking-period')); f = isoD(a); to = isoD(b); }
    let n = 0; document.querySelectorAll('#booking-table tbody tr').forEach(r => { const d = (r.dataset.show || '').slice(0, 10);
      r.hidden = !(r.dataset.search.includes(q) && (!st || r.dataset.status === st) && (!val('bk-screen') || r.dataset.screen === val('bk-screen')) && (!val('bk-movie') || r.dataset.movie === val('bk-movie')) && (!val('bk-time') || (r.dataset.show || '').slice(11, 16) === val('bk-time')) && (!f || d >= f) && (!to || d <= to)); if (!r.hidden) n++; }); const c = $('#bk-count'); if (c) c.textContent = n + ' booking(s) shown'; };
  ['booking-search', 'bk-from', 'bk-to'].forEach(i => $('#' + i).oninput = filter); ['booking-status', 'booking-period', 'bk-screen', 'bk-movie', 'bk-time'].forEach(i => $('#' + i).onchange = filter); filter();
  $('#tar').onclick = () => run(() => activityExport('t'));
  $('#tbx').onclick = () => { const vis = new Set([...document.querySelectorAll('#booking-table tbody tr')].filter(r => !r.hidden).map(r => r.children[0].textContent)); csvDialog('cinebook-bookings.csv', [['Reference', b => b.reference], ['Customer', b => b.customerName], ['Movie', b => b.movieTitle], ['Screen', b => b.screenName], ['Show time', b => b.showTime], ['Seats', b => b.seats], ['Amount', b => b.totalAmount], ['Status', b => b.status], ['Payment', b => b.paymentStatus]], list.filter(b => vis.has(b.reference))); };
}

/* ---------- super admin ---------- */

function theatreAction(id, action) {
  const needs = ['REJECT', 'REQUEST_CHANGES', 'SUSPEND', 'DEACTIVATE'].includes(action);
  let reason = null;
  if (needs) { reason = prompt('Reason (required, shown to the theatre owner):\n e.g. Invalid licence, missing documents, incorrect owner details, duplicate registration, policy violation'); if (!reason || !reason.trim()) return; }
  else if (!confirm(action.replace('_', ' ') + ' this theatre?')) return;
  run(async () => { await api(`/admin/theatres/${id}/status`, { method: 'POST', body: { action, reason } }); toast('Done'); window.reloadTheatres(); });
}
function setCommission(id) {
  const p = prompt('Theatre-level commission % (0-100):'); if (p === null) return;
  run(async () => { await api(`/admin/theatres/${id}/commission`, { method: 'PUT', body: { percent: Number(p) } }); toast('Commission updated'); window.reloadTheatres(); });
}
function setScreenCommission(sid, tid) {
  const p = prompt('Screen commission % (0-100). Leave empty to inherit the theatre rate:'); if (p === null) return;
  run(async () => { await api(`/admin/screens/${sid}/commission`, { method: 'PUT', body: { percent: p.trim() === '' ? null : Number(p) } }); toast('Updated'); showDetail(tid); });
}
async function showDetail(id) {
  await run(async () => {
    const [sc, h] = await Promise.all([api(`/admin/theatres/${id}/screens`), api(`/admin/theatres/${id}/history`)]);
    $('#detail').innerHTML = `<div class="card"><h3>Screens &amp; effective commission</h3><div class="tablewrap"><table><tr><th>Screen</th><th>Seats</th><th>Own rate</th><th>Effective</th><th></th></tr>${sc.map(s =>
      `<tr><td>${esc(s.name)}</td><td>${s.totalSeats}</td><td>${s.screenCommission ?? '—'}</td><td><b>${s.effectiveCommission}%</b></td><td><button class="btn sec small" onclick="setScreenCommission(${s.id},${id})">Set rate</button></td></tr>`).join('')}</table></div>
      <h3>Approval history</h3><div class="tablewrap"><table>${h.map(x => `<tr><td>${fmt(x.at)}</td><td>${esc(x.from || '—')} → ${esc(x.to)}</td><td>${esc(x.reason || '')}</td><td>${esc(x.actor)}</td></tr>`).join('')}</table></div></div>`;
    $('#detail').scrollIntoView({ behavior: 'smooth' });
  });
}
function movieForm(m = {}) { return `${datalists()}<div class="movie-edit-form"><div class="row"><div><label>Title</label><input id="mt" value="${esc(m.title)}" required></div><div><label>Languages (comma-separated)</label><input id="ml" list="dl-lang" value="${esc(m.language)}" placeholder="Tamil, Telugu, Hindi" required></div><div><label>Genre</label><input id="mg" list="dl-genre" value="${esc(m.genre)}" required></div><div><label>Duration (min)</label><input id="md" type="number" min="1" max="600" value="${esc(m.durationMinutes)}" required></div><div><label>Certification</label><input id="mc" value="${esc(m.certification)}" placeholder="U/A"></div><div><label>Release date</label><input id="mr" type="date" value="${esc(m.releaseDate)}"></div><div><label>Status</label><select id="ms"><option ${m.status==='ACTIVE'?'selected':''}>ACTIVE</option><option ${m.status==='UPCOMING'?'selected':''}>UPCOMING</option><option ${m.status==='PENDING_REVIEW'?'selected':''}>PENDING_REVIEW</option><option ${m.status==='ARCHIVED'?'selected':''}>ARCHIVED</option></select></div></div><label>Poster URL</label><input id="mp" value="${esc(m.posterUrl)}" placeholder="https://…"><label>Or upload poster image</label><input id="poster-file" type="file" accept="image/png,image/jpeg,image/webp"><small class="muted">PNG, JPG or WebP, maximum 5 MB.</small><label>Trailer URL</label><input id="mv" value="${esc(m.trailerUrl)}" placeholder="https://…"><label>Cast</label><input id="mk" value="${esc(m.castInfo)}"><label>Description</label><textarea id="mds" rows="3">${esc(m.description)}</textarea><button class="btn" id="save-movie">${m.id ? 'Save changes' : 'Add movie'}</button> <button class="btn sec" id="cancel-edit" ${m.id?'':'hidden'}>Cancel edit</button></div>`; }
async function uploadSelectedPoster(){const f=$('#poster-file')?.files?.[0];if(!f)return val('mp');if(f.size>5*1024*1024)throw new Error('Poster must be 5 MB or smaller');const form=new FormData();form.append('file',f);const r=await fetch(me?.role==='THEATRE_ADMIN'?'/api/theatre/poster-upload':'/api/admin/poster-upload',{method:'POST',body:form,credentials:'same-origin'});let d={};try{d=await r.json()}catch(e){}if(!r.ok)throw new Error(d.message||'Poster upload failed');return d.url;}
function readMovieForm() { return {title:val('mt'),language:normCsv(val('ml')),genre:normCsv(val('mg')),durationMinutes:num('md'),certification:val('mc'),releaseDate:val('mr')||null,status:val('ms'),posterUrl:val('mp'),trailerUrl:val('mv'),castInfo:val('mk'),description:val('mds')}; }
function wireMovieForm(id, refresh) { $('#save-movie').onclick=()=>run(async()=>{const data=readMovieForm(); data.posterUrl=await uploadSelectedPoster(); await api(id?'/admin/movies/'+id:'/admin/movies',{method:id?'PUT':'POST',body:data});toast(id?'Movie changes saved':'Movie added to shared catalogue');$('#movie-form').innerHTML=movieForm();wireMovieForm(null,refresh);await refresh();}); const cancel=$('#cancel-edit'); if(cancel)cancel.onclick=()=>{ $('#movie-form').innerHTML=movieForm();wireMovieForm(null,refresh);}; }

async function pgALocations() {
  view(`<div class="card"><h2>Add location</h2><p class="muted">Add districts, then cities under them (Tamil Nadu).</p>${pickerHtml('l')}
    <div class="row"><div><label>New name</label><input id="ln"></div><div><label>Type</label><select id="lt"><option>DISTRICT</option><option>CITY</option></select></div></div>
    <button class="btn" id="add">Add</button></div>`);
  let parent = { state: null, district: null };
  const st = $('#l-state'), di = $('#l-district'), ci = $('#l-city');
  await initPicker('l', () => {});
  $('#add').onclick = () => run(async () => {
    const type = val('lt'); const parentId = type === 'STATE' ? null : type === 'DISTRICT' ? (st.value || null) : (di.value || null);
    await api('/admin/locations', { method: 'POST', body: { name: val('ln'), type, parentId: parentId ? Number(parentId) : null } });
    toast('Location added'); pgALocations();
  });
}
async function pgAMovies() {
  const all = await api('/admin/movies/in-booking');
  const langs = [...new Set(all.map(m => m.language).filter(Boolean))].sort();
  view(pageHead('MANAGE', 'Movies in booking', 'Movies customers can book right now. Removing one stops it everywhere.')
    + `<div class="card"><div class="filter-grid"><div><label>Search</label><input id="mq" placeholder="Title…"></div><div><label>Language</label><select id="ml"><option value="">All languages</option>${langs.map(l => `<option>${esc(l)}</option>`).join('')}</select></div></div></div><div id="mlist"></div>`);
  const draw = () => {
    const q = val('mq').toLowerCase(), lg = val('ml');
    const list = all.filter(m => (!q || m.title.toLowerCase().includes(q)) && (!lg || m.language === lg));
    $('#mlist').innerHTML = list.length ? list.map(m => `<div class="mrow"><div class="mrow-info"><b>${esc(m.title)}</b> <span class="badge">${esc(m.language)}</span>
      <div class="muted">${esc(m.genre || '')}${m.runFrom ? ` · Run ${m.runFrom} → ${m.runTo}` : ''}</div>
      <div class="muted">${m.theatres} theatre(s) · ${m.upcomingShows} upcoming show(s) · ${m.bookings} booking(s)</div></div>
      <div class="actions"><button class="btn danger small" data-rm="${m.id}" type="button">Remove</button></div></div>`).join('') : emptyBox('No movies are in booking right now.');
    document.querySelectorAll('#mlist [data-rm]').forEach(b => b.onclick = () => {
      const m = all.find(x => x.id === Number(b.dataset.rm));
      const dlg = modal(`<h3>Remove “${esc(m.title)}”</h3><p class="muted">This will: archive the movie so customers can’t see or book it, end the run at <b>${m.theatres}</b> theatre(s), and cancel <b>${m.upcomingShows}</b> upcoming show(s) with refunds for <b>${m.bookings}</b> booking(s). Theatres are notified and can add a replacement movie.</p><label>Remarks (required, min 5 characters)</label><input id="rr" maxlength="250"><div class="actions"><button class="btn danger" id="rgo" type="button">Remove movie</button><button class="btn sec" id="rno" type="button">Keep</button></div>`);
      dlg.querySelector('#rno').onclick = () => dlg.remove();
      dlg.querySelector('#rgo').onclick = () => run(async () => {
        const r = await api(`/admin/movies/${m.id}/remove`, { method: 'POST', body: { remarks: dlg.querySelector('#rr').value } });
        dlg.remove(); toast(`Removed. ${r.cancelledShows} show(s) cancelled, ${r.theatresNotified} theatre(s) notified.`); pgAMovies();
      });
    });
  };
  $('#mq').oninput = draw; $('#ml').onchange = draw; draw();
}
function toggleUser(id, active) { if (!confirm((active ? 'Activate' : 'Deactivate') + ' this account?')) return; run(async () => { await api(`/admin/users/${id}/active`, { method: 'POST', body: { active } }); pgAUsers(); }); }

/* =====================================================================
   Organized UI: navigation groups, notifications, dashboards, pages
   ===================================================================== */
const debounce = (fn, ms) => { let h; return (...a) => { clearTimeout(h); h = setTimeout(() => fn(...a), ms); }; };
const store = { get(k, d) { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch (e) { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} } };
function rememberQ(q) { q = (q || '').trim(); if (q.length < 2) return; store.set('recentQ', [q, ...store.get('recentQ', []).filter(x => x !== q)].slice(0, 6)); }
function drawRecent(go) {
  const box = $('#recent'); if (!box) return; const r = store.get('recentQ', []);
  box.innerHTML = r.length ? '<span class="muted">Recent:</span>' + r.map(x => `<button type="button" class="chip">${esc(x)}</button>`).join('') + '<button type="button" class="chip ghost" id="clr-recent">Clear</button>' : '';
  box.querySelectorAll('.chip:not(.ghost)').forEach(b => b.onclick = () => { $('#q').value = b.textContent; go(); });
  const c = $('#clr-recent'); if (c) c.onclick = () => { store.set('recentQ', []); drawRecent(go); };
}

const stat2 = (icon, label, value, sub = '', tone = '') => `<div class="stat2 ${tone}"><span class="stat2-ic">${icon}</span><div><span class="muted">${label}</span><b>${value}</b>${sub ? `<small>${sub}</small>` : ''}</div></div>`;
const tabsHtml = (id, list, active) => `<div class="tabs" id="${id}">${list.map(([k, l, c]) => `<button type="button" class="tab ${k === active ? 'on' : ''}" data-k="${k}">${l}${c != null ? `<i>${c}</i>` : ''}</button>`).join('')}</div>`;
function wireTabs(id, fn) { document.querySelectorAll('#' + id + ' .tab').forEach(b => b.onclick = () => { document.querySelectorAll('#' + id + ' .tab').forEach(x => x.classList.toggle('on', x === b)); fn(b.dataset.k); }); }
const pageHead = (eyebrow, title, sub, actions = '') => `<div class="page-heading"><div><p class="eyebrow">${eyebrow}</p><h2>${title}</h2>${sub ? `<p class="muted">${sub}</p>` : ''}</div><div class="head-actions">${actions}</div></div>`;
const dayGroup = d => { const t = new Date(d), n = new Date(), y = new Date(); y.setDate(n.getDate() - 1); const s = x => x.toDateString(); return s(t) === s(n) ? 'Today' : s(t) === s(y) ? 'Yesterday' : (n - t) < 7 * 864e5 ? 'This week' : 'Earlier'; };
const last7 = (rows, dateOf, valOf) => { const days = []; for (let i = 6; i >= 0; i--) { const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - i); days.push({ d, label: d.toLocaleDateString([], { weekday: 'short' }), v: 0 }); } rows.forEach(r => { const t = new Date(dateOf(r)); t.setHours(0, 0, 0, 0); const x = days.find(k => k.d.getTime() === t.getTime()); if (x) x.v += valOf(r); }); return days; };
const barChart = (days, f) => { const max = Math.max(...days.map(d => d.v), 1); return `<div class="bars">${days.map(d => `<div class="bar-col" title="${d.label}: ${f(d.v)}"><span class="bar-val">${d.v ? f(d.v) : ''}</span><div class="bar" style="height:${Math.max(3, d.v / max * 100)}%"></div><span class="bar-lab">${d.label}</span></div>`).join('')}</div>`; };
const emptyBox = (t) => `<div class="empty">${t}</div>`;
const csvOf = rows => rows.map(r => r.map(v => '"' + String(v ?? '').replace(/"/g, '""') + '"').join(',')).join('\r\n');
const downloadCsv = (name, rows) => { const u = URL.createObjectURL(new Blob([csvOf(rows)], { type: 'text/csv;charset=utf-8;' })); const a = document.createElement('a'); a.href = u; a.download = name; a.click(); URL.revokeObjectURL(u); };

/* ---------- navigation (grouped by purpose) ---------- */
function navGroups() {
  const g = [['Browse', [['home', '⌂', 'Home'], ['search', '⌕', 'Search'], ['shortlist', '♥', 'Shortlist'], ['offers', '％', 'Offers']]]];
  if (me?.role === 'CUSTOMER') g.push(['My account', [['profile', '☺', 'My profile'], ['bookings', '▤', 'My bookings'], ['payments', '₹', 'Payments'], ['complaints', '⚑', 'Help & complaints']]]);
  if (me?.role === 'THEATRE_ADMIN') g.push(['Overview', [['t/dashboard', '▦', 'Dashboard']]], ['Operations', [['t/screens', '▥', 'Screens'], ['t/shows', '◷', 'Shows'], ['t/movies', '▣', 'Movies'], ['t/bookings', '✓', 'Bookings'], ['t/customers', '♙', 'Customers'], ['t/finance', '₹', 'Finance & analytics']]], ['Engage', [['t/offers', '％', 'Offers'], ['t/reviews', '★', 'Reviews'], ['t/complaints', '⚑', 'Complaints']]]);
  if (me?.role === 'SUPER_ADMIN') g.push(['Overview', [['a/dashboard', '▦', 'Dashboard']]], ['Manage', [['a/bookings', '▤', 'Bookings'], ['a/theatres', '▥', 'Theatres'], ['a/movies', '▣', 'Movies'], ['a/users', '♙', 'Users'], ['a/locations', '⌖', 'Locations']]], ['Engage', [['a/offers', '％', 'Offers'], ['a/reviews', '★', 'Reviews & ratings'], ['a/complaints', '⚑', 'Complaints']]], ['Finance & reports', [['a/finance', '₹', 'Finance'], ['a/refunds', '↺', 'Refunds'], ['a/reports', '◔', 'Reports'], ['a/activity', '⌚', 'Activity & audit']]]);
  g.push(me ? ['Inbox', [['notifications', '♧', 'Notifications']]] : ['Account', [['login', '⇥', 'Login'], ['register', '＋', 'Sign up'], ['register-theatre', '▣', 'Register theatre']]]);
  return g;
}
function renderNav() {
  document.body.dataset.role = me ? me.role : 'GUEST';
  $('#nav').innerHTML = navGroups().map(([h, items]) => `<div class="nav-group nav-label">${h}</div>` + items.map(([route, icon, label]) => `<a href="#/${route}" title="${label}" class="nav-item" data-g="${esc(h)}"><span class="nav-icon">${icon}</span><span class="nav-label">${label}</span></a>`).join('')).join('')
    + (me ? `<div class="nav-account"><span class="nav-icon">●</span><span class="nav-label">${esc(me.name)}<small class="role-tag">${esc(String(me.role).replace('_', ' ').toLowerCase())}</small></span><button onclick="logout()" class="nav-logout nav-label">Logout</button></div>` : '');
  document.querySelectorAll('#nav a').forEach(a => a.classList.toggle('active', (location.hash || '#/home') === a.getAttribute('href')));
  if (me) api('/notifications/unread-count').then(n => { const a = [...document.querySelectorAll('#nav a')].find(x => x.href.includes('/notifications')); if (a) { if (n > 0) a.dataset.count = n; else delete a.dataset.count; } }).catch(() => {});
}

/* ---------- notifications: one inbox, grouped by day, filtered by type ---------- */
const NCAT = { BOOKING: ['▤', 'Bookings'], PAYMENT: ['₹', 'Payments'], THEATRE: ['▥', 'Theatres'], MOVIE: ['▣', 'Movies'], SYSTEM: ['✦', 'System'], REVIEW: ['★', 'Reviews'], OFFER: ['％', 'Offers'], COMPLAINT: ['⚑', 'Complaints'], CANCELLATION: ['✕', 'Cancellations'], REFUND: ['↺', 'Refunds'] };
const NLINK = { CUSTOMER: { BOOKING: '#/bookings', CANCELLATION: '#/bookings', REFUND: '#/bookings', PAYMENT: '#/bookings', OFFER: '#/offers', COMPLAINT: '#/complaints' }, THEATRE_ADMIN: { CANCELLATION: '#/t/bookings', REFUND: '#/t/bookings', REVIEW: '#/t/reviews', COMPLAINT: '#/t/complaints', OFFER: '#/t/offers', BOOKING: '#/t/bookings', THEATRE: '#/t/dashboard', MOVIE: '#/t/movies' }, SUPER_ADMIN: { CANCELLATION: '#/a/bookings', REFUND: '#/a/refunds', REVIEW: '#/a/reviews', COMPLAINT: '#/a/complaints', THEATRE: '#/a/theatres', MOVIE: '#/a/movies', PAYMENT: '#/a/finance', BOOKING: '#/a/bookings' } };
async function pgNotifications() {
  let list = await api('/notifications'), tab = 'ALL';
  const draw = () => {
    const cats = Object.keys(NCAT).filter(c => list.some(n => n.category === c));
    const unread = list.filter(n => !n.seen).length;
    const shown = list.filter(n => tab === 'ALL' || (tab === 'UNREAD' ? !n.seen : n.category === tab));
    const groups = ['Today', 'Yesterday', 'This week', 'Earlier'].map(g => [g, shown.filter(n => dayGroup(n.createdAt) === g)]).filter(([, x]) => x.length);
    view(pageHead('INBOX', 'Notifications', unread ? `${unread} unread` : 'You are all caught up', `<button class="btn sec small" id="n-all" ${unread ? '' : 'disabled'}>Mark all read</button><button class="btn sec small" id="n-clear">Clear read</button>`)
      + tabsHtml('ntabs', [['ALL', 'All', list.length], ['UNREAD', 'Unread', unread], ...cats.map(c => [c, NCAT[c][1], list.filter(n => n.category === c).length])], tab)
      + (groups.length ? groups.map(([g, items]) => `<div class="day-group"><h3>${g}</h3>${items.map(n => {
        const link = (NLINK[me.role] || {})[n.category];
        return `<div class="notif ${n.seen ? '' : 'new'}" data-id="${n.id}"><span class="notif-ic ${n.category}">${NCAT[n.category][0]}</span><div class="notif-body"><p>${esc(n.message)}</p><small>${NCAT[n.category][1]} · ${fmt(n.createdAt)}</small></div><div class="notif-actions">${link ? `<a class="text-link" href="${link}">Open</a>` : ''}${n.seen ? '' : '<button class="icon-btn" data-act="read" title="Mark read">✓</button>'}<button class="icon-btn" data-act="del" title="Delete">✕</button></div></div>`;
      }).join('')}</div>`).join('') : emptyBox('No notifications here.')));
    wireTabs('ntabs', k => { tab = k; draw(); });
    const refresh = async () => { list = await api('/notifications'); renderNav(); draw(); };
    $('#n-all').onclick = () => run(async () => { await api('/notifications/read', { method: 'POST' }); await refresh(); });
    $('#n-clear').onclick = () => run(async () => { await api('/notifications/read', { method: 'DELETE' }); await refresh(); });
    document.querySelectorAll('.notif [data-act]').forEach(b => b.onclick = () => run(async () => {
      const id = b.closest('.notif').dataset.id;
      if (b.dataset.act === 'read') await api(`/notifications/${id}/read`, { method: 'POST' }); else await api(`/notifications/${id}`, { method: 'DELETE' });
      await refresh();
    }));
  };
  draw();
}

/* ---------- Super Admin: dashboard ---------- */
async function pgADash() {
  const [d, pay] = await Promise.all([api('/admin/dashboard'), api('/admin/payments')]);
  const rev = last7(pay.filter(p => p.status === 'SUCCESS'), p => p.createdAt, p => Number(p.amount));
  const todo = d.theatresPending + d.failedPayments;
  const act = (n, label, href, hint, tone) => `<a class="action-card ${n ? 'hot ' + tone : ''}" href="${href}"><b>${n}</b><span>${label}</span><small>${n ? hint : 'All clear'}</small></a>`;
  view(pageHead('SUPER ADMIN · ' + new Date().toLocaleDateString([], { weekday: 'long', day: 'numeric', month: 'long' }), 'Dashboard', todo ? todo + ' item(s) need you today' : 'Everything is up to date')
    + `<div class="stats2">${stat2('₹', 'Commission income', money(d.commissionIncome), 'platform earnings', 'rev')}${stat2('▤', 'Gross ticket sales', money(d.grossTicketSales), '', 'ok')}${stat2('✓', 'Payments collected', money(d.collectedPayments), '', 'ok')}${stat2('↺', 'Refunds', money(d.refundsIssued), 'issued / pending', 'warn')}</div>`
    + `<h3 class="sec-title">Needs your attention</h3><div class="action-row">${act(d.theatresPending, 'Theatres to verify', '#/a/theatres', 'Review & approve →', 'pending')}${act(d.failedPayments, 'Failed payments', '#/a/payments', 'Check ledger →', 'err')}</div>`
    + `<div class="split"><div class="card"><h3>Revenue — last 7 days</h3><p class="muted">Successful payments collected</p>${barChart(rev, v => '₹' + Math.round(v))}</div>
      <div class="card"><h3>Platform</h3><div class="kv-list"><span>Theatres</span><b>${d.theatresTotal} <small class="muted">${d.theatresApproved} approved</small></b><span>Customers</span><b>${d.customers}</b><span>Suspended / deactivated</span><b class="gold">${d.theatresSuspended + d.theatresDeactivated}</b><span>Theatre payables</span><b>${money(d.theatrePayables)}</b></div></div></div>`
    + `<div class="card"><h3>Recent admin activity</h3>${d.recentActivity.length ? '<ul class="timeline">' + d.recentActivity.map(a => `<li>${esc(a)}</li>`).join('') + '</ul>' : emptyBox('No activity yet.')}</div>`);
}

/* ---------- Super Admin: theatres (tabs by what needs doing) ---------- */
const THEATRE_TABS = [['todo', 'Needs action', ['PENDING_VERIFICATION', 'UNDER_REVIEW']], ['approved', 'Approved', ['APPROVED']], ['owner', 'Waiting on owner', ['CHANGES_REQUIRED']], ['closed', 'Rejected / suspended', ['REJECTED', 'SUSPENDED', 'DEACTIVATED']], ['all', 'All', null]];
async function pgATheatres() {
  let all = await api('/admin/theatres?' + new URLSearchParams({ q: '', status: '' })), tab = 'todo', q = '', ST = '', CT = '';
  if (!all.some(t => ['PENDING_VERIFICATION', 'UNDER_REVIEW'].includes(t.status))) tab = 'approved';
  const inTab = (t, k) => { const d = THEATRE_TABS.find(x => x[0] === k)[2]; return !d || d.includes(t.status); };
  view(pageHead('MANAGE', 'Theatres', 'Verify new theatres, set commission, suspend when needed.') + `<div id="tt"></div><div class="card"><div class="filter-grid"><div><label>Search</label><input id="tq" placeholder="Name, address, city or owner…"></div><div><label>City</label><select id="tct"><option value="">All cities</option>${[...new Set(all.map(t => t.city).filter(Boolean))].sort().map(x => `<option>${esc(x)}</option>`).join('')}</select></div><div><button class="btn sec" id="tx" type="button">Export CSV</button></div></div></div><div id="tl"></div><div id="detail"></div>`);
  const draw = () => {
    $('#tt').innerHTML = tabsHtml('ttabs', THEATRE_TABS.map(([k, l]) => [k, l, all.filter(t => inTab(t, k)).length]), tab);
    wireTabs('ttabs', k => { tab = k; draw(); });
    const list = all.filter(t => inTab(t, tab) && (!ST || t.state === ST) && (!CT || t.city === CT) && [t.name, t.address, t.city, t.state, t.ownerName, t.ownerEmail].some(x => String(x || '').toLowerCase().includes(q))); CUR_T = list;
    $('#tl').innerHTML = list.length ? `<div class="tcards">${list.map(t => `<div class="tcard"><div class="tcard-h"><div><b>${esc(t.name)}</b><div class="muted">${esc(t.city)}</div></div>${badge(t.status)}</div>
      <div class="kv-list"><span>Owner</span><b>${esc(t.ownerName)}</b><span>Email</span><b>${esc(t.ownerEmail)}</b><span>Licence</span><b>${esc(t.licenseNumber)} <small class="muted">exp ${esc(t.licenseExpiry)}</small></b><span>Screens / seats</span><b>${t.screenCount} / ${t.totalSeats}</b><span>Commission</span><b>${t.effectiveCommission}%${t.theatreCommission == null ? ' <small class="muted">default</small>' : ''}</b></div>
      ${t.statusReason ? `<p class="warn small-note">${esc(t.statusReason)}</p>` : ''}
      <div class="actions">${t.allowedActions.map(a => `<button class="btn small ${['REJECT', 'SUSPEND', 'DEACTIVATE'].includes(a) ? 'danger' : ''}" onclick="theatreAction(${t.id},'${a}')">${a.replace('_', ' ')}</button>`).join('')}<button class="btn sec small" onclick="setCommission(${t.id})">Set rate</button><button class="btn sec small" onclick="showDetail(${t.id})">Screens &amp; history</button><button class="btn small" onclick="openTheatreEntity(${t.id})">Details &amp; export</button></div></div>`).join('')}</div>` : emptyBox('No theatres in this tab.');
  };
  draw(); $('#tq').oninput = e => { q = e.target.value.toLowerCase(); draw(); };
  $('#tct').onchange = e => { CT = e.target.value; draw(); };
  $('#tx').onclick = () => csvDialog('cinebook-theatres.csv', [['Theatre', t => t.name], ['Address', t => t.address], ['City', t => t.city], ['Owner', t => t.ownerName], ['Owner email', t => t.ownerEmail], ['Licence', t => t.licenseNumber], ['Licence expiry', t => t.licenseExpiry], ['Screens', t => t.screenCount], ['Seats', t => t.totalSeats], ['Commission %', t => t.effectiveCommission], ['Status', t => t.status]], CUR_T);
  window.reloadTheatres = async () => { all = await api('/admin/theatres?' + new URLSearchParams({ q: '', status: '' })); draw(); };
}

/* ---------- Super Admin: movies (review queue + auto import) ---------- */
const MOVIE_TABS = [['PENDING_REVIEW', 'Review queue'], ['ACTIVE', 'Now showing'], ['UPCOMING', 'Coming soon'], ['ARCHIVED', 'Archived'], ['ALL', 'All']];
/* ---------- Super Admin: payments ---------- */
async function pgAPayments() {
  const rows = await api('/admin/payments');
  view(pageHead('FINANCE', 'Payments', 'Every payment attempt. Test mode — not a real bank statement.', '<button class="btn sec small" id="pexp">Export CSV</button>')
    + `<div id="pk"></div><div class="card"><div class="filter-grid"><div><label>Search</label><input id="pq" placeholder="Booking ref or transaction"></div><div><label>Status</label><select id="ps"><option value="">All</option>${['SUCCESS', 'FAILED', 'PENDING', 'REFUND_PENDING', 'REFUNDED'].map(x => `<option>${x}</option>`).join('')}</select></div><div><label>From</label><input type="date" id="pf"></div><div><label>To</label><input type="date" id="pt"></div></div></div><div id="pl"></div>`);
  let cur = rows;
  const draw = () => {
    const q = val('pq').toLowerCase(), s = val('ps'), f = val('pf'), t = val('pt');
    cur = rows.filter(p => (!s || p.status === s) && (!q || (p.bookingReference + ' ' + p.transactionRef).toLowerCase().includes(q)) && (!f || p.createdAt.slice(0, 10) >= f) && (!t || p.createdAt.slice(0, 10) <= t));
    const sum = st => cur.filter(p => st.includes(p.status)).reduce((a, p) => a + Number(p.amount), 0);
    $('#pk').innerHTML = `<div class="stats2">${stat2('₹', 'Collected', money(sum(['SUCCESS'])), cur.filter(p => p.status === 'SUCCESS').length + ' payments')}${stat2('!', 'Failed', cur.filter(p => p.status === 'FAILED').length, money(sum(['FAILED'])), 'warn')}${stat2('↺', 'Refunds', money(sum(['REFUND_PENDING', 'REFUNDED'])))}${stat2('≡', 'Showing', cur.length, 'of ' + rows.length)}</div>`;
    $('#pl').innerHTML = cur.length ? `<div class="card tablewrap"><table><tr><th>Created</th><th>Booking</th><th>Amount</th><th>Status</th><th>Mode</th><th>Transaction</th><th>Message</th></tr>${cur.map(p => `<tr><td>${fmt(p.createdAt)}</td><td>${esc(p.bookingReference)}</td><td>${money(p.amount)}</td><td>${badge(p.status)}</td><td>${esc(p.mode)}</td><td>${esc(p.transactionRef)}</td><td>${esc(p.message || '')}</td></tr>`).join('')}</table></div>` : emptyBox('No payments match.');
  };
  ['pq'].forEach(i => $('#' + i).oninput = draw); ['ps', 'pf', 'pt'].forEach(i => $('#' + i).onchange = draw);
  $('#pexp').onclick = () => csvDialog('cinebook-payments.csv', [['Created', p => p.createdAt], ['Booking', p => p.bookingReference], ['Amount', p => p.amount], ['Status', p => p.status], ['Mode', p => p.mode], ['Transaction', p => p.transactionRef], ['Message', p => p.message]], cur);
  draw();
}

/* ---------- Super Admin: reports & audit ---------- */

/* ---------- Theatre Admin: dashboard ---------- */
/* ---------- Theatre Admin dashboard: only what matters today ---------- */
const occBar = (booked, total) => { const p = total ? Math.round(booked / total * 100) : 0; return `<div class="occ" title="${booked} of ${total} seats booked"><div class="occ-bar"><i style="width:${p}%"></i></div><span>${p}% <small class="muted">(${booked}/${total})</small></span></div>`; };
async function pgTDash() {
  const [t, hist, bookings, shows, cmp] = await Promise.all([api('/theatre/me'), api('/theatre/history'), api('/theatre/bookings'), api('/theatre/shows'), api('/theatre/complaints').catch(() => ({ inbox: [] }))]);
  const fix = t.status === 'CHANGES_REQUIRED', now = new Date(), todayS = isoD(now);
  const isToday = x => String(x).slice(0, 10) === todayS, hhmm = x => new Date(x).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const live = shows.filter(s => s.status === 'SCHEDULED').sort((a, b) => new Date(a.startTime) - new Date(b.startTime));
  const todays = live.filter(s => isToday(s.startTime));
  const upcoming = live.filter(s => new Date(s.startTime) > now).slice(0, 6);
  const tb = bookings.filter(b => b.status === 'CONFIRMED' && isToday(b.showTime));
  const revenue = tb.reduce((a, b) => a + Number(b.totalAmount || 0), 0);
  const seatsSold = tb.reduce((a, b) => a + String(b.seats || '').split(',').filter(x => x.trim()).length, 0);
  const total = todays.reduce((a, s) => a + (s.totalSeats || 0), 0), booked = todays.reduce((a, s) => a + (s.bookedSeats || 0), 0);
  const pct = total ? Math.round(booked / total * 100) : 0, left = todays.filter(s => new Date(s.startTime) > now).length;
  const refundsDue = bookings.filter(b => b.status === 'CANCELLED' && b.refundStatus === 'PENDING'), refundAmt = refundsDue.reduce((a, b) => a + Number(b.refundAmount || 0), 0);
  const openCmp = (cmp.inbox || []).filter(c => c.status === 'OPEN' || c.status === 'IN_PROGRESS');
  const alert = (n, label, sub, href) => `<a class="alert-row ${n ? 'hot' : ''}" href="${href}"><b>${n}</b><span>${label}<small class="muted">${n ? sub : 'All clear'}</small></span><i>→</i></a>`;
  view(`<div class="card hero-card"><div class="tcard-h"><div><p class="eyebrow">THEATRE ADMIN · ${new Date().toLocaleDateString([], { weekday: 'long', day: 'numeric', month: 'long' })}</p><h2>${esc(t.name)}</h2></div>${badge(t.status)}</div>
    ${t.statusReason ? `<p class="warn"><b>Admin note:</b> ${esc(t.statusReason)}</p>` : ''}${t.status !== 'APPROVED' ? '<p class="warn">Your theatre is not bookable until it is Approved.</p>' : ''}</div>
    ${fix ? `<div class="card"><h3>Correct &amp; resubmit</h3>${detailsForm(t)}<button class="btn" id="rs">Resubmit for review</button></div>` : ''}
    <div class="stats2">${stat2('◷', "Today's shows", todays.length, left + ' still to start')}${stat2('✓', "Today's bookings", tb.length, seatsSold + ' seat(s)')}${stat2('₹', "Today's revenue", money(revenue), 'confirmed, for today’s shows')}${stat2('▥', 'Seat occupancy', pct + '%', total ? booked + ' of ' + total + ' seats' : 'No shows today')}</div>
    <div class="split"><div class="card"><div class="page-heading"><h3>Today’s shows</h3><a class="btn sec small" href="#/t/shows">Manage shows</a></div>${todays.length ? `<div class="tablewrap"><table><tr><th>Time</th><th>Movie</th><th>Screen</th><th>Occupancy</th></tr>${todays.map(s => `<tr class="${new Date(s.startTime) <= now ? 'past' : ''}"><td><b>${hhmm(s.startTime)}</b></td><td>${esc(s.movieTitle)}</td><td>${esc(s.screenName)}</td><td>${occBar(s.bookedSeats || 0, s.totalSeats || 0)}</td></tr>`).join('')}</table></div>` : emptyBox('No shows scheduled today.')}</div>
    <div class="card"><h3>Alerts</h3><div class="alert-list">${alert(refundsDue.length, 'Refunds pending', money(refundAmt) + ' to be returned to customers', '#/t/bookings')}${alert(openCmp.length, 'Open complaints', 'Customers are waiting for a reply', '#/t/complaints')}</div></div></div>
    <div class="card"><div class="page-heading"><h3>Upcoming shows</h3><a class="btn sec small" href="#/t/shows">Schedule</a></div>${upcoming.length ? `<div class="tablewrap"><table><tr><th>When</th><th>Movie</th><th>Screen</th><th>Occupancy</th></tr>${upcoming.map(s => `<tr><td><b>${isToday(s.startTime) ? 'Today' : new Date(s.startTime).toLocaleDateString([], { weekday: 'short', day: 'numeric', month: 'short' })}</b> ${hhmm(s.startTime)}</td><td>${esc(s.movieTitle)}</td><td>${esc(s.screenName)}</td><td>${occBar(s.bookedSeats || 0, s.totalSeats || 0)}</td></tr>`).join('')}</table></div>` : emptyBox('No upcoming shows. Schedule one from Shows.')}</div>
    <details class="card"><summary>Approval history (${hist.length})</summary><div class="tablewrap"><table><tr><th>When</th><th>Change</th><th>Reason</th><th>By</th></tr>${hist.map(h => `<tr><td>${fmt(h.at)}</td><td>${esc(h.from || '—')} → ${esc(h.to)}</td><td>${esc(h.reason || '')}</td><td>${esc(h.actor)}</td></tr>`).join('')}</table></div></details>`);
  if (fix) { let city = null; await initPicker('t', c => city = c);
    $('#rs').onclick = () => run(async () => { if (!city) throw new Error('Select district and city'); await api('/theatre/me', { method: 'PUT', body: readDetails(city) }); toast('Resubmitted'); pgTDash(); }); }
}

/* ---------- Theatre Admin: movies (catalogue / my requests / new request) ---------- */

/* =====================================================================
   Finance, analytics & reports: area (State > District > City > Theatre) + period filters
   ===================================================================== */
const pad2 = n => String(n).padStart(2, '0');
const isoD = d => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
const PERIODS = [['today', 'Today'], ['yesterday', 'Yesterday'], ['thisWeek', 'This week'], ['lastWeek', 'Last week'], ['thisMonth', 'This month'], ['lastMonth', 'Last month'], ['thisYear', 'This year'], ['lastYear', 'Last year'], ['custom', 'Custom range']];
function presetRange(p) {
  const n = new Date(); n.setHours(0, 0, 0, 0);
  const d = o => { const x = new Date(n); x.setDate(x.getDate() + o); return x; }, dow = (n.getDay() + 6) % 7, y = n.getFullYear(), m = n.getMonth();
  switch (p) {
    case 'today': return [n, n];
    case 'yesterday': return [d(-1), d(-1)];
    case 'thisWeek': return [d(-dow), d(6 - dow)];
    case 'lastWeek': return [d(-dow - 7), d(-dow - 1)];
    case 'lastMonth': return [new Date(y, m - 1, 1), new Date(y, m, 0)];
    case 'thisYear': return [new Date(y, 0, 1), new Date(y, 11, 31)];
    case 'lastYear': return [new Date(y - 1, 0, 1), new Date(y - 1, 11, 31)];
    default: return [new Date(y, m, 1), new Date(y, m + 1, 0)];
  }
}
let FS = store.get('fscope', null) || { preset: 'thisMonth', from: '', to: '', fromTime: '', toTime: '', basis: 'CREATED', compare: false, path: [] };
const fsSave = () => store.set('fscope', FS);
function fsRange() { if (FS.preset === 'custom' && FS.from && FS.to) return [FS.from, FS.to]; const [a, b] = presetRange(FS.preset === 'custom' ? 'thisMonth' : FS.preset); return [isoD(a), isoD(b)]; }
function fsParams(role, extra = {}) {
  const [from, to] = fsRange(), p = new URLSearchParams({ from, to, basis: FS.basis });
  if (FS.fromTime && FS.toTime) { p.set('fromTime', FS.fromTime + ':00'); p.set('toTime', FS.toTime + ':00'); }
  if (role === 'a') FS.path.forEach(x => p.set(x.type + 'Id', x.id));
  Object.entries(extra).forEach(([k, v]) => p.set(k, v));
  return p;
}
const LEVELS = ['state', 'district', 'city', 'theatre'], LEVEL_NAMES = { state: 'State / UT', district: 'District', city: 'City / Town', theatre: 'Theatre' };
const scopeLabel = r => r === 'a' ? (FS.path.length ? FS.path.map(x => esc(x.name)).join(' › ') + ` <small class="muted">(${LEVEL_NAMES[FS.path[FS.path.length - 1].type]})</small>` : 'All Tamil Nadu') : r === 't' ? 'Your theatre' : 'All platform activity';

/* Reusable filter bar. r: 'a' = Super Admin (area + period), 't' = Theatre Admin (period), 'x' = period only */
async function finBar(r, host, onChange) {
  const [from, to] = fsRange();
  const rebuild = async () => { fsSave(); await finBar(r, host, onChange); await run(onChange); };
  const crumbs = r === 'a' ? `<div class="crumbs"><button type="button" data-i="0">Tamil Nadu</button>${FS.path.map((x, i) => `<span>›</span><button type="button" data-i="${i}">${esc(x.name)}</button>`).join('')}</div>` : '';
  const pick = r === 'a' ? '<div class="filter-grid"><div><label>State / UT</label><select id="fs-state"></select></div><div><label>District</label><select id="fs-district" disabled></select></div><div><label>City / Town</label><select id="fs-city" disabled></select></div></div>' : '';
  host.innerHTML = `<div class="card finbar"><div class="scope-line"><b>Showing:</b> ${scopeLabel(r)} · <b>${from}</b> → <b>${to}</b></div>${crumbs}${pick}
    <div class="filter-grid"><div><label>Period</label><select id="fs-preset">${PERIODS.map(([k, l]) => `<option value="${k}" ${k === FS.preset ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
    <div><label>From</label><input type="date" id="fs-from" value="${from}"></div><div><label>To</label><input type="date" id="fs-to" value="${to}"></div>
    <div><label>Time of day from</label><input type="time" id="fs-t1" value="${FS.fromTime}"></div><div><label>Time of day to</label><input type="time" id="fs-t2" value="${FS.toTime}"></div>
    ${r === 'x' ? '' : `<div><label>Dates are based on</label><select id="fs-basis"><option value="CREATED" ${FS.basis === 'CREATED' ? 'selected' : ''}>Booking / payment date</option><option value="SHOW" ${FS.basis === 'SHOW' ? 'selected' : ''}>Show date &amp; time</option></select></div>`}</div>
    ${r === 'x' ? '' : `<label class="check"><input type="checkbox" id="fs-compare" ${FS.compare ? 'checked' : ''}> Compare with the previous period</label>`}</div>`;
  if (r === 'a') {
    const S = $('#fs-state'), D = $('#fs-district'), C = $('#fs-city'), opt = s => ({ id: s.value, name: s.options[s.selectedIndex].text });
    await fill(S, null, 'Select'); const TN = [...S.options].find(o => o.value && /tamil\s*nadu/i.test(o.text)); if (TN && !(FS.path[0] && FS.path[0].type === 'state')) FS.path = [{ type: 'state', id: TN.value, name: TN.text }, ...FS.path.filter(x => x.type !== 'state')]; S.closest('div').hidden = true;
    const [a, b, c] = FS.path;
    if (a && a.type === 'state') { S.value = a.id; await fill(D, a.id, 'All districts');
      if (b && b.type === 'district') { D.value = b.id; await fill(C, b.id, 'All cities'); if (c && c.type === 'city') C.value = c.id; } }
    S.onchange = () => { rebuild(); };
    D.onchange = () => { FS.path = D.value ? [{ type: 'state', ...opt(S) }, { type: 'district', ...opt(D) }] : [{ type: 'state', ...opt(S) }]; rebuild(); };
    C.onchange = () => { FS.path = C.value ? [{ type: 'state', ...opt(S) }, { type: 'district', ...opt(D) }, { type: 'city', ...opt(C) }] : [{ type: 'state', ...opt(S) }, { type: 'district', ...opt(D) }]; rebuild(); };
    host.querySelectorAll('.crumbs button').forEach(b => b.onclick = () => { FS.path = FS.path.slice(0, Number(b.dataset.i) + 1); rebuild(); });
  }
  $('#fs-preset').onchange = e => { FS.preset = e.target.value; if (FS.preset !== 'custom') { FS.from = FS.to = ''; } rebuild(); };
  const custom = () => { FS.preset = 'custom'; FS.from = val('fs-from'); FS.to = val('fs-to'); rebuild(); };
  $('#fs-from').onchange = custom; $('#fs-to').onchange = custom;
  $('#fs-t1').onchange = $('#fs-t2').onchange = () => { FS.fromTime = val('fs-t1'); FS.toTime = val('fs-t2'); if (!(FS.fromTime && FS.toTime)) { if (FS.fromTime || FS.toTime) return; } rebuild(); };
  if (r !== 'x') { $('#fs-basis').onchange = e => { FS.basis = e.target.value; rebuild(); }; $('#fs-compare').onchange = e => { FS.compare = e.target.checked; rebuild(); }; }
}

const KPIS = [
  ['gross', 'Gross ticket sales', '₹', 'money'], ['collected', 'Payments collected', '✓', 'pay'], ['failed', 'Failed payments', '!', 'pay'], ['pending', 'Pending payments', '…', 'pay'],
  ['cancelled', 'Cancelled bookings', '✕', 'count'], ['refundsRequested', 'Refunds requested', '↺', 'money'], ['refundsPending', 'Refunds pending', '↺', 'money'], ['refundsCompleted', 'Refunds completed', '✓', 'money'],
  ['commission', 'Platform commission', '%', 'money'], ['earnings', 'Theatre earnings', '▥', 'money'], ['payoutsPending', 'Payouts pending', '⏳', 'money'], ['payoutsCompleted', 'Payouts completed', '✓', 'money'],
  ['net', 'Net revenue (after refunds)', '₹', 'money'], ['avgTicket', 'Average ticket value', '₹', 'avg'], ['bookings', 'Bookings', '▤', 'count'], ['tickets', 'Tickets sold', '▣', 'tickets']];
const METRIC_TITLE = Object.fromEntries(KPIS.map(k => [k[0], k[1]]));
const fmtNum = n => Number(n || 0).toLocaleString('en-IN');
const isCountMetric = m => ['bookings', 'tickets', 'cancelled'].includes(m);
const fmtMetric = (m, v) => isCountMetric(m) ? fmtNum(v) : money(v);
function kpiCard(k, cur, prev, r, label) {
  const [key, title, icon, kind] = k; const c = cur[key] || { count: 0, value: 0 }, p = prev && prev[key];
  const main = kind === 'money' || kind === 'avg' ? money(c.value) : kind === 'tickets' ? fmtNum(c.value) : fmtNum(c.count);
  const sub = kind === 'pay' ? money(c.value) : kind === 'money' ? fmtNum(c.count) + ' records' : kind === 'count' ? '' : '';
  const a = kind === 'money' || kind === 'avg' || kind === 'tickets' ? Number(c.value) : Number(c.count), b = p ? (kind === 'money' || kind === 'avg' || kind === 'tickets' ? Number(p.value) : Number(p.count)) : null;
  const delta = b == null ? '' : b === 0 ? (a === 0 ? '<i class="delta">no change</i>' : '<i class="delta up">new</i>') : `<i class="delta ${a >= b ? 'up' : 'down'}">${a >= b ? '▲' : '▼'} ${Math.abs((a - b) / b * 100).toFixed(0)}% vs previous</i>`;
  const tone = ['collected', 'refundsCompleted', 'payoutsCompleted'].includes(key) ? 'sage' : ['failed', 'cancelled'].includes(key) ? 'terra' : ['refundsRequested', 'refundsPending'].includes(key) ? 'rose' : ['pending', 'payoutsPending'].includes(key) ? 'butter' : ['gross', 'net', 'commission', 'earnings', 'avgTicket'].includes(key) ? 'gold' : 'ivory';
  return `<a class="stat2 kpi tone-${tone}" href="#/${r}/finance/m/${key}"><span class="stat2-ic">${icon}</span><div><span class="muted">${label || title}</span><b>${main}</b>${sub ? `<small>${sub}</small>` : ''}${delta}</div></a>`;
}

/* ---------- Finance overview (Super Admin: any area; Theatre Admin: own theatre) ---------- */
async function pgFinance(r) {
  const base = r === 'a' ? '/admin/finance' : '/theatre/finance';
  let by = 'auto';
  view(pageHead('FINANCE', r === 'a' ? 'Finance' : 'Finance &amp; analytics', r === 'a' ? 'Pick an area and a period. Every number follows your choice; click a card to see the records behind it.' : 'Your theatre\u2019s sales, commission, earnings and refunds. Click a card to see the records.', '<button class="btn sec small" id="fxs" type="button">Export summary</button><button class="btn sec small" id="fxb" type="button">Export breakdown</button>')
    + '<div id="fbar"></div><div id="fnote"></div><div id="fk"></div><div id="fb"></div>');
  const draw = async () => {
    const [s, g] = await Promise.all([api(base + '/summary?' + fsParams(r, { compare: FS.compare })), api(base + '/breakdown?' + fsParams(r, { by }))]);
    $('#fnote').innerHTML = `<p class="muted small-note">Counting by: <b>${esc(s.timeBasis)}</b>. ${FS.compare && s.previousRange ? 'Compared with ' + esc(s.previousRange) + '.' : ''}</p>`;
    $('#fk').innerHTML = statementHtml(s, r);
    const next = r === 'a' && by === 'auto' ? LEVELS[FS.path.length] : null;
    const timeline = ['day', 'month', 'hour', 'weekday'].includes(by);
    const opts = (r === 'a' ? [['auto', FS.path.length >= 4 ? 'Movie' : 'Next level: ' + LEVEL_NAMES[LEVELS[FS.path.length]]], ['theatre', 'Theatre'], ['movie', 'Movie']] : [['auto', 'Movie']]).concat([['language', 'Language'], ['screen', 'Screen'], ['day', 'Day'], ['month', 'Month'], ['hour', 'Showtime (hour)'], ['weekday', 'Weekday']]);
    $('#fb').innerHTML = `<div class="card"><div class="page-heading"><div><h3>Sales breakdown</h3><p class="muted">Confirmed bookings only${next ? ' · click a row to go deeper' : ''}</p></div><div class="head-actions"><label class="inline">View by <select id="by">${opts.map(([k, l]) => `<option value="${k}" ${k === by ? 'selected' : ''}>${l}</option>`).join('')}</select></label></div></div>
      ${g.length ? (timeline ? barChart(g.map(x => ({ label: x.label, v: Number(x.gross) })), v => '₹' + Math.round(v)) : '') + `<div class="tablewrap"><table><tr><th>${timeline ? 'When' : 'Group'}</th><th>Bookings</th><th>Tickets</th><th>Gross sales</th><th>Commission</th><th>Theatre earnings</th></tr>${g.map((x, i) => `<tr class="${next && x.id ? 'click' : ''}" data-i="${i}"><td>${esc(x.label || '—')}</td><td>${x.bookings}</td><td>${x.tickets}</td><td>${money(x.gross)}</td><td>${money(x.commission)}</td><td>${money(x.earnings)}</td></tr>`).join('')}</table></div>` : emptyBox('No confirmed bookings for this area and period.')}</div>`;
    bindFinExport(s, g, r);
    $('#by').onchange = e => { by = e.target.value; run(draw); };
    if (next) document.querySelectorAll('#fb tr.click').forEach(tr => tr.onclick = async () => { const x = g[Number(tr.dataset.i)]; FS.path.push({ type: next, id: x.id, name: x.label }); fsSave(); await finBar(r, $('#fbar'), draw); run(draw); });
  };
  await finBar(r, $('#fbar'), draw); await draw();
}

/* ---------- Records behind one metric ---------- */
async function pgFinMetric(r, metric) {
  const base = r === 'a' ? '/admin/finance' : '/theatre/finance', pay = ['collected', 'failed', 'pending'].includes(metric), back = `#/${r}/finance`;
  let page = 0, q = '', sort = 'createdAt', asc = false, cur = null;
  view(pageHead('FINANCE', esc(METRIC_TITLE[metric] || metric), 'The records that add up to this figure, for the area and period below.', `<a class="btn sec small" href="${back}">← Back to finance</a><button class="btn sec small" id="fx">Export CSV</button>`)
    + '<div id="fbar"></div><div class="card"><div class="filter-grid"><div><label>Search</label><input id="fq" placeholder="Reference, theatre, movie, customer…"></div></div><div id="fsum"></div><div id="frows"></div></div>');
  const cols = pay
    ? [['Created', x => fmt(x.createdAt), 'createdAt'], ['Transaction', x => esc(x.transactionRef)], ['Booking', x => esc(x.reference)], ...(r === 'a' ? [['Theatre', x => esc(x.theatre), 'theatre'], ['Location', x => esc([x.city, x.district].filter(Boolean).join(', '))]] : []), ['Movie', x => esc(x.movie)], ['Amount', x => money(x.amount), 'amount'], ['Status', x => badge(x.paymentStatus)], ['Message', x => esc(x.message || '')]]
    : [['Created', x => fmt(x.createdAt), 'createdAt'], ['Booking', x => esc(x.reference)], ...(r === 'a' ? [['Theatre', x => esc(x.theatre), 'theatre'], ['Location', x => esc([x.city, x.district].filter(Boolean).join(', '))]] : []), ['Movie · show', x => esc(x.movie) + '<br><small class="muted">' + fmt(x.showTime) + '</small>', 'showTime'], ['Tickets', x => x.tickets], ['Amount', x => money(x.amount), 'amount'], ['Comm. %', x => x.commissionRate == null ? '—' : x.commissionRate + '%'], ['Commission', x => x.commissionAmount == null ? '—' : money(x.commissionAmount)], ['Theatre payable', x => x.theatrePayable == null ? '—' : money(x.theatrePayable)], ['Refund', x => x.refundAmount == null ? '—' : money(x.refundAmount)], ['Status', x => badge(x.bookingStatus) + ' ' + badge(x.paymentStatus)]];
  const load = async () => { cur = await api(`${base}/records?` + fsParams(r, { metric, q, sort, asc, page, size: 25 })); paint(); };
  const paint = () => {
    const pages = Math.max(1, Math.ceil(cur.total / cur.size));
    $('#fsum').innerHTML = `<p class="muted"><b>${fmtNum(cur.total)}</b> record(s) · total <b class="gold">${fmtMetric(metric, cur.totalValue)}</b>${metric === 'payoutsCompleted' ? ' · payout records are not tracked yet' : ''}</p>`;
    $('#frows').innerHTML = cur.rows.length ? `<div class="tablewrap"><table><tr>${cols.map(c => `<th ${c[2] ? `class="sortable" data-s="${c[2]}"` : ''}>${c[0]}${c[2] === sort ? (asc ? ' ▲' : ' ▼') : ''}</th>`).join('')}</tr>${cur.rows.map(x => `<tr>${cols.map(c => `<td>${c[1](x)}</td>`).join('')}</tr>`).join('')}</table></div>
      <div class="pager"><button class="btn sec small" id="pp" ${page === 0 ? 'disabled' : ''}>← Previous</button><span class="muted">Page ${page + 1} of ${pages}</span><button class="btn sec small" id="pn" ${page + 1 >= pages ? 'disabled' : ''}>Next →</button></div>` : emptyBox('No records for this area and period.');
    document.querySelectorAll('#frows th.sortable').forEach(th => th.onclick = () => { if (sort === th.dataset.s) asc = !asc; else { sort = th.dataset.s; asc = false; } page = 0; run(load); });
    const pp = $('#pp'), pn = $('#pn'); if (pp) pp.onclick = () => { page--; run(load); }; if (pn) pn.onclick = () => { page++; run(load); };
  };
  $('#fq').oninput = debounce(e => { q = e.target.value; page = 0; run(load); }, 350);
  $('#fx').onclick = () => run(() => csvDialog(`cinebook-${metric}.csv`, cols.map(c => [c[0], c[1]]), async () => { const all = []; for (let p = 0; p < 20; p++) { const c = await api(`${base}/records?` + fsParams(r, { metric, q, sort, asc, page: p, size: 1000 })); all.push(...c.rows); if (all.length >= c.total) break; } return all; }, 'records for the chosen area, period and search'));
  await finBar(r, $('#fbar'), () => { page = 0; return load(); }); await load();
}

/* ---------- Reports dashboard: few big numbers, each opens its records ---------- */

/* ---------- Recent activity (readable) and audit trail (formal), same period filter ---------- */
async function pgAActivity() {
  const [logs, users, theatres] = await Promise.all([api('/admin/audit'), api('/admin/users').catch(() => []), api('/admin/theatres?' + new URLSearchParams({ q: '', status: '' })).catch(() => [])]);
  const roleOf = {}, areaOf = {}; users.forEach(u => roleOf[String(u.email).toLowerCase()] = u.role); theatres.forEach(t => areaOf[String(t.ownerEmail || '').toLowerCase()] = { state: t.state, city: t.city, theatre: t.name });
  const RL = { CUSTOMER: 'Customer', THEATRE_ADMIN: 'Theatre', SUPER_ADMIN: 'Admin' }, roleTag = e => { const r = roleOf[String(e).toLowerCase()], a = areaOf[String(e).toLowerCase()]; return r ? ` <span class="chip static">${RL[r] || r}${a ? ' · ' + esc(a.theatre) : ''}</span>` : ''; };
  let tab = 'recent', actor = '', type = '', role = '', ast = '', act = '';
  view(pageHead('INSIGHTS', 'Activity &amp; audit', 'Recent activity is the readable feed; the audit trail is the formal read-only record. Both follow the period below (audit records carry no location).')
    + '<div id="fbar"></div>' + tabsHtml('atabs', [['recent', 'Recent activity'], ['audit', 'Audit trail']], tab)
    + '<div class="card"><div class="filter-grid"><div><label>Actor</label><input id="aa" placeholder="Email contains…"></div><div><label>Event type</label><select id="at"></select></div><div><label>Role</label><select id="ar"><option value="">All roles</option><option value="CUSTOMER">Customers</option><option value="THEATRE_ADMIN">Theatres</option><option value="SUPER_ADMIN">Super admins</option></select></div><div><label>City (theatres)</label><select id="act"><option value="">All cities</option>' + [...new Set(theatres.map(t => t.city).filter(Boolean))].sort().map(x => '<option>' + esc(x) + '</option>').join('') + '</select></div><div><button class="btn sec" id="axp" type="button">Export this list</button> <button class="btn" id="axr" type="button">Activity report</button></div></div><div id="alist"></div></div>');
  const types = [...new Set(logs.map(l => l.action))].sort();
  $('#at').innerHTML = '<option value="">All events</option>' + types.map(t => `<option>${esc(t)}</option>`).join('');
  const human = a => String(a).toLowerCase().replace(/_/g, ' ');
  const draw = () => {
    const [f, t] = fsRange();
    const list = logs.filter(l => { const d = String(l.at).slice(0, 10); return d >= f && d <= t && (!actor || l.actorEmail.toLowerCase().includes(actor)) && (!type || l.action === type) && (!role || roleOf[l.actorEmail.toLowerCase()] === role) && (!ast || (areaOf[l.actorEmail.toLowerCase()] || {}).state === ast) && (!act || (areaOf[l.actorEmail.toLowerCase()] || {}).city === act); }); CUR_A = list;
    $('#alist').innerHTML = !list.length ? emptyBox('No events in this period.') : tab === 'audit'
      ? `<div class="tablewrap"><table><tr><th>When</th><th>Actor</th><th>Event</th><th>Details</th></tr>${list.map(x => `<tr><td>${fmt(x.at)}</td><td>${esc(x.actorEmail)}${roleTag(x.actorEmail)}</td><td>${badge(x.action)}</td><td>${esc(x.details || '')}</td></tr>`).join('')}</table></div><p class="muted small-note">Read-only. ${list.length} event(s).</p>`
      : ['Today', 'Yesterday', 'This week', 'Earlier'].map(g => [g, list.filter(x => dayGroup(x.at) === g)]).filter(([, x]) => x.length).map(([g, items]) => `<div class="day-group"><h3>${g}</h3><ul class="timeline">${items.map(x => `<li><b>${esc(x.actorEmail)}</b>${roleTag(x.actorEmail)} · ${esc(human(x.action))}${x.details ? ' — ' + esc(x.details) : ''}<br><small class="muted">${fmt(x.at)}</small></li>`).join('')}</ul></div>`).join('');
  };
  $('#aa').oninput = e => { actor = e.target.value.toLowerCase(); draw(); }; $('#at').onchange = e => { type = e.target.value; draw(); };
  $('#ar').onchange = e => { role = e.target.value; draw(); };
  $('#act').onchange = e => { act = e.target.value; draw(); };
  $('#axr').onclick = () => run(() => activityExport('a'));
  $('#axp').onclick = () => csvDialog('cinebook-activity.csv', [['When', x => x.at], ['Actor', x => x.actorEmail], ['Role', x => RL[roleOf[String(x.actorEmail).toLowerCase()]] || ''], ['Theatre', x => (areaOf[String(x.actorEmail).toLowerCase()] || {}).theatre || ''], ['City', x => (areaOf[String(x.actorEmail).toLowerCase()] || {}).city || ''], ['Event', x => x.action], ['Details', x => x.details]], CUR_A);
  wireTabs('atabs', k => { tab = k; draw(); });
  await finBar('x', $('#fbar'), draw); draw();
}

/* =====================================================================
   Offers, reviews, complaints, refunds, screen editing, show cancellation
   ===================================================================== */
function modal(html) { const o = document.createElement('div'); o.className = 'overlay'; o.innerHTML = `<div class="modal">${html}</div>`; o.onclick = e => { if (e.target === o) o.remove(); }; document.body.appendChild(o); return o; }
const stars = n => '★'.repeat(n) + '☆'.repeat(5 - n);
const dtLocal = d => d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) + 'T' + pad2(d.getHours()) + ':' + pad2(d.getMinutes());
const optNum = id => { const v = val(id); return v === '' ? null : Number(v); };

/* ---------- Theatre: screens (add + edit) ---------- */

/* ---------- Theatre: cancel a show with a reason ---------- */
function cancelShow(id) {
  const m = modal(`<h3>Cancel this show</h3><p class="muted">All bookings are cancelled and customers are told the reason. Full refunds are queued for the Super Admin to complete.</p>
    <label>Reason (shown to customers)</label><textarea id="creason" rows="3" maxlength="300" placeholder="e.g. Projector failure / low bookings / film print not received"></textarea>
    <div class="actions"><button class="btn danger" id="cgo">Cancel show &amp; refund customers</button><button class="btn sec" id="cno">Keep show</button></div>`);
  m.querySelector('#cno').onclick = () => m.remove();
  m.querySelector('#cgo').onclick = () => { const reason = m.querySelector('#creason').value.trim(); if (reason.length < 5) return toast('Please give a reason (at least 5 characters)', 'err');
    run(async () => { await api(`/theatre/shows/${id}/cancel`, { method: 'POST', body: { reason } }); m.remove(); toast('Show cancelled. Refunds are now pending.'); pgTShows(); }); };
}

/* ---------- Customer: bookings with reviews ---------- */
function rateBooking(ref, title) {
  let rating = 0;
  const m = modal(`<h3>Rate “${esc(title)}”</h3><p class="muted">Only people who booked and watched can review. Reviews are final.</p><div class="starpick" id="sp">${[1, 2, 3, 4, 5].map(i => `<button type="button" data-v="${i}">☆</button>`).join('')}</div>
    <label>Your review (optional)</label><textarea id="rtext" rows="4" maxlength="1000"></textarea><div class="actions"><button class="btn" id="rgo">Submit review</button><button class="btn sec" id="rno">Close</button></div>`);
  m.querySelectorAll('#sp button').forEach(b => b.onclick = () => { rating = Number(b.dataset.v); m.querySelectorAll('#sp button').forEach(x => x.textContent = Number(x.dataset.v) <= rating ? '★' : '☆'); });
  m.querySelector('#rno').onclick = () => m.remove();
  m.querySelector('#rgo').onclick = () => { if (!rating) return toast('Choose a star rating', 'err'); run(async () => { await api('/customer/reviews', { method: 'POST', body: { reference: ref, rating, comment: m.querySelector('#rtext').value } }); m.remove(); toast('Thanks for your review!'); pgBookings(); }); };
}

/* ---------- Customer: offers ---------- */
async function pgOffers() {
  const list = await api('/public/offers');
  view(pageHead('OFFERS', 'Offers &amp; coupons', 'Copy a code and paste it when you pick your seats. The discount is checked by our server before you pay.')
    + (list.length ? `<div class="offer-grid">${list.map(o => `<div class="offer"><div class="offer-top"><span class="offer-code">${esc(o.code)}</span><button class="btn sec small" data-copy="${esc(o.code)}">Copy</button></div>
      <h3>${esc(o.title)}</h3><p class="offer-val">${o.discountType === 'PERCENT' ? o.discountValue + '% off' : money(o.discountValue) + ' off'}${o.maxDiscount ? ` <small class="muted">(up to ${money(o.maxDiscount)})</small>` : ''}</p>
      ${o.description ? `<p class="muted">${esc(o.description)}</p>` : ''}<ul class="terms"><li>Valid at: <b>${esc(o.scope)}</b></li>${o.movieTitle ? `<li>Only for: <b>${esc(o.movieTitle)}</b></li>` : ''}${Number(o.minAmount) > 0 ? `<li>Minimum booking ${money(o.minAmount)}</li>` : ''}<li>${o.perUserLimit} use${o.perUserLimit > 1 ? 's' : ''} per customer</li><li>Expires ${fmt(o.endsAt)}</li></ul></div>`).join('')}</div>` : emptyBox('No offers are running right now. Check back soon!')));
  document.querySelectorAll('[data-copy]').forEach(b => b.onclick = async () => { try { await navigator.clipboard.writeText(b.dataset.copy); toast('Copied ' + b.dataset.copy); } catch (e) { toast('Code: ' + b.dataset.copy); } });
}

/* ---------- Admin + Theatre: manage offers ---------- */
async function pgManageOffers(r) {
  const base = r === 'a' ? '/admin/offers' : '/theatre/offers';
  const [list, movies, theatres] = await Promise.all([api(base), api('/public/movies'), r === 'a' ? api('/admin/theatres?' + new URLSearchParams({ q: '', status: 'APPROVED' })) : Promise.resolve([])]);
  const now = new Date(), end = new Date(now.getTime() + 30 * 864e5);
  view(pageHead(r === 'a' ? 'ENGAGE' : 'ENGAGE', 'Offers', r === 'a' ? 'Platform-wide offers, or limit one to a single theatre or movie.' : 'Offers that apply only at your theatre.')
    + `<details class="card" id="of-new"><summary>＋ Create an offer</summary><div class="filter-grid">
      <div><label>Coupon code</label><input id="of-code" placeholder="WEEKEND20" maxlength="30"></div><div><label>Title</label><input id="of-title" maxlength="120" placeholder="Weekend 20% off"></div>
      <div><label>Discount type</label><select id="of-type"><option value="PERCENT">Percentage (%)</option><option value="FLAT">Fixed amount (₹)</option></select></div><div><label>Discount value</label><input id="of-val" type="number" min="1" step="0.01"></div>
      <div><label>Minimum booking (₹)</label><input id="of-min" type="number" min="0" value="0"></div><div><label>Maximum discount (₹, optional)</label><input id="of-max" type="number" min="0"></div>
      <div><label>Starts</label><input id="of-start" type="datetime-local" value="${dtLocal(now)}"></div><div><label>Ends</label><input id="of-end" type="datetime-local" value="${dtLocal(end)}"></div>
      <div><label>Total uses (optional)</label><input id="of-total" type="number" min="1"></div><div><label>Uses per customer</label><input id="of-per" type="number" min="1" value="1"></div>
      <div><label>Only for movie (optional)</label><select id="of-movie"><option value="">Any movie</option>${movies.map(m => `<option value="${m.id}">${esc(m.title)}</option>`).join('')}</select></div>
      ${r === 'a' ? `<div><label>Valid at</label><select id="of-theatre"><option value="">All theatres</option>${theatres.map(t => `<option value="${t.id}">${esc(t.name)} — ${esc(t.city)}</option>`).join('')}</select></div>` : ''}</div>
      <label>Description / terms (optional)</label><textarea id="of-desc" rows="2" maxlength="500"></textarea><button class="btn" id="of-save">Create offer</button></details>
    <div class="card"><h3>Your offers</h3>${list.length ? `<div class="tablewrap"><table><tr><th>Code</th><th>Offer</th><th>Where</th><th>Valid</th><th>Used</th><th>Status</th><th></th></tr>${list.map(o => `<tr><td><b>${esc(o.code)}</b></td><td>${esc(o.title)}<br><small class="muted">${o.discountType === 'PERCENT' ? o.discountValue + '%' : money(o.discountValue)}${o.maxDiscount ? ' (max ' + money(o.maxDiscount) + ')' : ''}${Number(o.minAmount) > 0 ? ' · min ' + money(o.minAmount) : ''}</small></td><td>${esc(o.scope)}${o.movieTitle ? '<br><small class="muted">' + esc(o.movieTitle) + '</small>' : ''}</td><td>${fmt(o.startsAt)}<br>→ ${fmt(o.endsAt)}</td><td>${o.redeemed}${o.totalLimit ? ' / ' + o.totalLimit : ''}</td><td>${badge(o.effectiveStatus)}</td><td>${o.effectiveStatus === 'EXPIRED' ? '' : `<button class="btn sec small" data-tog="${o.id}" data-to="${o.status === 'ACTIVE' ? 'PAUSED' : 'ACTIVE'}">${o.status === 'ACTIVE' ? 'Pause' : 'Resume'}</button>`}</td></tr>`).join('')}</table></div>` : emptyBox('No offers yet.')}</div>`);
  $('#of-save').onclick = () => run(async () => {
    await api(base, { method: 'POST', body: { code: val('of-code'), title: val('of-title'), description: val('of-desc'), discountType: val('of-type'), discountValue: optNum('of-val'), minAmount: optNum('of-min'), maxDiscount: optNum('of-max'),
      startsAt: val('of-start'), endsAt: val('of-end'), totalLimit: optNum('of-total'), perUserLimit: optNum('of-per'), movieId: optNum('of-movie'), theatreId: r === 'a' ? optNum('of-theatre') : null } });
    toast('Offer created'); pgManageOffers(r); });
  document.querySelectorAll('[data-tog]').forEach(b => b.onclick = () => run(async () => { await api(`${base}/${b.dataset.tog}/status?status=${b.dataset.to}`, { method: 'PUT' }); pgManageOffers(r); }));
}

/* ---------- Theatre: reviews of my shows ---------- */

/* ---------- Super Admin: ratings and low-rating alerts ---------- */
async function pgAReviews() {
  const d = await api('/admin/reviews/ratings'), th = d.thresholds;
  let tab = d.theatres.some(t => t.flagged) ? 'flagged' : 'all';
  view(pageHead('ENGAGE', 'Reviews &amp; ratings', `Last ${th.windowDays} days. A theatre is flagged when it has at least ${th.minReviews} reviews and an average of ${th.lowAverage} or lower (or half of them are 1–2★). Flags never suspend a theatre — you review the evidence and decide.`)
    + tabsHtml('rvt', [['flagged', 'Needs attention', d.theatres.filter(t => t.flagged).length], ['all', 'All theatres', d.theatres.length], ['reported', 'Reported reviews']], tab) + '<div class="card"><div class="filter-grid"><div><label>Search theatre or city</label><input id="rvq" placeholder="Type a theatre or city"></div></div></div><div id="rvb"></div><div id="rve"></div>');
  const evidence = async (theatreId, reportedOnly) => {
    const list = await api('/admin/reviews?' + new URLSearchParams({ reportedOnly, ...(theatreId ? { theatreId } : {}) }));
    $('#rve').innerHTML = `<div class="card"><h3>${reportedOnly ? 'Reported reviews' : 'Reviews (evidence)'}</h3>${list.length ? list.map(r => `<div class="review"><div><span class="gold">${stars(r.rating)}</span> <b>${esc(r.theatre)}</b> · ${esc(r.movie)} <small class="muted">· ${esc(r.customer)} · ${fmt(r.createdAt)}</small> ${badge(r.status)}</div>
      ${r.comment ? `<p>${esc(r.comment)}</p>` : ''}${r.reported ? `<p class="warn small-note">Reported by theatre: ${esc(r.reportReason || '')}</p>` : ''}${r.hiddenReason ? `<p class="muted">Hidden: ${esc(r.hiddenReason)}</p>` : ''}
      ${r.status === 'VISIBLE' ? `<button class="btn danger small" data-hide="${r.id}">Hide</button>` : `<button class="btn sec small" data-show="${r.id}">Restore</button>`}</div>`).join('') : emptyBox('No reviews.')}</div>`;
    document.querySelectorAll('[data-hide]').forEach(b => b.onclick = () => { const reason = prompt('Reason for hiding this review (kept in the audit trail):'); if (reason) run(async () => { await api(`/admin/reviews/${b.dataset.hide}/hide`, { method: 'POST', body: { reason } }); evidence(theatreId, reportedOnly); }); });
    document.querySelectorAll('[data-show]').forEach(b => b.onclick = () => run(async () => { await api(`/admin/reviews/${b.dataset.show}/restore`, { method: 'POST' }); evidence(theatreId, reportedOnly); }));
  };
  const draw = () => {
    if (tab === 'reported') { $('#rvb').innerHTML = ''; evidence(null, true); return; }
    $('#rve').innerHTML = '';
    const l = d.theatres.filter(t => (tab === 'all' || t.flagged) && (!fv('rvq') || (t.theatre + ' ' + t.city).toLowerCase().includes(fv('rvq'))));
    $('#rvb').innerHTML = `<div class="card">${l.length ? `<div class="tablewrap"><table><tr><th>Theatre</th><th>City</th><th>Average</th><th>Reviews</th><th>1–2★</th><th></th><th></th></tr>${l.map(t => `<tr><td><b>${esc(t.theatre)}</b></td><td>${esc(t.city)}</td><td class="gold">${t.average.toFixed(2)}</td><td>${t.count}</td><td>${t.lowCount}</td><td>${t.flagged ? '<span class="badge FAILED">Low rating</span>' : ''}</td><td><button class="btn sec small" data-ev="${t.theatreId}">View reviews</button></td></tr>`).join('')}</table></div>` : emptyBox(tab === 'flagged' ? 'No theatre needs attention' : 'No reviews in this period yet.')}</div>`;
    document.querySelectorAll('[data-ev]').forEach(b => b.onclick = () => { evidence(Number(b.dataset.ev), false); $('#rve').scrollIntoView({ behavior: 'smooth' }); });
  };
  wireTabs('rvt', k => { tab = k; draw(); }); $('#rvq').oninput = () => { if (tab !== 'reported') draw(); }; draw();
}

/* ---------- Complaints ---------- */
const CSTATUS = ['IN_PROGRESS', 'RESOLVED', 'CLOSED'];
const cCard = (c, canRespond) => `<div class="review"><div><b>${esc(c.subject)}</b> ${badge(c.status)} <span class="badge">${c.type === 'PLATFORM' ? 'About the website' : c.type === 'THEATRE' ? 'About ' + esc(c.theatre || 'a theatre') : 'Theatre → Admin'}</span><br><small class="muted">${esc(c.from)} · ${fmt(c.createdAt)}${c.bookingReference ? ' · Booking ' + esc(c.bookingReference) : ''}${c.theatre && c.type === 'ADMIN' ? ' · ' + esc(c.theatre) : ''}</small></div>
  <p>${esc(c.message)}</p>${c.response ? `<p class="reply"><b>Reply (${esc(c.respondedBy || '')}, ${fmt(c.respondedAt)}):</b> ${esc(c.response)}</p>` : ''}${canRespond && c.status !== 'CLOSED' ? `<button class="btn sec small" data-reply="${c.id}">Reply / update</button>` : ''}</div>`;
function wireReplies(base, after) {
  document.querySelectorAll('[data-reply]').forEach(b => b.onclick = () => {
    const m = modal(`<h3>Reply to complaint</h3><label>Status</label><select id="cs">${CSTATUS.map(x => `<option>${x}</option>`).join('')}</select><label>Your reply</label><textarea id="cr" rows="4" maxlength="2000"></textarea><div class="actions"><button class="btn" id="cgo">Send</button><button class="btn sec" id="cno">Close</button></div>`);
    m.querySelector('#cno').onclick = () => m.remove();
    m.querySelector('#cgo').onclick = () => run(async () => { await api(`${base}/${b.dataset.reply}/respond`, { method: 'POST', body: { status: m.querySelector('#cs').value, response: m.querySelector('#cr').value } }); m.remove(); toast('Reply sent'); after(); });
  });
}

async function pgCComplaints() {
  const [list, bookings] = await Promise.all([api('/customer/complaints'), api('/customer/bookings')]);
  view(pageHead('HELP', 'Help &amp; complaints', 'Tell us about a problem with the website or with a theatre you booked at. You will be notified when it is answered.')
    + `<div class="card"><h3>New complaint</h3><div class="filter-grid"><div><label>About</label><select id="cx-type"><option value="PLATFORM">The website / app</option><option value="THEATRE">A theatre I booked at</option></select></div>
      <div id="cx-bk-wrap" hidden><label>Which booking?</label><select id="cx-bk">${bookings.map(b => `<option value="${esc(b.reference)}">${esc(b.theatreName)} · ${esc(b.movieTitle)} · ${fmt(b.showTime)}</option>`).join('')}</select></div></div>
      <label>Subject</label><input id="cx-sub" maxlength="150"><label>What happened?</label><textarea id="cx-msg" rows="4" maxlength="2000"></textarea><button class="btn" id="cx-go">Submit complaint</button></div>
    <div class="card"><h3>My complaints</h3>${list.length ? list.map(c => cCard(c, false)).join('') : emptyBox('You have not raised any complaints.')}</div>`);
  $('#cx-type').onchange = e => { $('#cx-bk-wrap').hidden = e.target.value !== 'THEATRE'; };
  $('#cx-go').onclick = () => run(async () => { const t = val('cx-type'); await api('/customer/complaints', { method: 'POST', body: { type: t, bookingReference: t === 'THEATRE' ? val('cx-bk') : null, subject: val('cx-sub'), message: val('cx-msg') } }); toast('Complaint submitted'); pgCComplaints(); });
}

async function pgTComplaints() {
  const d = await api('/theatre/complaints');
  view(pageHead('ENGAGE', 'Complaints', 'Customer complaints about your theatre, and your own messages to the Super Admin.')
    + `<div class="card"><h3>Customers' complaints about your theatre</h3>${d.inbox.length ? d.inbox.map(c => cCard(c, true)).join('') : emptyBox('No complaints from customers.')}</div>
    <details class="card"><summary>⚑ Raise a complaint with the Super Admin</summary><label>Subject</label><input id="tx-sub" maxlength="150"><label>Details</label><textarea id="tx-msg" rows="4" maxlength="2000"></textarea><button class="btn" id="tx-go">Send to Super Admin</button></details>
    <div class="card"><h3>My messages to the Super Admin</h3>${d.mine.length ? d.mine.map(c => cCard(c, false)).join('') : emptyBox('None yet.')}</div>`);
  wireReplies('/theatre/complaints', pgTComplaints);
  $('#tx-go').onclick = () => run(async () => { await api('/theatre/complaints', { method: 'POST', body: { subject: val('tx-sub'), message: val('tx-msg') } }); toast('Sent to the Super Admin'); pgTComplaints(); });
}

async function pgAComplaints() {
  let all = await api('/admin/complaints?includeTheatre=true'), tab = 'OPEN';
  view(pageHead('ENGAGE', 'Complaints', 'Website complaints from customers and messages from theatres. Customer-to-theatre complaints are handled by the theatre; you can see them here too.') + '<div class="card"><div class="filter-grid"><div><label>Search</label><input id="cq" placeholder="Subject, customer, theatre or message"></div></div></div><div id="ct"></div><div id="cl"></div>');
  const draw = () => {
    const groups = [['OPEN', 'Open'], ['IN_PROGRESS', 'In progress'], ['RESOLVED', 'Resolved'], ['CLOSED', 'Closed']];
    $('#ct').innerHTML = tabsHtml('ctabs', groups.map(([k, l]) => [k, l, all.filter(c => c.status === k).length]), tab);
    wireTabs('ctabs', k => { tab = k; draw(); });
    const l = all.filter(c => c.status === tab && (!fv('cq') || JSON.stringify(c).toLowerCase().includes(fv('cq'))));
    $('#cl').innerHTML = `<div class="card">${l.length ? l.map(c => cCard(c, true)).join('') : emptyBox('Nothing here.')}</div>`;
    wireReplies('/admin/complaints', async () => { all = await api('/admin/complaints?includeTheatre=true'); draw(); });
  };
  $('#cq').oninput = draw;
  draw();
}

/* ---------- Super Admin: refund tracker ---------- */
async function pgARefunds() {
  let tab = 'pending', list = await api('/admin/refunds');
  view(pageHead('FINANCE', 'Refunds', 'Cancelled bookings and cancelled shows. Payments run in test mode, so pay the customer outside the system, then mark the refund completed here — the customer is notified and finance reports update.') + '<div class="card"><div class="filter-grid"><div><label>Search</label><input id="rq" placeholder="Booking, customer, movie or theatre"></div><div><button class="btn sec" id="rfx" type="button">Export CSV</button></div></div></div><div id="rt"></div><div id="rl"></div>');
  const draw = () => {
    const pend = list.filter(r => r.paymentStatus === 'REFUND_PENDING'), done = list.filter(r => r.paymentStatus === 'REFUNDED');
    $('#rt').innerHTML = tabsHtml('rtabs', [['pending', 'Pending', pend.length], ['done', 'Completed', done.length]], tab);
    wireTabs('rtabs', k => { tab = k; draw(); });
    const l = (tab === 'pending' ? pend : done).filter(r => !fv('rq') || JSON.stringify(r).toLowerCase().includes(fv('rq'))); CUR_R = l;
    $('#rl').innerHTML = `<div class="card">${l.length ? `<p class="muted">Total: <b class="gold">${money(l.reduce((a, r) => a + Number(r.amount || 0), 0))}</b></p><div class="tablewrap"><table><tr><th>Booking</th><th>Customer</th><th>Movie · theatre</th><th>Amount</th><th>Reason</th><th>${tab === 'pending' ? 'Cancelled' : 'Refunded'}</th><th></th></tr>${l.map(r => `<tr><td>${esc(r.reference)}</td><td>${esc(r.customer)}</td><td>${esc(r.movie)}<br><small class="muted">${esc(r.theatre)} · ${fmt(r.showTime)}</small></td><td>${money(r.amount)}</td><td>${esc(r.reason || '')}</td><td>${fmt(tab === 'pending' ? r.cancelledAt : r.refundedAt)}${tab === 'done' ? '<br><small class="muted">Ref ' + esc(r.refundReference || '') + '</small>' : ''}</td><td>${tab === 'pending' ? `<button class="btn small" data-done="${esc(r.reference)}">Mark refunded</button>` : ''}</td></tr>`).join('')}</table></div>` : emptyBox(tab === 'pending' ? 'No pending refunds' : 'No completed refunds yet.')}</div>`;
    document.querySelectorAll('[data-done]').forEach(b => b.onclick = () => { const ref = prompt('Refund reference / transaction id (optional — one is generated if blank):'); if (ref === null) return;
      run(async () => { await api(`/admin/refunds/${encodeURIComponent(b.dataset.done)}/complete`, { method: 'POST', body: { reference: ref } }); toast('Refund marked completed'); list = await api('/admin/refunds'); draw(); }); });
  };
  $('#rq').oninput = draw;
  $('#rfx').onclick = () => csvDialog('cinebook-refunds.csv', [['Booking', r => r.reference], ['Customer', r => r.customer], ['Movie', r => r.movie], ['Theatre', r => r.theatre], ['Show time', r => r.showTime], ['Amount', r => r.amount], ['Reason', r => r.reason], ['Status', r => r.paymentStatus], ['Cancelled', r => r.cancelledAt], ['Refunded', r => r.refundedAt], ['Refund ref', r => r.refundReference]], CUR_R);
  draw();
}

/* =====================================================================
   Seat grid, BookMyShow-style show page, theatre studio (designer, shows, movie runs)
   ===================================================================== */
/* Draws seats by section with aisles/gaps. Used for customer booking and for the designer preview. */
function seatGridHtml(seats, opts) {
  const preview = !!(opts && opts.preview), cols = Math.max(...seats.map(s => s.gridCol)) + 1;
  const bySection = new Map();
  [...seats].sort((a, b) => a.gridRow - b.gridRow || a.gridCol - b.gridCol).forEach(s => { if (!bySection.has(s.section)) bySection.set(s.section, []); bySection.get(s.section).push(s); });
  let prevRow = -1;
  return [...bySection.entries()].map(([sec, list]) => {
    const prices = list.map(x => Number(x.price)).filter(x => x > 0), price = prices.length ? '₹' + Math.min(...prices) + ' ' : '';
    const rows = new Map(); list.forEach(s => { if (!rows.has(s.gridRow)) rows.set(s.gridRow, []); rows.get(s.gridRow).push(s); });
    let first = true;
    return `<div class="sec"><div class="sec-h">${price}${esc(sec)}</div>${[...rows.entries()].map(([gr, ss]) => {
      const gap = first ? 0 : Math.max(0, gr - prevRow - 1); first = false; prevRow = gr;
      return `<div class="grow" style="margin-top:${gap * 26}px"><span class="rowlabel">${esc(ss[0].rowLabel)}</span><div class="gcells" style="grid-template-columns:repeat(${cols},26px)">${ss.map(s => preview
        ? `<span class="seat AVAILABLE" style="grid-column:${s.gridCol + 1}" title="${esc(s.label)}">${s.number}</span>`
        : `<button class="seat ${s.category} ${s.state}" style="grid-column:${s.gridCol + 1}" data-id="${s.seatId}" ${((opts && opts.manage) ? (s.state === 'AVAILABLE' || s.state === 'BLOCKED') : s.state === 'AVAILABLE') ? '' : 'disabled'} title="${esc(s.label)} ${money(s.price)}">${s.number}</button>`).join('')}</div></div>`;
    }).join('')}</div>`;
  }).join('');
}

/* ---------- customer: movie page ---------- */

/* ---------- customer: show times, like the big booking sites ---------- */
const TIME_BUCKETS = { Morning: [0, 12], Afternoon: [12, 16], Evening: [16, 19], Night: [19, 24] };
const PRICE_BUCKETS = [['₹0 - ₹100', 0, 100], ['₹101 - ₹200', 101, 200], ['₹201 - ₹400', 201, 400], ['₹401 - ₹500', 401, 500], ['Above ₹500', 501, 1e9]];
async function pgMovieShows(id) {
  const m = await api('/public/movies/' + id);
  let day = '', dates = [], data = [], city = localStorage.getItem('cityId');
  const F = { tq: '', lf: '', price: new Set(), fmt: new Set(), cancel: false, time: new Set(), sort: 'relevance' };
  view(`${topStrip(false)}<section class="mhero"><div class="mposter" style="${posterStyle(m)}">${posterStyle(m) ? '' : '✦'}</div><div><p class="eyebrow"><a href="#/search">← All movies</a></p><h1>${esc(m.title)} ${badge(m.status)}</h1>
    <div class="chips"><span class="chip static">⏱ ${Math.floor(m.durationMinutes / 60)}h ${m.durationMinutes % 60}m</span>${m.certification ? `<span class="chip sky">${esc(m.certification)}</span>` : ''}${splitCsv(m.genre).map(g => `<span class="chip mint">${esc(g)}</span>`).join('')}${splitCsv(m.language).map(g => `<span class="chip lilac">${esc(g)}</span>`).join('')}</div>
    <p class="about">${esc(m.description || '')}</p>${m.castInfo ? `<p class="muted">Cast: ${esc(m.castInfo)}</p>` : ''}
    <div class="actions"><a class="btn" href="#/movie/${m.id}/shows" onclick="event.preventDefault();document.getElementById('theatres').scrollIntoView({behavior:'smooth'})">Book tickets</a>${m.trailerUrl && /^https?:\/\//.test(m.trailerUrl) ? `<a class="btn sec" href="${esc(m.trailerUrl)}" target="_blank" rel="noopener noreferrer">▶ Trailer</a>` : ''}<button type="button" class="heart inline ${isSL('movie', m.id) ? 'on' : ''}" data-h="${m.id}" data-k="movie" title="Shortlist" aria-label="Shortlist">♥</button></div></div></section>
    <h3 class="sec-title" id="theatres">Theatres showing ${esc(m.title)}</h3><p class="muted" id="locline">Pick a date, then a show time.</p>
    <div class="card showbar"><p class="muted" id="dsr"></p><div class="datestrip" id="ds"></div>
    <div class="filterbar" id="fb"></div></div>
    <div class="legend"><span><i style="background:var(--ok)"></i>Available</span><span><i style="background:#e8a900"></i>Fast filling</span><span>☾ Late night</span><span>☁ Early morning</span></div><div id="sl"></div>`);
  const dd = (id, label, body) => `<div class="dd" data-dd="${id}"><button type="button" class="ddb">${label} ▾</button><div class="ddp" hidden>${body}</div></div>`;
  const chk = (g, v, label) => `<label class="ddi"><input type="checkbox" data-g="${g}" data-v="${esc(v)}" ${F[g].has(v) ? 'checked' : ''}> ${label}</label>`;
  const times = t => { const h = new Date(t).getHours(); return h; };
  const drawBar = () => {
    const lfs = [...new Set(data.flatMap(t => t.shows.map(s => `${s.audioLanguage || ''} - ${s.dimension || '2D'}`)))], fmts = [...new Set(data.flatMap(t => t.shows.flatMap(s => s.formats)))];
    $('#fb').innerHTML = `<input id="tq" class="tsearch" placeholder="Search theatre or area…" value="${esc(F.tq)}"><select id="lf"><option value="">All languages / formats</option>${lfs.map(x => `<option ${F.lf === x ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select>
      ${dd('price', 'Price Range', PRICE_BUCKETS.map(([l]) => chk('price', l, l)).join(''))}${dd('fmt', 'Special Formats', fmts.length ? fmts.map(f => chk('fmt', f, esc(f))).join('') : '<span class="muted">None listed</span>')}
      ${dd('other', 'Other Filters', `<label class="ddi"><input type="checkbox" id="fcancel" ${F.cancel ? 'checked' : ''}> Cancellable</label>`)}
      ${dd('time', 'Preferred Time', Object.entries(TIME_BUCKETS).map(([k, [a, b]]) => chk('time', k, `<b>${k}</b> <small class="muted">${pad2(a)}:00 - ${pad2(b - 1)}:59</small>`)).join(''))}
      ${dd('sort', 'Sort By', ['relevance|Relevance (earliest first)', 'popularity|Popularity (filling fastest)'].map(o => { const [v, l] = o.split('|'); return `<label class="ddi"><input type="radio" name="sort" data-sort="${v}" ${F.sort === v ? 'checked' : ''}> ${l}</label>`; }).join(''))}`;
    $('#lf').onchange = e => { F.lf = e.target.value; drawList(); };
    $('#tq').oninput = e => { F.tq = e.target.value; drawList(); };
    $('#fcancel').onchange = e => { F.cancel = e.target.checked; drawList(); };
    document.querySelectorAll('#fb input[data-g]').forEach(i => i.onchange = () => { i.checked ? F[i.dataset.g].add(i.dataset.v) : F[i.dataset.g].delete(i.dataset.v); drawList(); });
    document.querySelectorAll('#fb input[data-sort]').forEach(i => i.onchange = () => { F.sort = i.dataset.sort; drawList(); });
    document.querySelectorAll('#fb .ddb').forEach(b => b.onclick = e => { e.stopPropagation(); const p = b.nextElementSibling, open = !p.hidden; document.querySelectorAll('#fb .ddp').forEach(x => x.hidden = true); p.hidden = open; });
  };
  document.addEventListener('click', e => { if (!e.target.closest('.dd')) document.querySelectorAll('#fb .ddp').forEach(x => x.hidden = true); });
  const passes = (s, t) => {
    if (F.lf && `${s.audioLanguage || ''} - ${s.dimension || '2D'}` !== F.lf) return false;
    if (F.fmt.size && !s.formats.some(f => F.fmt.has(f))) return false;
    if (F.price.size && ![...F.price].some(l => { const b = PRICE_BUCKETS.find(x => x[0] === l); return Number(s.minPrice) >= b[1] && Number(s.minPrice) <= b[2]; })) return false;
    if (F.time.size) { const h = times(s.startTime); if (![...F.time].some(k => h >= TIME_BUCKETS[k][0] && h < TIME_BUCKETS[k][1])) return false; }
    return true;
  };
  const drawList = () => {
    const fill = s => s.total ? (s.total - s.available) / s.total : 0;
    let list = data.filter(t => (!F.cancel || t.cancellable) && (!F.tq || (t.theatre + ' ' + (t.address || '') + ' ' + (t.city || '')).toLowerCase().includes(F.tq.toLowerCase()))).map(t => ({ ...t, shows: t.shows.filter(s => passes(s, t)).sort((a, b) => F.sort === 'popularity' ? fill(b) - fill(a) : new Date(a.startTime) - new Date(b.startTime)) })).filter(t => t.shows.length);
    if (F.sort === 'popularity') list.sort((a, b) => Math.max(...b.shows.map(fill)) - Math.max(...a.shows.map(fill)));
    list.sort((a, b) => (ORD[a._scope] || 0) - (ORD[b._scope] || 0));
    $('#sl').innerHTML = list.length ? list.map((t, i) => scopeHead(t, list[i - 1]) + `<div class="card theatre-card"><div class="tcard-h"><div class="tname"><span class="tlogo">${esc((t.theatre || 'T')[0])}</span><div><b>${esc(t.theatre)}</b><br><small class="muted">${esc(t.city)}${t.address ? ' · ' + esc(t.address) : ''}${t._scope && t._scope !== 'area' ? ' · ' + esc(t._from) : ''}</small></div></div><div><span class="chip ${t.cancellable ? 'mint' : 'static'}">${t.cancellable ? '✓ Cancellable' : 'Non-cancellable'}</span> <button type="button" class="heart inline ${isSL('theatre', t.theatreId) ? 'on' : ''}" data-h="${t.theatreId}" data-k="theatre" data-n="${esc(t.theatre)}" data-s="${esc(t.city)}" title="Shortlist theatre" aria-label="Shortlist theatre">♥</button></div></div>
      ${t.facilities.length ? `<div class="chips">${t.facilities.map(f => `<span class="chip static">${esc(f)}</span>`).join('')}</div>` : ''}
      <div class="timegrid">${t.shows.map(s => { const h = new Date(s.startTime).getHours(), mark = h >= 23 || h < 3 ? '<i class="tmark">☾</i>' : h < 8 ? '<i class="tmark">☁</i>' : '';
        return `<button type="button" class="tbtn ${s.availability}" ${s.availability === 'SOLD_OUT' ? 'disabled' : ''} onclick="location.hash='#/show/${s.id}'" title="${s.available} seats left · from ${money(s.minPrice)}">${mark}<b>${new Date(s.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</b><small>${esc([s.audioLanguage, ...s.formats].filter(Boolean).join(' · ') || (s.dimension || ''))}</small></button>`; }).join('')}</div></div>`).join('')
      : emptyBox(data.length ? 'No shows match your filters. Clear a filter above.' : 'No theatre has a show for this movie on this date in the selected city. Try another date, or change the location above.');
  };
  const dshort = iso => new Date(iso + 'T00:00').toLocaleDateString('en', { day: 'numeric', month: 'short' });
  const drawStrip = () => {
    $('#dsr').textContent = dates.length ? `Booking open: ${dshort(dates[0])}${dates.length > 1 ? ' – ' + dshort(dates[dates.length - 1]) : ''}` : '';
    $('#ds').innerHTML = dates.map(iso => { const d = new Date(iso + 'T00:00'); return `<button type="button" data-d="${iso}" class="${iso === day ? 'on' : ''}"><small>${d.toLocaleDateString('en', { weekday: 'short' }).toUpperCase()}</small><b>${d.getDate()}</b><small>${d.toLocaleDateString('en', { month: 'short' }).toUpperCase()}</small></button>`; }).join('');
    document.querySelectorAll('#ds button').forEach(b => b.onclick = () => { day = b.dataset.d; document.querySelectorAll('#ds button').forEach(x => x.classList.toggle('on', x === b)); load(false); });
  };
  /* The dates come from the theatres: each one opens 4-7 days from today (its own setting) and stops at the movie's end date, so the window slides forward every day. */
  const loadDates = async () => { const L = getLoc(), loc = L.stateId || L.districtId || L.cityId; dates = await api(`/public/movies/${id}/booking-dates` + (loc ? '?locationId=' + encodeURIComponent(loc) : '')).catch(() => []); if (!dates.includes(day)) day = dates[0] || ''; drawStrip(); };
  const load = (refetchDates = true) => run(async () => {
    if (refetchDates) await loadDates();
    if (!day) { $('#sl').innerHTML = emptyBox('No booking dates are open for this movie right now. Check back soon.'); $('#locline').textContent = ''; return; }
    if (!city) { $('#sl').innerHTML = '<div class="empty">Choose your city to see theatres and show times.<br><button class="btn" id="pickcity" type="button" style="margin-top:12px">Select area</button></div>'; const pc = $('#pickcity'); if (pc) pc.onclick = () => openCityModal(() => { city = localStorage.getItem('cityId'); load(); }); return; }
    data = await listingNear(id, day); drawBar(); drawList(); const L = getLoc(), sc = data[0] && data[0]._scope; $('#locline').textContent = !data.length ? '' : sc === 'area' ? `${data.length} theatre${data.length > 1 ? 's' : ''} in ${L.cityName || 'your area'} have shows on this date.` : `No theatre in ${L.cityName || 'your area'} has shows on this date, so these are the nearest: ${String(SCOPE_TXT[sc]).toLowerCase()}.`;
  });
  wireStrip(() => { city = localStorage.getItem('cityId'); load(); });
  load();
}

/* ---------- theatre: seating designer ---------- */
function parseLayoutJs(rows) {
  const seats = [], used = new Set(); let gr = 0;
  for (const r of rows) {
    let label = (r.label || '').trim().toUpperCase(), pat = (r.pattern || '').trim(); const sec = (r.section || '').trim();
    if (!pat && label.includes('*')) { const i = label.indexOf('*'); pat = label.slice(i); label = label.slice(0, i).trim(); }   // A*5, Z*-5
    if (!label && !pat) { gr++; continue; }
    if (!/^[A-Z0-9]{1,3}$/.test(label)) return { error: `Row label "${r.label}" must be 1-3 letters or digits` };
    if (!sec) return { error: `Row ${label} needs a section name (used for pricing)` };
    if (!pat) return { error: `Row ${label} has no seats. Write e.g. 1-12 or *12` };
    let col = 0;
    for (const raw of pat.split(',')) {
      const t = raw.trim(); if (!t) continue;
      if (t.startsWith('_')) { const n = t.length > 1 ? Number(t.slice(1)) : 1; if (!(n >= 1 && n <= 30)) return { error: `Row ${label}: bad gap "${t}"` }; col += n; continue; }
      let nums = [];
      if (t.startsWith('*')) { const rev = t.startsWith('*-'), n = Number(t.slice(rev ? 2 : 1)); if (!(Number.isInteger(n) && n >= 1 && n <= 99)) return { error: `Row ${label}: "${t}" needs a count of 1-99` }; for (let k = 0; k < n; k++) nums.push(rev ? n - k : k + 1); }
      else { let a, b; if (t.includes('-')) { [a, b] = t.split('-', 2).map(Number); } else { a = b = Number(t); }
        if (!(Number.isInteger(a) && Number.isInteger(b) && a >= 1 && b >= 1 && a <= 99 && b <= 99)) return { error: `Row ${label}: cannot read "${t}"` };
        const st = a <= b ? 1 : -1; for (let n = a; n !== b + st; n += st) nums.push(n); }       // 18-10 counts downwards
      for (const n of nums) { const k = label + '#' + n; if (used.has(k)) return { error: `Seat ${label}${n} appears twice` }; used.add(k); seats.push({ rowLabel: label, number: n, label: label + n, state: 'AVAILABLE', category: 'REGULAR', section: sec, gridRow: gr, gridCol: col++, price: 0 }); }
    }
    gr++;
  }
  return seats.length ? { seats } : { error: 'Add at least one seat' };
}

async function openDesigner(screenId) {
  let d = { name: '', specialFormats: '', rows: [{ label: 'A', section: 'REGULAR', pattern: '1-12' }, { label: 'B', section: 'REGULAR', pattern: '1-12' }], locked: false, designed: true };
  if (screenId) { d = await api(`/theatre/screens/${screenId}/designer`); if (!d.rows.length) d.rows = [{ label: 'A', section: 'REGULAR', pattern: '1-12' }]; }
  const rows = d.rows.map(r => ({ label: r.label || '', section: r.section || '', pattern: r.pattern || '' }));
  const nextLabel = l => { l = (l || '').toUpperCase(); if (!l) return 'A'; const c = l.charCodeAt(l.length - 1); return c >= 65 && c < 90 ? l.slice(0, -1) + String.fromCharCode(c + 1) : l + '1'; };
  view(pageHead('THEATRE', screenId ? 'Edit screen' : 'Design a screen', 'Design the seating exactly as your hall is built. Each row has a letter, a pricing section, and the seat numbers. Use “_” for an aisle gap.')
    + `<div class="card">${d.locked ? '<div class="banner warn">This screen already has shows, so the seating plan is locked. You can still rename it or change its formats.</div>' : ''}${screenId && !d.designed && !d.locked ? '<div class="banner warn">This screen was made with the old simple layout. Design a new plan below and save to replace it.</div>' : ''}
    <div class="filter-grid"><div><label>Screen name</label><input id="dn" value="${esc(d.name)}" maxlength="60" placeholder="Screen 1"></div><div><label>Special formats of this screen</label><input id="df" value="${esc(d.specialFormats || '')}" maxlength="120" placeholder="Dolby Atmos, 4K, Laser"></div></div>
    <div ${d.locked ? 'hidden' : ''}><h3>Rows</h3><p class="muted small-note">Examples: <code>1-18</code> · <code>*12</code> (12 seats) · <code>*-12</code> or <code>18-1</code> (reverse numbering) · <code>1-4,_,5-17,_,18-21</code> (aisles) · <code>1,2,3,7,8</code>. You can also type <code>A*5</code> or <code>Z*-5</code> in the Row box. A completely empty line is a blank space between blocks.</p>
    <div class="quick"><b>Quick fill:</b> rows from <input id="qf" value="A" size="2" maxlength="2"> × <input id="qn" type="number" min="1" max="40" value="5"> rows, seat pattern <input id="qp" value="1-12" size="16" placeholder="e.g. 1-5,_,6-12" title="Seat numbers; _ = gap"> in section <input id="qsec" value="REGULAR" size="12"> <button class="btn sec small" id="qgo" type="button">Add rows</button></div>
    <div class="tablewrap"><table id="rt"></table></div><button class="btn sec small" id="addrow" type="button">＋ Add row</button> <button class="btn sec small" id="addgap" type="button">＋ Blank line</button> <button class="btn sec small" id="revrows" type="button">⇅ Reverse row order</button> <button class="btn sec small" id="revnums" type="button">⇄ Reverse seat numbers</button></div>
    <div id="perr" class="err"></div></div>
    <div class="card"><h3>Preview <small class="muted" id="pcount"></small></h3><div class="screen-bar"></div><div class="muted" style="text-align:center">SCREEN</div><div class="seatmap2" id="pv"></div></div>
    <div class="actions"><button class="btn" id="dsave">Save screen</button> <button class="btn sec" onclick="pgTScreens()">Cancel</button></div>`);
  const preview = () => {
    const r = parseLayoutJs(rows);
    $('#perr').textContent = r.error || ''; $('#pv').innerHTML = r.seats ? seatGridHtml(r.seats, { preview: true }) : ''; $('#pcount').textContent = r.seats ? `· ${r.seats.length} seats` : '';
    return r;
  };
  const drawRows = () => {
    $('#rt').innerHTML = '<tr><th>Row</th><th>Section (pricing group)</th><th>Seat pattern</th><th></th></tr>' + rows.map((r, i) => `<tr><td><input data-i="${i}" data-f="label" value="${esc(r.label)}" size="6" maxlength="8"></td><td><input data-i="${i}" data-f="section" value="${esc(r.section)}" maxlength="40"></td><td><input data-i="${i}" data-f="pattern" value="${esc(r.pattern)}" maxlength="300" style="min-width:260px"></td><td><button class="icon-btn" data-del="${i}" type="button">✕</button></td></tr>`).join('');
    document.querySelectorAll('#rt input').forEach(inp => inp.oninput = () => { rows[Number(inp.dataset.i)][inp.dataset.f] = inp.value; preview(); });
    document.querySelectorAll('#rt [data-del]').forEach(b => b.onclick = () => { rows.splice(Number(b.dataset.del), 1); drawRows(); preview(); });
  };
  if (!d.locked) {
    $('#addrow').onclick = () => { const last = rows[rows.length - 1] || {}; rows.push({ label: nextLabel(last.label), section: last.section || 'REGULAR', pattern: last.pattern || '1-12' }); drawRows(); preview(); };
    $('#revrows').onclick = () => { rows.reverse(); drawRows(); preview(); };
    $('#revnums').onclick = () => { rows.forEach(r => { if (r.pattern) r.pattern = r.pattern.split(',').map(t => { t = t.trim(); const m = t.match(/^(\d+)-(\d+)$/); return m ? `${m[2]}-${m[1]}` : t.startsWith('*-') ? '*' + t.slice(2) : t.startsWith('*') ? '*-' + t.slice(1) : t; }).join(','); }); drawRows(); preview(); };
    $('#addgap').onclick = () => { rows.push({ label: '', section: '', pattern: '' }); drawRows(); preview(); };
    $('#qgo').onclick = () => { let l = val('qf').toUpperCase() || 'A'; const n = Number(val('qn')), pat = val('qp') || '1-12', sec = val('qsec') || 'REGULAR';
      if (!/^[0-9_,\-\s]+$/.test(pat)) return toast('Seat pattern can only use numbers, "-", "," and "_" (gap), e.g. 1-5,_,6-12', 'err');
      for (let i = 0; i < n; i++) { rows.push({ label: l, section: sec, pattern: pat }); l = nextLabel(l); } drawRows(); preview(); };
    drawRows();
  }
  preview();
  $('#dsave').onclick = () => run(async () => {
    const body = { name: val('dn'), specialFormats: val('df'), rows };
    if (screenId) await api(`/theatre/screens/${screenId}/designer`, { method: 'PUT', body }); else await api('/theatre/screens/designer', { method: 'POST', body });
    toast('Screen saved'); pgTScreens();
  });
}

/* ---------- theatre: screens + specifications ---------- */
const FACILITIES = ['Parking', 'Food court', 'Wheelchair access', 'M-Ticket', 'Recliner seats', 'Dolby Atmos', '4K', 'Laser projection', 'IMAX', 'AC'];
async function pgTScreens() {
  const [list, specs] = await Promise.all([api('/theatre/screens'), api('/theatre/specs')]);
  const have = new Set(String(specs.facilities || '').split(',').map(x => x.trim()).filter(Boolean));
  view(pageHead('OPERATIONS', 'Screens &amp; specifications', 'Design each hall’s seating, and tell customers what your theatre offers so they can choose.', '<button class="btn" id="newscreen">＋ Design a new screen</button>')
    + `<div class="card"><h3>Your screens</h3>${list.length ? `<div class="tablewrap"><table><tr><th>Screen</th><th>Seats</th><th>Commission</th><th></th></tr>${list.map(s => `<tr><td>${esc(s.name)}</td><td>${s.totalSeats}</td><td>${s.effectiveCommission}%</td><td><button class="btn sec small" data-edit="${s.id}">Edit / design seating</button></td></tr>`).join('')}</table></div>` : emptyBox('No screens yet. Click “Design a new screen”.')}</div>
    <div class="card"><h3>Theatre specifications (shown to customers)</h3><div class="chips">${FACILITIES.map(f => `<label class="chip"><input type="checkbox" data-fac="${esc(f)}" ${have.has(f) ? 'checked' : ''}> ${esc(f)}</label>`).join('')}</div>
      <label>Other facilities (comma-separated)</label><input id="fx" value="${esc([...have].filter(x => !FACILITIES.includes(x)).join(', '))}" maxlength="150">
      <label class="check"><input type="checkbox" id="fcan" ${specs.cancellationAvailable ? 'checked' : ''}> Customers can cancel tickets (shown as “Cancellation available”; untick for non-cancellable)</label><button class="btn" id="fsave">Save specifications</button></div>`);
  $('#newscreen').onclick = () => run(() => openDesigner(null));
  document.querySelectorAll('[data-edit]').forEach(b => b.onclick = () => run(() => openDesigner(Number(b.dataset.edit))));
  $('#fsave').onclick = () => run(async () => {
    const f = [...document.querySelectorAll('[data-fac]:checked')].map(x => x.dataset.fac).concat(val('fx').split(',').map(x => x.trim()).filter(Boolean));
    await api('/theatre/specs', { method: 'PUT', body: { facilities: [...new Set(f)].join(', '), cancellationAvailable: $('#fcan').checked } }); toast('Specifications saved');
  });
}

/* ---------- theatre: shows (create many, edit, cancel) ---------- */
const SPECIAL_FORMATS = ['Dolby Atmos', '4K', 'Laser', 'Dolby', 'IMAX', 'EPIQ', 'GOLD', 'P[XL]'];
async function sectionsOf(screenId) {
  try { const d = await api(`/theatre/screens/${screenId}/designer`); if (d.designed) { const r = parseLayoutJs(d.rows); if (r.seats) return [...new Set(r.seats.map(x => x.section))]; } } catch (e) { /* fall back */ }
  return ['REGULAR', 'PREMIUM'];
}
let SHOWS_TAB = 'create';
async function pgTShows() {
  const [shows, screens, runs, specs] = await Promise.all([api('/theatre/shows'), api('/theatre/screens'), api('/theatre/listings'), api('/theatre/specs')]);
  const today = isoD(new Date()), tomorrow = isoD(new Date(Date.now() + 864e5)), nowD = () => new Date();
  let windowDays = specs.bookingWindowDays || 7;
  const upcomingCount = () => shows.filter(s => s.status === 'SCHEDULED' && new Date(s.startTime) > nowD()).length;
  const dshort = d => d.toLocaleDateString('en', { day: 'numeric', month: 'short' });
  const windowText = () => { const e = new Date(); e.setHours(0, 0, 0, 0); e.setDate(e.getDate() + windowDays - 1); return `Customers can book <b>${dshort(new Date())} – ${dshort(e)}</b> today. The window moves forward one day every day, and never goes past a movie’s end date.`; };
  view(pageHead('OPERATIONS', 'Shows', 'Create show times for many dates at once, or edit the shows you already have. A movie must be added to your theatre first (Movies page).')
    + (!runs.length ? '<div class="banner warn">You have no movies on your screens yet. Go to <a href="#/t/movies">Movies</a> and add one with a start and end date.</div>' : '')
    + `<div class="card"><div class="page-heading"><div><h3>Customer booking window</h3><p class="muted" id="bw-txt">${windowText()}</p></div><div class="chips" id="bw">${[4, 5, 6, 7].map(n => `<button type="button" class="chip ${n === windowDays ? 'on' : ''}" data-n="${n}">${n} days</button>`).join('')}</div></div></div>`
    + tabsHtml('stabs', [['create', 'Create shows'], ['edit', 'Edit existing shows', upcomingCount()]], SHOWS_TAB) + '<div id="sbody"></div>');
  document.querySelectorAll('#bw [data-n]').forEach(b => b.onclick = () => run(async () => {
    const r = await api('/theatre/booking-window', { method: 'PUT', body: { days: Number(b.dataset.n) } }); windowDays = r.bookingWindowDays;
    document.querySelectorAll('#bw [data-n]').forEach(x => x.classList.toggle('on', Number(x.dataset.n) === windowDays)); $('#bw-txt').innerHTML = windowText(); toast('Booking window set to ' + windowDays + ' days'); }));
  const reload = async () => { shows.length = 0; (await api('/theatre/shows')).forEach(s => shows.push(s)); const c = document.querySelector('#stabs [data-k="edit"] i'); if (c) c.textContent = upcomingCount(); };

  /* ---- tab 1: create ---- */
  const drawCreate = async (doneMsg = '') => {
    const more = (await api('/public/movies')).filter(m => !runs.some(r => r.movieId === m.id) && ['ACTIVE', 'UPCOMING'].includes(m.status));
    let times = ['10:00', '14:00', '18:00', '21:30'];
    $('#sbody').innerHTML = `<div class="card"><h3>Create shows</h3><div class="filter-grid"><div><label>Movie</label><select id="sm">${runs.map(r => `<option value="${r.movieId}" data-dur="${r.durationMinutes}" data-lang="${esc(r.language)}" data-from="${r.startDate}" data-to="${r.endDate}">${esc(r.title)} (${r.startDate} → ${r.endDate})</option>`).join('')}${more.length ? `<optgroup label="Other movies — added to your theatre automatically">${more.map(m => `<option value="${m.id}" data-new="1" data-dur="${m.durationMinutes}" data-lang="${esc(m.language)}" data-from="${m.releaseDate && m.releaseDate > today ? m.releaseDate : today}" data-to="">${esc(m.title)} (${esc(m.language)})</option>`).join('')}</optgroup>` : ''}</select></div>
      <div><label>Screen</label><select id="ss">${screens.map(s => `<option value="${s.id}">${esc(s.name)}</option>`).join('')}</select></div>
      <div><label>From date</label><input id="sf" type="date" min="${today}" value="${tomorrow}"></div><div><label>To date</label><input id="st" type="date" min="${today}" value="${tomorrow}"></div>
      <div><label>Audio language</label><select id="sl2"></select></div><div><label>Format</label><select id="sd"><option>2D</option><option>3D</option></select></div></div>
      <label>Show times (every selected date)</label><div class="chips" id="tchips"></div><div class="row"><input id="tnew" type="time" style="max-width:150px"><button class="btn sec small" id="tadd" type="button">Add time</button></div>
      <label>Special formats</label><div class="chips">${SPECIAL_FORMATS.map(f => `<label class="chip"><input type="checkbox" data-sf="${esc(f)}"> ${esc(f)}</label>`).join('')}</div>
      <h4>Ticket price per section</h4><div class="filter-grid" id="prices"></div><button class="btn" id="sgo">Create shows</button><div id="sres"></div></div>`;
    const endOf = t => { const dur = Number(($('#sm') && $('#sm').selectedOptions[0] || { dataset: {} }).dataset.dur || 0); if (!dur) return ''; const [h, m] = t.split(':').map(Number), e = h * 60 + m + dur; return ' → ends ' + pad2(Math.floor(e / 60) % 24) + ':' + pad2(e % 60); };
    const drawChips = () => { $('#tchips').innerHTML = times.sort().map(t => `<span class="chip">${t}<small class="muted">${endOf(t)}</small> <button class="icon-btn" data-rm="${t}" type="button">✕</button></span>`).join('') || '<span class="muted">Add at least one time</span>'; document.querySelectorAll('[data-rm]').forEach(b => b.onclick = () => { times = times.filter(x => x !== b.dataset.rm); drawChips(); }); };
    $('#tadd').onclick = () => { const v = val('tnew'); if (v && !times.includes(v)) { times.push(v); drawChips(); } };
    drawChips();
    const onMovie = () => { const o = $('#sm').selectedOptions[0]; if (!o) return; $('#sl2').innerHTML = o.dataset.lang.split(',').map(l => `<option>${esc(l.trim())}</option>`).join(''); $('#sf').value = o.dataset.from > today ? o.dataset.from : tomorrow; $('#st').value = $('#sf').value; $('#sf').min = o.dataset.from > today ? o.dataset.from : today; $('#sf').max = o.dataset.to; $('#st').max = o.dataset.to; drawChips(); };
    const onScreen = async () => { const secs = await sectionsOf(val('ss')); $('#prices').innerHTML = secs.map(s => `<div><label>${esc(s)} (₹)</label><input data-sec="${esc(s)}" type="number" min="1" step="0.01" placeholder="e.g. 150"></div>`).join(''); };
    if ($('#sm').options.length) { $('#sm').onchange = onMovie; onMovie(); } else $('#sres').innerHTML = '<div class="banner">No movies are available yet.</div>'; if (doneMsg) $('#sres').innerHTML = doneMsg; if (screens.length) { $('#ss').onchange = onScreen; await onScreen(); }
    $('#sgo').onclick = () => run(async () => {
      if (!times.length) throw new Error('Add at least one show time');
      const sp = {}; document.querySelectorAll('[data-sec]').forEach(i => { if (i.value) sp[i.dataset.sec] = Number(i.value); });
      const secs = [...document.querySelectorAll('[data-sec]')]; if (secs.some(i => !i.value)) throw new Error('Enter a ticket price for every section');
      const picked = $('#sm').selectedOptions[0];
      if (picked && picked.dataset.new) await api('/theatre/listings', { method: 'POST', body: { movieId: num('sm'), startDate: val('sf'), endDate: val('st') } });
      const r = await api('/theatre/shows/bulk', { method: 'POST', body: { movieId: num('sm'), screenId: num('ss'), fromDate: val('sf'), toDate: val('st'), times, sectionPrices: sp, audioLanguage: val('sl2'), dimension: val('sd'), specialFormats: [...document.querySelectorAll('[data-sf]:checked')].map(x => x.dataset.sf).join(', ') } });
      const msg = `<div class="banner ok">Created <b>${r.created}</b> show(s).${r.skipped.length ? ` Skipped ${r.skipped.length}:<ul>${r.skipped.slice(0, 12).map(x => `<li>${esc(x)}</li>`).join('')}</ul>` : ''}</div>`;
      if (picked && picked.dataset.new) { runs.length = 0; (await api('/theatre/listings')).forEach(x => runs.push(x)); await reload(); await drawCreate(msg); return; }
      $('#sres').innerHTML = msg;
      await reload();
    });
  };

  /* ---- tab 2: edit ---- */
  const drawEdit = () => {
    let fday = '', fmovie = '', fscreen = '';
    $('#sbody').innerHTML = `<div class="card"><div class="page-heading"><div><h3>Movies running at your theatre</h3><p class="muted">Extend a movie’s end date to keep it on your screens longer, then add show times for the new days under <b>Create shows</b>.</p></div></div><div id="runs"></div></div>
    <div class="card"><div class="page-heading"><div><h3>Daily schedule</h3><p class="muted">Every screen on one timeline. Click an upcoming show to edit it.</p></div><div class="head-actions"><button class="btn sec small" id="tl-prev" type="button">←</button><input type="date" id="tl-day" value="${((shows.filter(s => s.status === 'SCHEDULED' && s.startTime.slice(0, 10) >= today).sort((a, b) => a.startTime.localeCompare(b.startTime))[0] || {}).startTime || today).slice(0, 10)}"><button class="btn sec small" id="tl-next" type="button">→</button></div></div><div id="timeline"></div></div>
    <div class="card"><div class="page-heading"><h3>All shows</h3><div class="head-actions"><input type="date" id="fd" title="Filter by date"><select id="fm"><option value="">All movies</option>${[...new Set(shows.map(s => s.movieTitle))].sort().map(t => `<option value="${esc(t)}">${esc(t)}</option>`).join('')}</select><select id="fs"><option value="">All screens</option>${screens.map(s => `<option value="${esc(s.name)}">${esc(s.name)}</option>`).join('')}</select></div></div><div id="slist"></div></div>`;
    const started = s => new Date(s.startTime) <= nowD();
    const openEdit = id => { const s = shows.find(x => x.id === Number(id)); if (!s) return; if (s.status !== 'SCHEDULED' || started(s)) return toast('This show has already started or finished, so it can’t be edited.', 'err'); run(() => editShow(s, async () => { await reload(); drawEdit(); })); };
    const drawRuns = () => { $('#runs').innerHTML = runs.length ? runs.map(r => `<div class="mrow"><div class="mrow-info"><b>${esc(r.title)}</b> ${badge(r.status)}<div class="muted">${esc(r.language)} · ${r.startDate} → <b>${r.endDate}</b> · ${r.upcomingShows} upcoming show(s)</div></div><div class="actions"><button class="btn sec small" data-ext="${r.id}" type="button">Extend end date</button></div></div>`).join('') : emptyBox('No movies on your screens. Add one from the Movies page.');
      document.querySelectorAll('[data-ext]').forEach(b => b.onclick = () => { const r = runs.find(y => y.id === Number(b.dataset.ext));
        const m = modal(`<h3>Extend “${esc(r.title)}”</h3><p class="muted">Currently ends on <b>${r.endDate}</b>. Pick a later date. (To end it sooner, use Movies → Change end date.)</p><label>New end date</label><input type="date" id="ne" min="${r.endDate}" value="${r.endDate}"><div class="actions"><button class="btn" id="ngo" type="button">Extend</button><button class="btn sec" id="nno" type="button">Close</button></div>`);
        m.querySelector('#nno').onclick = () => m.remove();
        m.querySelector('#ngo').onclick = () => run(async () => { const d = m.querySelector('#ne').value; if (!d || d <= r.endDate) throw new Error('Choose a date after ' + r.endDate); await api('/theatre/listings/' + r.id, { method: 'PUT', body: { endDate: d } }); m.remove(); toast(`“${r.title}” now runs until ${d}. Add show times for the new days under Create shows.`); runs.length = 0; (await api('/theatre/listings')).forEach(x => runs.push(x)); drawRuns(); }); }); };
    const drawList = () => {
      const l = shows.filter(s => (!fday || s.startTime.slice(0, 10) === fday) && (!fmovie || s.movieTitle === fmovie) && (!fscreen || s.screenName === fscreen)).sort((a, b) => new Date(a.startTime) - new Date(b.startTime));
      const byDay = {}; l.forEach(s => (byDay[s.startTime.slice(0, 10)] = byDay[s.startTime.slice(0, 10)] || []).push(s));
      $('#slist').innerHTML = Object.keys(byDay).length ? Object.entries(byDay).map(([d, ss]) => `<h4 class="sec-title">${new Date(d).toLocaleDateString('en', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</h4><div class="tablewrap"><table><tr><th>Time</th><th>Movie</th><th>Screen</th><th>Language · format</th><th>Free</th><th>Status</th><th></th></tr>${ss.map(s => `<tr><td><b>${new Date(s.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</b></td><td>${esc(s.movieTitle)}</td><td>${esc(s.screenName)}</td><td>${esc([s.audioLanguage, s.dimension, s.specialFormats].filter(Boolean).join(' · '))}</td><td>${s.availableSeats}</td><td>${badge(s.status === 'SCHEDULED' && started(s) ? 'COMPLETED' : s.status)}</td><td>${s.status === 'SCHEDULED' && !started(s) ? `<button class="btn sec small" data-es="${s.id}">Edit</button> <button class="btn danger small" onclick="cancelShow(${s.id})">Cancel</button>` : ''}</td></tr>`).join('')}</table></div>`).join('') : emptyBox('No shows match.');
      document.querySelectorAll('#slist [data-es]').forEach(b => b.onclick = () => openEdit(b.dataset.es));
    };
    const drawTimeline = () => {
      const day = val('tl-day'), mins = d => d.getHours() * 60 + d.getMinutes(), pct = m => (m / 1440 * 100).toFixed(2);
      const rows = screens.map(sc => { const ss = shows.filter(s => s.screenName === sc.name && s.status !== 'CANCELLED' && s.startTime.slice(0, 10) === day).sort((a, b) => new Date(a.startTime) - new Date(b.startTime));
        return `<div class="tl-row"><div class="tl-name">${esc(sc.name)}<small class="muted">${ss.length} show${ss.length === 1 ? '' : 's'}</small></div><div class="tl-track">${ss.map(s => { const a = mins(new Date(s.startTime)), e = s.endTime ? Math.min(1440, mins(new Date(s.endTime)) || 1440) : a + 120;
          return `<button type="button" class="tl-block" data-es="${s.id}" style="left:${pct(a)}%;width:${pct(Math.max(30, e - a))}%" title="${esc(s.movieTitle)} · ${new Date(s.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}"><b>${new Date(s.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</b> ${esc(s.movieTitle)}</button>`; }).join('')}</div></div>`; }).join('');
      $('#timeline').innerHTML = `<div class="tl-axis"><div class="tl-name"></div><div class="tl-track tl-ticks">${[0, 3, 6, 9, 12, 15, 18, 21].map(h => `<span style="left:${pct(h * 60)}%">${pad2(h)}:00</span>`).join('')}</div></div>${rows || emptyBox('No screens yet.')}`;
      document.querySelectorAll('#timeline [data-es]').forEach(b => b.onclick = () => openEdit(b.dataset.es));
    };
    $('#tl-day').onchange = drawTimeline; $('#tl-prev').onclick = () => { const d = new Date(val('tl-day')); d.setDate(d.getDate() - 1); $('#tl-day').value = isoD(d); drawTimeline(); }; $('#tl-next').onclick = () => { const d = new Date(val('tl-day')); d.setDate(d.getDate() + 1); $('#tl-day').value = isoD(d); drawTimeline(); };
    $('#fd').onchange = e => { fday = e.target.value; drawList(); }; $('#fm').onchange = e => { fmovie = e.target.value; drawList(); }; $('#fs').onchange = e => { fscreen = e.target.value; drawList(); };
    drawRuns(); drawTimeline(); drawList();
  };
  wireTabs('stabs', k => { SHOWS_TAB = k; run(k === 'create' ? drawCreate : async () => drawEdit()); });
  await (SHOWS_TAB === 'create' ? drawCreate() : drawEdit());
}
async function editShow(s, after) {
  const [screens, runs] = await Promise.all([api('/theatre/screens'), api('/theatre/listings')]);
  const cur = screens.find(x => x.name === s.screenName) || screens[0];
  const movies = []; runs.forEach(r => { if (!movies.some(m => m.movieId === r.movieId)) movies.push({ movieId: r.movieId, title: r.title, language: r.language }); });
  if (!movies.some(m => m.movieId === s.movieId)) movies.push({ movieId: s.movieId, title: s.movieTitle, language: s.audioLanguage || '' });
  const m = modal(`<h3>Edit show — ${esc(s.movieTitle)}</h3><p class="muted">You can change the movie, screen, time and prices until someone books. After that only the language and formats can change; to move a booked show, cancel it (customers are refunded) and create a new one.</p>
    <div class="filter-grid"><div><label>Movie</label><select id="es-m">${movies.map(x => `<option value="${x.movieId}" data-lang="${esc(x.language)}" ${x.movieId === s.movieId ? 'selected' : ''}>${esc(x.title)}</option>`).join('')}</select></div>
    <div><label>Screen</label><select id="es-s">${screens.map(x => `<option value="${x.id}" ${cur && x.id === cur.id ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select></div>
    <div><label>Start</label><input id="es-t" type="datetime-local" value="${s.startTime.slice(0, 16)}"></div>
    <div><label>Audio language</label><select id="es-l"></select></div>
    <div><label>Format</label><select id="es-d"><option ${s.dimension === '2D' ? 'selected' : ''}>2D</option><option ${s.dimension === '3D' ? 'selected' : ''}>3D</option></select></div></div>
    <label>Special formats (comma-separated)</label><input id="es-f" value="${esc(s.specialFormats || '')}">
    <h4>Ticket prices</h4><p class="muted" id="es-pn"></p><div class="filter-grid" id="es-p"></div>
    <div class="actions"><button class="btn" id="es-go">Save</button><button class="btn sec" id="es-seats" type="button">Seats: view / block</button><button class="btn sec" id="es-no">Close</button></div>`);
  const langs = () => { const o = m.querySelector('#es-m').selectedOptions[0], list = String(o.dataset.lang || '').split(',').map(x => x.trim()).filter(Boolean);
    const want = Number(o.value) === s.movieId ? s.audioLanguage : '', pick = list.includes(want) ? want : list[0] || want || '';
    m.querySelector('#es-l').innerHTML = (list.length ? list : [pick]).map(l => `<option ${l === pick ? 'selected' : ''}>${esc(l)}</option>`).join(''); };
  const prices = async () => { const sid = Number(m.querySelector('#es-s').value), changed = !cur || sid !== cur.id, secs = await sectionsOf(sid);
    m.querySelector('#es-pn').textContent = changed ? 'New screen: sections it shares with the old one keep their price. Enter a price for any section that is new.' : 'Leave all empty to keep the current prices, or fill every section to change them.';
    m.querySelector('#es-p').innerHTML = secs.map(x => `<div><label>${esc(x)} (₹)</label><input data-esec="${esc(x)}" type="number" min="1" step="0.01"></div>`).join(''); };
  m.querySelector('#es-m').onchange = langs; m.querySelector('#es-s').onchange = () => run(prices);
  langs(); await prices();
  m.querySelector('#es-no').onclick = () => m.remove();
  m.querySelector('#es-seats').onclick = () => { m.remove(); run(() => openSeatManager(s)); };
  m.querySelector('#es-go').onclick = () => run(async () => {
    const sid = Number(m.querySelector('#es-s').value), screenChanged = !cur || sid !== cur.id;
    const ins = [...m.querySelectorAll('[data-esec]')], filled = ins.filter(i => i.value);
    if (!screenChanged && filled.length && filled.length < ins.length) throw new Error('Fill every section price, or leave them all empty');
    const sp = {}; filled.forEach(i => sp[i.dataset.esec] = Number(i.value));
    await api('/theatre/shows/' + s.id, { method: 'PUT', body: { movieId: Number(m.querySelector('#es-m').value), screenId: sid, startTime: m.querySelector('#es-t').value, audioLanguage: m.querySelector('#es-l').value, dimension: m.querySelector('#es-d').value, specialFormats: m.querySelector('#es-f').value, sectionPrices: filled.length ? sp : null } });
    m.remove(); toast('Show updated'); if (after) await after(); else pgTShows();
  });
}

async function openSeatManager(s) {
  const map = await api('/public/shows/' + s.id + '/seats'), sel = new Set(), c = st => map.seats.filter(x => x.state === st).length;
  const m = modal(`<h3>Seats — ${esc(s.movieTitle)} · ${fmt(s.startTime)}</h3><p class="muted">Click seats to select them, then <b>Block</b> to keep them back from customers (they stay blocked until you unblock). Booked and customer-held seats cannot be changed.</p>
    <div class="legend"><span><i style="background:#cfe6d6;border:1px solid #7fb596"></i>Free (${c('AVAILABLE')})</span><span><i class="blk"></i>Blocked by you (${c('BLOCKED')})</span><span><i style="background:#F3E7B9;border:1px solid #E0C46C"></i>Held (${c('LOCKED')})</span><span><i style="background:#E9DDD2;border:1px solid #d4c2b4"></i>Booked (${c('BOOKED')})</span><span><i style="background:#9B6B66"></i>Selected</span></div>
    <div class="screen-bar"></div><div class="muted" style="text-align:center">SCREEN</div><div class="seatmap2" style="overflow:auto">${seatGridHtml(map.seats, { manage: true })}</div>
    <div id="sm-sum" class="muted">Nothing selected.</div><div class="actions"><button class="btn" id="sm-b">Block selected</button><button class="btn sec" id="sm-u">Unblock selected</button><button class="btn sec" id="sm-x">Close</button></div>`);
  m.querySelectorAll('.seat:not([disabled])').forEach(b => b.onclick = () => { const id = Number(b.dataset.id); sel.has(id) ? sel.delete(id) : sel.add(id); b.classList.toggle('sel', sel.has(id)); m.querySelector('#sm-sum').textContent = sel.size ? `${sel.size} selected: ${[...sel].map(i => map.seats.find(x => x.seatId === i).label).join(', ')}` : 'Nothing selected.'; });
  const go = block => run(async () => { if (!sel.size) throw new Error('Select at least one seat'); const r = await api(`/theatre/shows/${s.id}/seats/block`, { method: 'POST', body: { seatIds: [...sel], block } }); toast(`${r.changed} seat(s) ${block ? 'blocked' : 'unblocked'}`); m.remove(); await openSeatManager(s); });
  m.querySelector('#sm-b').onclick = () => go(true); m.querySelector('#sm-u').onclick = () => go(false); m.querySelector('#sm-x').onclick = () => m.remove();
}

/* ---------- theatre: movies on my screens (runs + history) ---------- */
async function pgTMovies() {
  const [runs, hist, catalogue, sh] = await Promise.all([api('/theatre/listings'), api('/theatre/listings?history=true'), api('/public/movies'), api('/theatre/screen-history')]);
  let tab = 'run', q = '';
  const today = isoD(new Date()), plus30 = isoD(new Date(Date.now() + 30 * 864e5));
  view(pageHead('OPERATIONS', 'Movies on my screens', 'Add any catalogue movie to your theatre with a start and end date — no approval needed. Remove it any time; its history is kept.')
    + tabsHtml('tmt', [['run', 'Now &amp; upcoming', runs.length], ['add', '＋ Add a movie'], ['hist', 'History', sh.length], ['new', 'Create new movie']], tab) + '<div id="tmb"></div>');
  const poster = m => m.posterUrl && /^https?:\/\//.test(m.posterUrl) ? `style="background-image:url('${esc(m.posterUrl)}')"` : '';
  const draw = () => {
    const b = $('#tmb');
    if (tab === 'run') {
      b.innerHTML = runs.length ? runs.map(r => `<div class="mrow"><div class="mthumb" ${poster(r)}></div><div class="mrow-info"><b>${esc(r.title)}</b> ${badge(r.status)}<div class="muted">${esc(r.language)} · ${r.startDate} → ${r.endDate}</div><div class="muted">${r.upcomingShows} upcoming show(s)</div></div>
        <div class="actions"><a class="btn sec small" href="#/t/shows">Add show times</a><button class="btn sec small" data-edit-movie="${r.movieId}">Edit details</button><button class="btn sec small" data-end="${r.id}">Change end date</button><button class="btn danger small" data-rm="${r.id}">Remove</button></div></div>`).join('') : emptyBox('No movies on your screens. Use “Add a movie”.');
      document.querySelectorAll('[data-end]').forEach(x => x.onclick = () => { const r = runs.find(y => y.id === Number(x.dataset.end)); const m = modal(`<h3>${esc(r.title)}</h3><label>New end date (leave empty to keep ${r.endDate})</label><input type="date" id="ne" min="${r.startDate}"><div class="actions"><button class="btn" id="ngo">Save</button><button class="btn sec" id="nno">Close</button></div>`);
        m.querySelector('#nno').onclick = () => m.remove(); m.querySelector('#ngo').onclick = () => run(async () => { await api('/theatre/listings/' + r.id, { method: 'PUT', body: { endDate: m.querySelector('#ne').value || null } }); m.remove(); toast('Updated'); pgTMovies(); }); });
      document.querySelectorAll('[data-rm]').forEach(x => x.onclick = () => { const r = runs.find(y => y.id === Number(x.dataset.rm)); const m = modal(`<h3>Remove “${esc(r.title)}”</h3><p class="muted">${r.upcomingShows ? `Its <b>${r.upcomingShows}</b> upcoming show(s) will be cancelled and customers refunded.` : 'It has no upcoming shows.'} The removal is kept in your history.</p><label>Reason</label><input id="rr" maxlength="280"><div class="actions"><button class="btn danger" id="rgo">Remove movie</button><button class="btn sec" id="rno">Keep</button></div>`);
        m.querySelector('#rno').onclick = () => m.remove(); m.querySelector('#rgo').onclick = () => run(async () => { await api(`/theatre/listings/${r.id}/remove`, { method: 'POST', body: { reason: m.querySelector('#rr').value } }); m.remove(); toast('Movie removed'); pgTMovies(); }); });
    } else if (tab === 'add') {
      b.innerHTML = `<div class="card"><div class="filter-grid"><div><label>Find a movie</label><input id="mq" placeholder="Type to search the catalogue…"></div><div><label>Start date (required)</label><input id="ls" type="date" min="${today}" value="${today}"></div><div><label>End date (required)</label><input id="le" type="date" min="${today}" value="${plus30}"></div></div><div id="mlist"></div></div>`;
      const r = () => { const l = catalogue.filter(m => !q || [m.title, m.language, m.genre].some(x => String(x || '').toLowerCase().includes(q))).slice(0, 30);
        $('#mlist').innerHTML = l.length ? l.map(m => `<div class="mrow"><div class="mthumb" ${poster(m)}></div><div class="mrow-info"><b>${esc(m.title)}</b> ${badge(m.status)}<div class="muted">${esc(m.language)} · ${esc(m.genre)} · ${m.durationMinutes} min · Release ${esc(m.releaseDate || 'TBA')}</div></div><div class="actions"><button class="btn small" data-pick="${m.id}">Add to my theatre</button></div></div>`).join('') : emptyBox('No match. Try “Create new movie”.');
        document.querySelectorAll('[data-pick]').forEach(x => x.onclick = () => run(async () => { await api('/theatre/listings', { method: 'POST', body: { movieId: Number(x.dataset.pick), startDate: val('ls'), endDate: val('le') } }); toast('Movie added. Now create its show times.'); pgTMovies(); })); };
      $('#mq').oninput = e => { q = e.target.value.toLowerCase(); r(); }; r();
    } else if (tab === 'hist') {
      const uniq = k => [...new Set(sh.map(x => x[k]))].sort(), opt = (a, all) => `<option value="">${all}</option>` + a.map(x => `<option>${esc(x)}</option>`).join('');
      b.innerHTML = `<div class="card"><div class="page-heading"><div><h3>What played on each screen</h3><p class="muted">Every movie that has been (or is booked to be) screened on each of your screens, with its dates. Cancelled shows are not counted.</p></div><div class="head-actions"><button class="btn sec small" id="hx" type="button">Export CSV</button></div></div>
        <div class="filter-grid"><div><label>Screen</label><select id="hs" class="nocombo">${opt(uniq('screenName'), 'All screens')}</select></div><div><label>Movie</label><select id="hm" class="nocombo">${opt(uniq('title'), 'All movies')}</select></div>
        <div><label>Screened from</label><input type="date" id="hf"></div><div><label>Screened until</label><input type="date" id="ht"></div>
        <div><label>Status</label><select id="hst" class="nocombo"><option value="">Any</option><option value="COMPLETED">Completed</option><option value="RUNNING">Running now</option><option value="UPCOMING">Upcoming</option></select></div></div><p class="muted" id="hc"></p><div id="hl"></div></div>
        <details class="card"><summary>Add / remove log (${hist.length})</summary>${hist.length ? `<div class="tablewrap"><table><tr><th>Movie</th><th>Run</th><th>Added</th><th>Ended / removed</th><th>Reason</th></tr>${hist.map(h => `<tr><td><b>${esc(h.title)}</b></td><td>${h.startDate} → ${h.endDate}</td><td>${fmt(h.addedAt)}<br><small class="muted">${esc(h.addedBy || '')}</small></td><td>${h.removedAt ? fmt(h.removedAt) + '<br><small class="muted">' + esc(h.removedBy || '') + '</small>' : 'Ended on ' + h.endDate} ${badge(h.status)}</td><td>${esc(h.removeReason || '')}</td></tr>`).join('')}</table></div>` : emptyBox('No removed or finished movies yet.')}</details>`;
      const dfmt = d => new Date(d + 'T00:00').toLocaleDateString('en', { day: 'numeric', month: 'short', year: 'numeric' });
      let cur = [];
      const drawHist = () => {
        const f = val('hf'), t = val('ht');
        cur = sh.filter(x => (!val('hs') || x.screenName === val('hs')) && (!val('hm') || x.title === val('hm')) && (!val('hst') || x.status === val('hst')) && (!f || x.toDate >= f) && (!t || x.fromDate <= t));
        $('#hc').textContent = cur.length + ' screening run(s)';
        const by = {}; cur.forEach(x => (by[x.screenName] = by[x.screenName] || []).push(x));
        $('#hl').innerHTML = cur.length ? Object.keys(by).sort().map(sc => `<h4 class="sec-title">${esc(sc)}</h4><div class="tablewrap"><table><tr><th>Movie</th><th>Language</th><th>From</th><th>To</th><th>Shows</th><th>Status</th></tr>${by[sc].map(x => `<tr><td><b>${esc(x.title)}</b></td><td>${esc(x.language)}</td><td>${dfmt(x.fromDate)}</td><td>${dfmt(x.toDate)}</td><td>${x.shows}</td><td>${badge(x.status)}</td></tr>`).join('')}</table></div>`).join('') : emptyBox(sh.length ? 'Nothing matches these filters.' : 'No shows have been scheduled yet, so there is no screening history.');
      };
      ['hf', 'ht'].forEach(i => $('#' + i).oninput = drawHist); ['hs', 'hm', 'hst'].forEach(i => $('#' + i).onchange = drawHist);
      $('#hx').onclick = () => csvDialog('cinebook-screening-history.csv', [['Screen', x => x.screenName], ['Movie', x => x.title], ['Language', x => x.language], ['From', x => x.fromDate], ['To', x => x.toDate], ['Shows', x => x.shows], ['Status', x => x.status]], cur);
      drawHist();
    } else {
      b.innerHTML = `<div class="card"><p class="muted">Can’t find your movie? Create it here. It is published to the catalogue straight away. Fill the fields marked *; add the rest later if you like.</p>${movieForm()}</div>`;
      document.querySelector('#ms').closest('div').hidden = true;
      $('#save-movie').onclick = () => run(async () => { const data = readMovieForm(); data.posterUrl = await uploadSelectedPoster(); data.status = 'UPCOMING'; await api('/theatre/movies', { method: 'POST', body: data }); toast('Movie created. Add it to your theatre next.'); pgTMovies(); });
    }
  };
  wireTabs('tmt', k => { tab = k; draw(); }); draw();
}


/* ---------- home: only movies that have shows where you are ---------- */
function pgMovie(id) { return pgMovieShows(id); }

/* ---------- Super Admin: bookings across all theatres (or one chosen) ---------- */
const BOOKING_PERIODS = [['last7', 'Last 7 days'], ['last30', 'Last 30 days'], ...PERIODS.filter(p => p[0] !== 'custom')];
function bookingRange(k) { const n = new Date(); n.setHours(0, 0, 0, 0); if (k === 'last7') { const a = new Date(n); a.setDate(a.getDate() - 6); return [a, n]; } if (k === 'last30') { const a = new Date(n); a.setDate(a.getDate() - 29); return [a, n]; } return presetRange(k); }
async function pgABookings() {
  const [theatres, movies] = await Promise.all([api('/admin/theatres?' + new URLSearchParams({ q: '', status: '' })), api('/admin/movies')]);
  let page = 0, cur = null, screens = [];
  view(pageHead('MANAGE', 'Bookings &amp; cancellations', 'Every booking on the platform. Pick a theatre to see only its bookings, cancellations, refunds and revenue.', '<button class="btn sec small" id="bx" type="button">Export CSV</button>')
    + `<div class="card"><div class="scope-line" id="bscope"></div><div class="filter-grid">
      <div><label>Theatre</label><select id="b-th"><option value="">All theatres</option>${theatres.map(t => `<option value="${t.id}">${esc(t.name)} — ${esc(t.city)}</option>`).join('')}</select></div>
      <div><label>Screen</label><select id="b-sc" disabled><option value="">All screens</option></select></div>
      <div><label>Movie</label><select id="b-mv"><option value="">All movies</option>${movies.map(m => `<option value="${m.id}">${esc(m.title)}</option>`).join('')}</select></div>
      <div><label>Booking status</label><select id="b-st"><option value="">Any</option>${['CONFIRMED', 'CANCELLED', 'PENDING_PAYMENT', 'EXPIRED'].map(x => `<option>${x}</option>`).join('')}</select></div>
      <div><label>Payment / refund</label><select id="b-ps"><option value="">Any</option>${['SUCCESS', 'FAILED', 'PENDING', 'REFUND_PENDING', 'REFUNDED'].map(x => `<option>${x}</option>`).join('')}</select></div>
      <div><label>Booked in</label><select id="b-per">${BOOKING_PERIODS.map(([k, l]) => `<option value="${k}" ${k === 'last30' ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
      <div><label>From</label><input type="date" id="b-from"></div><div><label>To</label><input type="date" id="b-to"></div>
      <div><label>Search</label><input id="b-q" placeholder="Reference, customer, movie, seat…"></div></div></div>
    <div id="bk"></div><div id="bl"></div>`);
  const range = () => { if (val('b-from') && val('b-to')) return [val('b-from'), val('b-to')]; const [a, b] = bookingRange(val('b-per')); return [isoD(a), isoD(b)]; };
  const params = (pg, size) => { const [from, to] = range(), p = new URLSearchParams({ from, to, page: pg, size }); [['theatreId', 'b-th'], ['screenId', 'b-sc'], ['movieId', 'b-mv'], ['status', 'b-st'], ['paymentStatus', 'b-ps'], ['q', 'b-q']].forEach(([k, id]) => { if (val(id)) p.set(k, val(id)); }); return p; };
  const load = async () => {
    cur = await api('/admin/bookings?' + params(page, 25)); const sm = cur.summary, th = theatres.find(t => String(t.id) === val('b-th')), [from, to] = range();
    $('#bscope').innerHTML = `<b>Showing:</b> ${th ? esc(th.name) + ' <small class="muted">(' + esc(th.city) + ')</small>' : 'All theatres'}${val('b-sc') ? ' › ' + esc($('#b-sc').selectedOptions[0].text) : ''} · bookings made <b>${from}</b> → <b>${to}</b>`;
    $('#bk').innerHTML = `<div class="stats2">${stat2('▤', 'Bookings', fmtNum(sm.bookings), '', 'ivory')}${stat2('✓', 'Confirmed', fmtNum(sm.confirmed), '', 'sage')}${stat2('✕', 'Cancelled', fmtNum(sm.cancelled), '', 'terra')}${stat2('₹', 'Revenue (confirmed)', money(sm.revenue), '', 'gold')}${stat2('↺', 'Refunds', money(sm.refunds), '', 'rose')}${stat2('⏳', 'Refunds pending', fmtNum(sm.refundsPending), '', 'butter')}</div>`;
    const pages = Math.max(1, Math.ceil(cur.total / cur.size));
    $('#bl').innerHTML = cur.rows.length ? `<div class="card tablewrap"><table><tr><th>Booked</th><th>Booking</th><th>Customer</th><th>Theatre · screen</th><th>Movie · show</th><th>Seats</th><th>Amount</th><th>Status</th><th></th></tr>${cur.rows.map((r, i) => `<tr><td>${fmt(r.createdAt)}</td><td><b>${esc(r.reference)}</b></td><td>${esc(r.customer)}<br><small class="muted">${esc(r.customerEmail || '')}</small></td><td>${esc(r.theatre)}<br><small class="muted">${esc(r.screen)}</small></td><td>${esc(r.movie)}<br><small class="muted">${fmt(r.showTime)}</small></td><td>${esc(r.seats || '')}</td><td>${money(r.amount)}${r.offerCode ? '<br><small class="gold">' + esc(r.offerCode) + '</small>' : ''}</td><td>${badge(r.status)} ${badge(r.paymentStatus)}</td><td><button class="btn sec small" data-d="${i}" type="button">Details</button></td></tr>`).join('')}</table></div>
      <div class="pager"><button class="btn sec small" id="bp" ${page === 0 ? 'disabled' : ''}>← Previous</button><span class="muted">Page ${page + 1} of ${pages} · ${fmtNum(cur.total)} booking(s)</span><button class="btn sec small" id="bn" ${page + 1 >= pages ? 'disabled' : ''}>Next →</button></div>` : emptyBox('No bookings match these filters.');
    document.querySelectorAll('#bl [data-d]').forEach(b => b.onclick = () => { const r = cur.rows[Number(b.dataset.d)];
      const kv = [['Booking', r.reference], ['Customer', r.customer + (r.customerEmail ? ' · ' + r.customerEmail : '')], ['Theatre · screen', r.theatre + ' · ' + r.screen], ['Movie', r.movie], ['Show time', fmt(r.showTime)], ['Seats', r.seats || '—'], ['Tickets', r.tickets], ['Amount paid', money(r.amount)], ['Offer', r.offerCode ? r.offerCode + ' (−' + money(r.discount) + ')' : '—'], ['Booked on', fmt(r.createdAt)], ['Status', r.status], ['Payment', r.paymentStatus],
        ['Cancelled on', r.cancelledAt ? fmt(r.cancelledAt) : '—'], ['Why cancelled', r.showCancelReason ? 'Show cancelled: ' + r.showCancelReason : r.cancelledAt ? 'Cancelled by customer' : '—'], ['Refund', r.refundAmount != null ? money(r.refundAmount) + ' (' + (r.refundStatus || '') + ')' : '—'], ['Refund completed', r.refundCompletedAt ? fmt(r.refundCompletedAt) + ' · ref ' + (r.refundReference || '') : '—']];
      const m = modal(`<h3>Booking ${esc(r.reference)}</h3><div class="kv-list">${kv.map(([k, v]) => `<span>${k}</span><b>${esc(v)}</b>`).join('')}</div><div class="actions"><button class="btn sec" id="bclose">Close</button></div>`); m.querySelector('#bclose').onclick = () => m.remove(); });
    const pp = $('#bp'), pn = $('#bn'); if (pp) pp.onclick = () => { page--; run(load); }; if (pn) pn.onclick = () => { page++; run(load); };
  };
  const reset = () => { page = 0; run(load); };
  $('#b-th').onchange = () => run(async () => { const id = val('b-th'), sc = $('#b-sc'); sc.innerHTML = '<option value="">All screens</option>'; sc.disabled = !id; if (id) { screens = await api(`/admin/theatres/${id}/screens`); sc.innerHTML += screens.map(s => `<option value="${s.id}">${esc(s.name)} (${s.totalSeats} seats)</option>`).join(''); } page = 0; await load(); });
  ['b-sc', 'b-mv', 'b-st', 'b-ps', 'b-per'].forEach(i => $('#' + i).onchange = reset); ['b-from', 'b-to'].forEach(i => $('#' + i).onchange = reset);
  $('#b-q').oninput = debounce(reset, 350);
  $('#bx').onclick = () => run(() => csvDialog('cinebook-bookings.csv', [['Booked', r => r.createdAt], ['Booking', r => r.reference], ['Customer', r => r.customer], ['Customer email', r => r.customerEmail], ['Theatre', r => r.theatre], ['Screen', r => r.screen], ['Movie', r => r.movie], ['Show time', r => r.showTime], ['Seats', r => r.seats], ['Tickets', r => r.tickets], ['Amount', r => r.amount], ['Discount', r => r.discount], ['Offer', r => r.offerCode], ['Status', r => r.status], ['Payment', r => r.paymentStatus], ['Refund', r => r.refundAmount], ['Refund status', r => r.refundStatus], ['Cancelled on', r => r.cancelledAt]], async () => { const all = []; for (let p = 0; p < 50; p++) { const c = await api('/admin/bookings?' + params(p, 200)); all.push(...c.rows); if (all.length >= c.total) break; } return all; }));
  await load();
}

/* =====================================================================
   v3 — customer experience: city picker, shortlist, home, search, bookings
   ===================================================================== */
const splitCsv = s => { const seen = new Set(), out = []; String(s || '').split(',').forEach(x => { x = x.trim().replace(/\s+/g, ' '); if (!x) return; const k = x.toLowerCase(); if (!seen.has(k)) { seen.add(k); out.push(titleCase(x)); } }); return out; };
const posterStyle = m => { const u = String(m.posterUrl || ''); return /^(https?:)?\/\/|^\/(?!\/)/.test(u) ? `background-image:url('${esc(u)}')` : ''; };
const shortDate = d => d ? new Date(d + 'T00:00').toLocaleDateString('en', { day: 'numeric', month: 'short' }) : 'soon';
const SLK = { movie: 'slMovies', theatre: 'slTheatres' };
const isSL = (k, id) => store.get(SLK[k], []).some(x => String(x.id) === String(id));
function toggleSL(k, id, meta = {}) { const l = store.get(SLK[k], []), i = l.findIndex(x => String(x.id) === String(id)); if (i >= 0) l.splice(i, 1); else l.unshift({ id: Number(id), ...meta }); store.set(SLK[k], l); return i < 0; }
document.addEventListener('click', e => {
  const h = e.target.closest('[data-h]'); if (!h) return; e.preventDefault(); e.stopPropagation();
  const k = h.dataset.k || 'movie', on = toggleSL(k, h.dataset.h, { name: h.dataset.n || '', sub: h.dataset.s || '' });
  document.querySelectorAll(`[data-h="${h.dataset.h}"][data-k="${k}"]`).forEach(x => x.classList.toggle('on', on));
  toast(on ? 'Added to your shortlist ♥' : 'Removed from shortlist');
  if (location.hash === '#/shortlist') pgShortlist();
});
const pcard = m => {
  const soon = (m.releaseDate || '') > isoD(new Date()), ps = posterStyle(m);
  return `<article class="pcard"><button type="button" class="heart ${isSL('movie', m.id) ? 'on' : ''}" data-h="${m.id}" data-k="movie" aria-label="Shortlist ${esc(m.title)}">♥</button>
    <a class="pimg" href="#/movie/${m.id}" style="${ps}${ps ? ';' + ps.replace('background-image:', '--poster:') : ''}" aria-label="${esc(m.title)}">${ps ? '' : '✦'}<span class="tag ${soon ? 'soon' : 'live'}">${soon ? 'Coming ' + esc(shortDate(m.releaseDate)) : m.status === 'ACTIVE' ? 'Now showing' : 'Released'}</span></a>
    <b>${esc(m.title)}</b><small>${esc(splitCsv(m.language).slice(0, 2).join(', ') || 'Multiple languages')} · ${esc(splitCsv(m.genre)[0] || 'Film')}</small></article>`;
};
function topStrip(withSearch = true) {
  const cn = localStorage.getItem('cityName'), has = localStorage.getItem('cityId');
  return `<div class="topstrip"><button class="citypill" id="citybtn" type="button"><i class="pin"></i>${esc(cn ? cn + (localStorage.getItem('districtName') && localStorage.getItem('districtName') !== cn ? ', ' + localStorage.getItem('districtName') : '') : (has ? 'Your area' : 'Select area'))} <small>▾</small></button>${withSearch ? '<div class="quicksearch"><input id="qs" placeholder="Search movies, actors, genres…" aria-label="Search movies"></div>' : ''}</div>`;
}
function wireStrip(onChange) {
  const b = $('#citybtn'); if (b) b.onclick = () => openCityModal(onChange);
  const q = $('#qs'); if (q) q.onkeydown = e => { if (e.key === 'Enter' && q.value.trim()) { store.set('pendingQ', q.value.trim()); location.hash = '#/search'; } };
}
function openCityModal(onChange) {
  const m = modal(`<h3>Choose your location</h3><p class="muted">Pick your district and area. If your area has no theatre, we show the nearest ones.</p>${pickerHtml('cm')}<div class="actions"><button class="btn sec" id="cm-clear" type="button">Show everywhere</button><button class="btn sec" id="cm-x" type="button">Close</button></div>`);
  run(() => initPicker('cm', c => { if (!c) return; const g = id => m.querySelector('#cm-' + id).selectedOptions[0], t = g('city').text.replace(' (main town)', ''), dn = g('district').text; setLoc({ cityId: c, cityName: t, districtId: g('district').value, districtName: dn, stateId: g('state').value, stateName: g('state').text }); m.remove(); toast('Location set to ' + t + (t === dn ? '' : ', ' + dn)); if (onChange) onChange(); }));
  m.querySelector('#cm-clear').onclick = () => { setLoc(null); m.remove(); if (onChange) onChange(); };
  m.querySelector('#cm-x').onclick = () => m.remove();
}
const stepperHtml = n => `<div class="stepper">${['Choose seats', 'Pay', 'Get ticket'].map((l, i) => `${i ? '<em></em>' : ''}<span class="${i + 1 === n ? 'on' : i + 1 < n ? 'done' : ''}"><b>${i + 1 < n ? '✓' : i + 1}</b>${l}</span>`).join('')}</div>`;
const chipRow = (list, cur, all) => `<button type="button" class="chip ${cur ? '' : 'on'}" data-v="">${all}</button>` + list.map(x => `<button type="button" class="chip ${x === cur ? 'on' : ''}" data-v="${esc(x)}">${esc(x)}</button>`).join('');
const topBy = (list, k) => { const c = {}; list.forEach(m => splitCsv(m[k]).forEach(x => c[x] = (c[x] || 0) + 1)); return Object.entries(c).sort((a, b) => b[1] - a[1]).map(x => x[0]).slice(0, 14); };

async function pgHome() {
  const all = (await api('/public/movies')).filter(m => m.status !== 'ARCHIVED'), cityId = (restoreUserLoc(), localStorage.getItem('cityId')), today = isoD(new Date());
  const L = getLoc(); let avail = null, availNote = '';
  const av = async q => { try { return new Set((await api('/public/movies/available?' + q)).map(x => x.movieId)); } catch (e) { return new Set(); } };
  if (cityId) { avail = await av('cityId=' + cityId); if (!avail.size && L.districtId) { avail = await av('districtId=' + L.districtId); availNote = 'No theatre in ' + L.cityName + ' yet. Showing movies from ' + L.districtName + ' district.'; } if (!avail.size && L.stateId) { avail = await av('stateId=' + L.stateId); availNote = 'Showing movies from across ' + L.stateName + '.'; } }
  const soon = all.filter(m => (m.releaseDate || '') > today).sort((a, b) => a.releaseDate.localeCompare(b.releaseDate));
  const live = all.filter(m => !soon.includes(m) && (!avail || avail.has(m.id))).sort((a, b) => (b.releaseDate || '').localeCompare(a.releaseDate || ''));
  const F = { tab: 'live', lang: '', genre: '' }, cn = localStorage.getItem('cityName'), saved = new Set(store.get('slMovies', []).map(x => x.id)), mine = all.filter(m => saved.has(m.id));
  view(`${topStrip()}<section class="hero3"><p class="eyebrow">CineBook</p><h1>Your next great night out starts here.</h1><p>Pick a movie, choose a theatre near you and grab the best seats in under a minute.</p>
    <div class="actions"><a class="btn" href="#/search">Browse &amp; filter all movies</a><a class="btn sec" href="#/offers">See offers</a></div>
    <div class="herostats"><span>${live.length} now showing</span><span>${soon.length} coming soon</span>${cn ? `<span>${esc(cn)}</span>` : ''}</div></section>
    ${mine.length ? `<section class="movie-section"><div class="section-heading"><div><h2>Your shortlist</h2><p class="muted">Saved by you ♥</p></div><a class="text-link" href="#/shortlist">Open all →</a></div><div class="rail">${mine.slice(0, 12).map(pcard).join('')}</div></section>` : ''}
    <section class="movie-section"><div class="section-heading"><div><h2>Movies</h2><p class="muted" id="hs"></p></div><a class="text-link" href="#/search">Advanced filters →</a></div>
    ${tabsHtml('htabs', [['live', 'Now showing', live.length], ['soon', 'Coming soon', soon.length]], 'live')}<div class="filterchips" id="hl"></div><div class="filterchips" id="hg"></div><div id="hgrid"></div></section>`);
  const draw = () => {
    const base = F.tab === 'live' ? live : soon;
    $('#hl').innerHTML = chipRow(topBy(base, 'language'), F.lang, 'All languages') + '<a class="chip" href="#/search">More languages →</a>'; $('#hg').innerHTML = chipRow(topBy(base, 'genre'), F.genre, 'All genres');
    const list = base.filter(m => (!F.lang || splitCsv(m.language).includes(F.lang)) && (!F.genre || splitCsv(m.genre).includes(F.genre)));
    $('#hs').textContent = F.tab === 'live' ? (availNote || (cn ? `Movies with shows in ${cn}` : 'Choose your area above to see only movies with shows near you')) : 'Upcoming releases';
    $('#hgrid').innerHTML = list.length ? `<div class="pgrid">${list.slice(0, 30).map(pcard).join('')}</div>${list.length > 30 ? `<p style="text-align:center;margin-top:18px"><a class="btn sec" href="#/search">See all ${list.length} movies</a></p>` : ''}`
      : emptyBox(F.lang || F.genre ? 'No movies match these filters.' : F.tab === 'live' && cityId ? 'No movie has shows in your city yet. Check “Coming soon” or change your city.' : 'Nothing here yet.');
  };
  $('#hl').onclick = e => { const b = e.target.closest('[data-v]'); if (b) { F.lang = b.dataset.v; draw(); } };
  $('#hg').onclick = e => { const b = e.target.closest('[data-v]'); if (b) { F.genre = b.dataset.v; draw(); } };
  wireTabs('htabs', k => { F.tab = k; F.lang = F.genre = ''; draw(); }); wireStrip(() => pgHome()); draw(); askLocationOnce(() => pgHome());
}
async function pgMovies() { location.hash = '#/search'; }

async function pgSearch() {
  const all = (await api('/public/movies')).filter(m => m.status !== 'ARCHIVED');
  const F = { q: store.get('pendingQ', '') || '', st: '', lg: new Set(), gn: new Set(), yr: '', sort: 'title', loc: null }; store.set('pendingQ', '');
  const langs = topBy(all, 'language'), genres = topBy(all, 'genre'), years = [...new Set(all.map(m => (m.releaseDate || '').slice(0, 4)).filter(Boolean))].sort().reverse();
  const chips = (id, list) => list.map(x => `<button type="button" class="chip" data-g="${id}" data-v="${esc(x)}">${esc(x)}</button>`).join('') || '<span class="muted">None</span>';
  view(`${topStrip(false)}<div class="page-heading"><div><p class="eyebrow">Discover</p><h1>Find your movie</h1></div></div>
    <div class="searchlayout"><aside class="card fpanel ${window.innerWidth <= 900 ? 'collapsed' : ''}" id="fp">
      <div class="fgroup"><h4>Location</h4><input id="lq" autocomplete="off" placeholder="District or city…"><div id="ls" class="location-suggestions" role="listbox"></div><div class="muted small-note" id="lsel">All locations</div></div>
      <div class="fgroup"><h4>Release</h4><div class="chips" id="f-st">${[['', 'All'], ['ACTIVE', 'Now showing'], ['UPCOMING', 'Coming soon']].map(([v, l]) => `<button type="button" class="chip" data-g="st" data-v="${v}">${l}</button>`).join('')}</div></div>
      <div class="fgroup"><h4>Language</h4><div class="facet">${facetHtml('lg', all, 'language', LANG_SUGGEST)}</div></div>
      <div class="fgroup"><h4>Genre</h4><div class="facet">${facetHtml('gn', all, 'genre', GENRE_SUGGEST)}</div></div>
      <div class="fgroup"><h4>Release year</h4><select id="f-yr"><option value="">Any year</option>${years.map(y => `<option>${y}</option>`).join('')}</select></div>
      <button class="btn sec" id="f-clear" type="button">Clear all filters</button></aside>
    <div><div class="catalog-search" style="display:flex;gap:10px;margin-bottom:12px"><input id="q" value="${esc(F.q)}" placeholder="Search titles, actors, directors…" aria-label="Search movies"><button class="btn" id="sr" type="button">Search</button></div><div id="recent" class="chips"></div>
      <div class="resultbar"><b id="rc"></b><div style="display:flex;gap:8px;align-items:center"><button class="btn sec small filtertoggle" id="ftog" type="button">Filters</button><select id="f-sort" aria-label="Sort"><option value="title">Title A–Z</option><option value="newest">Newest first</option><option value="oldest">Oldest first</option></select></div></div>
      <div class="activebar" id="ab"></div><div id="results"></div></div></div>`);
  const sync = () => {
    document.querySelectorAll('#fp .chip[data-g]').forEach(c => { const g = c.dataset.g, v = c.dataset.v; c.classList.toggle('on', g === 'st' ? F.st === v : F[g].has(v)); });
    const pills = [...(F.q ? [['q', '', 'Search: ' + F.q]] : []), ...(F.st ? [['st', '', F.st === 'ACTIVE' ? 'Now showing' : 'Coming soon']] : []), ...[...F.lg].map(v => ['lg', v, v]), ...[...F.gn].map(v => ['gn', v, v]), ...(F.yr ? [['yr', '', F.yr]] : []), ...(F.loc ? [['loc', '', '' + F.loc.name]] : [])];
    $('#ab').innerHTML = pills.map(([g, v, l]) => `<span class="pill">${esc(l)}<button type="button" data-rm="${g}" data-v="${esc(v)}" aria-label="Remove">×</button></span>`).join('');
  };
  const load = () => run(async () => {
    rememberQ(F.q); drawRecent(() => { F.q = val('q'); sync(); load(); });
    let list; if (F.q || F.loc || F.st) { const qs = new URLSearchParams(); if (F.q) qs.set('q', F.q); if (F.st) qs.set('status', F.st); if (F.loc) qs.set('locationId', F.loc.id); list = (await api('/public/movies?' + qs)).filter(m => m.status !== 'ARCHIVED'); } else list = all.slice();
    list = list.filter(m => (!F.lg.size || splitCsv(m.language).some(x => F.lg.has(x))) && (!F.gn.size || splitCsv(m.genre).some(x => F.gn.has(x))) && (!F.yr || (m.releaseDate || '').startsWith(F.yr)));
    list.sort((a, b) => F.sort === 'newest' ? (b.releaseDate || '').localeCompare(a.releaseDate || '') : F.sort === 'oldest' ? (a.releaseDate || '9999').localeCompare(b.releaseDate || '9999') : a.title.localeCompare(b.title));
    $('#rc').textContent = list.length + ' movie' + (list.length === 1 ? '' : 's');
    $('#results').innerHTML = list.length ? `<div class="pgrid">${list.map(pcard).join('')}</div>` : `<div class="empty">No movies match these filters.<br><button class="btn small" id="e-clear" type="button" style="margin-top:12px">Clear filters</button></div>`;
    const ec = $('#e-clear'); if (ec) ec.onclick = clearAll;
  });
  const clearAll = () => { F.q = ''; F.st = ''; F.lg.clear(); F.gn.clear(); F.yr = ''; F.loc = null; $('#q').value = ''; $('#f-yr').value = ''; $('#lq').value = ''; $('#ls').innerHTML = ''; $('#lsel').textContent = 'All locations'; sync(); load(); };
  $('#fp').onclick = e => { const c = e.target.closest('.chip[data-g]'); if (!c) return; const g = c.dataset.g, v = c.dataset.v; if (g === 'st') F.st = v; else F[g].has(v) ? F[g].delete(v) : F[g].add(v); sync(); load(); };
  $('#ab').onclick = e => { const b = e.target.closest('[data-rm]'); if (!b) return; const g = b.dataset.rm, v = b.dataset.v; if (g === 'q') { F.q = ''; $('#q').value = ''; } else if (g === 'st') F.st = ''; else if (g === 'yr') { F.yr = ''; $('#f-yr').value = ''; } else if (g === 'loc') { F.loc = null; $('#lq').value = ''; $('#lsel').textContent = 'All locations'; } else F[g].delete(v); sync(); load(); };
  $('#f-yr').onchange = e => { F.yr = e.target.value; sync(); load(); }; $('#f-sort').onchange = e => { F.sort = e.target.value; load(); };
  $('#f-clear').onclick = clearAll; $('#ftog').onclick = () => $('#fp').classList.toggle('collapsed');
  $('#sr').onclick = () => { F.q = val('q'); sync(); load(); }; $('#q').onkeydown = e => { if (e.key === 'Enter') { F.q = val('q'); sync(); load(); } }; $('#q').oninput = debounce(() => { F.q = val('q'); sync(); load(); }, 350);
  let t; $('#lq').oninput = () => { clearTimeout(t); const q = val('lq'), box = $('#ls'); if (q.length < 2) { box.innerHTML = ''; return; }
    t = setTimeout(() => run(async () => { const items = (await api('/public/locations/search?q=' + encodeURIComponent(q))).filter(l => String(l.type).toUpperCase() !== 'STATE'); box.innerHTML = items.length ? items.map(l => `<button type="button" class="location-option" data-id="${l.id}" data-name="${esc(l.name)}" data-type="${esc(l.type)}"><b>${esc(l.name)}</b><span>${esc(l.type.toLowerCase())}</span></button>`).join('') : '<div class="muted small-note">No matching location</div>';
      box.querySelectorAll('button').forEach(b => b.onclick = () => { F.loc = { id: Number(b.dataset.id), name: b.dataset.name }; $('#lq').value = F.loc.name; box.innerHTML = ''; $('#lsel').textContent = 'Shows in ' + F.loc.name + ' (' + b.dataset.type.toLowerCase() + ')'; sync(); load(); }); }), 220); };
  wireStrip(() => pgSearch()); sync(); load();
}

async function pgShortlist() {
  let tab = pgShortlist.tab || 'movies'; const all = await api('/public/movies'), ids = new Set(store.get('slMovies', []).map(x => x.id)), movies = all.filter(m => ids.has(m.id)), th = store.get('slTheatres', []);
  view(pageHead('Your list', 'Shortlist', 'Movies and theatres you saved ♥ — kept on this device.') + tabsHtml('sltabs', [['movies', 'Movies', movies.length], ['theatres', 'Theatres', th.length]], tab) + '<div id="slbody"></div>');
  const draw = () => { $('#slbody').innerHTML = tab === 'movies'
    ? (movies.length ? `<div class="pgrid">${movies.map(pcard).join('')}</div>` : emptyBox('No movies shortlisted yet. Tap the ♥ on any poster to save it.'))
    : (th.length ? th.map(t => `<div class="card theatre-card"><div class="tcard-h"><div class="tname"><span class="tlogo">${esc((t.name || 'T')[0])}</span><div><b>${esc(t.name)}</b><br><small class="muted">${esc(t.sub || '')}</small></div></div><button class="btn sec small" type="button" data-h="${t.id}" data-k="theatre">Remove</button></div></div>`).join('') : emptyBox('No theatres shortlisted yet. Open a movie and tap ♥ beside a theatre.')); };
  wireTabs('sltabs', k => { tab = k; pgShortlist.tab = k; draw(); }); draw();
}

/* ---------- My bookings: tabs + search + date filter ---------- */
async function pgPayments() {
  const list = await api('/customer/payments'); let f = 'ALL';
  const ok = list.filter(p => p.status === 'SUCCESS'), paid = ok.reduce((a, p) => a + Number(p.amount), 0);
  view(pageHead('My account', 'Payments', 'Every payment you made, with transaction IDs and receipts.') +
    `<div class="stats2">${stat2('₹', 'Total paid', money(paid), ok.length + ' successful')}${stat2('✓', 'Successful', ok.length)}${stat2('✕', 'Failed', list.filter(p => p.status === 'FAILED').length)}${stat2('↺', 'Refunded', list.filter(p => p.status === 'REFUNDED').length)}</div>
    <div id="pt"></div><div id="pl"></div>`);
  const draw = () => {
    $('#pt').innerHTML = tabsHtml('ptabs', [['ALL', 'All', list.length], ['SUCCESS', 'Successful', ok.length], ['FAILED', 'Failed', list.filter(p => p.status === 'FAILED').length], ['REFUNDED', 'Refunded', list.filter(p => p.status === 'REFUNDED').length]], f);
    wireTabs('ptabs', k => { f = k; draw(); });
    const rows = list.filter(p => f === 'ALL' || p.status === f);
    $('#pl').innerHTML = rows.length ? `<div class="card" style="overflow:auto"><table><thead><tr><th>Date</th><th>Movie</th><th>Amount</th><th>Method</th><th>Status</th><th>Transaction ID</th><th></th></tr></thead><tbody>${rows.map((p, i) => `<tr><td>${fmt(p.paidAt)}</td><td><b>${esc(p.movieTitle)}</b><br><small class="muted">${esc(p.theatreName)} · ${esc(p.bookingReference)}</small></td><td>${money(p.amount)}</td><td>${esc(p.method)}</td><td>${badge(p.status)}</td><td><code>${esc(p.transactionRef)}</code></td><td>${p.status === 'SUCCESS' ? `<button class="btn sec small" data-i="${i}">Receipt</button>` : ''}</td></tr>`).join('')}</tbody></table></div>` : emptyBox('No payments yet.');
    $('#pl').onclick = e => { const b = e.target.closest('[data-i]'); if (!b) return; const p = rows[b.dataset.i];
      const m = modal(`<div id="rcpt"><h3>Payment receipt</h3><p><b>${esc(p.movieTitle)}</b><br>${esc(p.theatreName)}</p><table><tbody><tr><td>Booking</td><td>${esc(p.bookingReference)}</td></tr><tr><td>Paid on</td><td>${fmt(p.paidAt)}</td></tr><tr><td>Method</td><td>${esc(p.method)}</td></tr><tr><td>Transaction ID</td><td><code>${esc(p.transactionRef)}</code></td></tr><tr><td>Amount</td><td><b>${money(p.amount)}</b></td></tr></tbody></table><p class="muted">Test-mode payment. No real money was charged.</p></div><div class="actions"><button class="btn" id="rp">Print</button><button class="btn sec" id="rx">Close</button></div>`);
      m.querySelector('#rp').onclick = () => window.print(); m.querySelector('#rx').onclick = () => m.remove(); };
  };
  draw();
}
async function pgBookings() {
  const [list, reviewed] = await Promise.all([api('/customer/bookings'), api('/customer/reviews/mine').catch(() => [])]);
  const done = new Set(reviewed), now = new Date(); let tab = 'upcoming', q = '', from = '', to = '', sort = 'new';
  const kind = b => b.status === 'CONFIRMED' ? (new Date(b.showTime) >= now ? 'upcoming' : 'watched') : ['CANCELLED', 'EXPIRED'].includes(b.status) ? 'cancelled' : 'pending';
  const tabs = [['upcoming', 'Upcoming'], ['watched', 'Watched'], ['cancelled', 'Cancelled'], ['pending', 'Awaiting payment'], ['all', 'All']];
  view(pageHead('My account', 'My bookings', 'Your tickets, past shows and cancellations in one place.', '<button class="btn sec small" id="bkx" type="button">Export CSV</button>') + '<div id="bt"></div><div class="card"><div class="filter-grid"><div><label>Search</label><input id="bq" placeholder="Movie, theatre or booking reference"></div><div><label>Show date from</label><input type="date" id="bfrom"></div><div><label>to</label><input type="date" id="bto"></div><div><label>Sort</label><select id="bsort"><option value="new">Newest show first</option><option value="old">Oldest show first</option></select></div></div></div><div id="bl"></div>');
  const draw = () => {
    $('#bt').innerHTML = tabsHtml('btabs', tabs.map(([k, l]) => [k, l, k === 'all' ? list.length : list.filter(b => kind(b) === k).length]), tab); wireTabs('btabs', k => { tab = k; draw(); });
    const rows = list.filter(b => (tab === 'all' || kind(b) === tab) && (!q || [b.movieTitle, b.theatreName, b.reference].some(x => String(x || '').toLowerCase().includes(q))) && (!from || String(b.showTime).slice(0, 10) >= from) && (!to || String(b.showTime).slice(0, 10) <= to))
      .sort((a, b) => sort === 'new' ? new Date(b.showTime) - new Date(a.showTime) : new Date(a.showTime) - new Date(b.showTime)); CUR_B = rows;
    $('#bl').innerHTML = rows.length ? rows.map(b => `<div class="card bk-card"><div class="bk-main"><b>${esc(b.movieTitle)}</b> ${badge(b.status)} ${badge(b.paymentStatus)}<br><span class="muted">${esc(b.theatreName)} · ${esc(b.screenName)} · ${fmt(b.showTime)}</span><br>Seats ${esc(b.seats)} · ${money(b.totalAmount)} · Ref <b>${esc(b.reference)}</b>${b.refundAmount != null ? `<br>Refund ${money(b.refundAmount)} (${esc(b.refundStatus)})` : ''}</div>
      <div class="bk-side">${b.status === 'CONFIRMED' ? `<button class="btn sec small" onclick="showExistingTicket('${esc(b.reference)}')">View ticket / QR</button><button class="btn danger small" onclick="cancelBooking('${esc(b.reference)}')">Cancel</button>` : ''}
      ${b.status === 'CONFIRMED' && new Date(b.showTime) < now ? (done.has(b.reference) ? '<span class="badge ACTIVE">Reviewed ✓</span>' : `<button class="btn small" onclick="rateBooking('${esc(b.reference)}','${esc(b.movieTitle).replace(/'/g, '')}')">★ Rate this show</button>`) : ''}
      ${b.status !== 'PENDING_PAYMENT' ? `<button class="btn sec small" onclick="location.hash='#/complaints'">Report a problem</button>` : ''}</div></div>`).join('') : emptyBox(list.length ? 'No bookings match these filters.' : 'No bookings yet — <a href="#/home">find a movie</a>.');
  };
  $('#bq').oninput = e => { q = e.target.value.toLowerCase(); draw(); }; $('#bfrom').onchange = e => { from = e.target.value; draw(); }; $('#bto').onchange = e => { to = e.target.value; draw(); }; $('#bsort').onchange = e => { sort = e.target.value; draw(); };
  $('#bkx').onclick = () => csvDialog('my-cinebook-bookings.csv', [['Movie', b => b.movieTitle], ['Theatre', b => b.theatreName], ['Screen', b => b.screenName], ['Show time', b => b.showTime], ['Seats', b => b.seats], ['Amount', b => b.totalAmount], ['Status', b => b.status], ['Payment', b => b.paymentStatus], ['Reference', b => b.reference], ['Refund amount', b => b.refundAmount], ['Refund status', b => b.refundStatus]], CUR_B);
  draw();
}

/* ---------- Super Admin: users with real filters ---------- */
async function pgAUsers() {
  const [list, theatres] = await Promise.all([api('/admin/users'), api('/admin/theatres?' + new URLSearchParams({ q: '', status: '' })).catch(() => [])]);
  const area = {}; theatres.forEach(t => area[String(t.ownerEmail || '').toLowerCase()] = { state: t.state, city: t.city, theatre: t.name });
  const states = [...new Set(theatres.map(t => t.state).filter(Boolean))].sort(); let cur = [], tab = 'ALL', q = '', act = '', st = '', ct = '', page = 1;
  const ROLES = [['ALL', 'Everyone'], ['CUSTOMER', 'Customers'], ['THEATRE_ADMIN', 'Theatre admins'], ['SUPER_ADMIN', 'Super admins']];
  view(pageHead('Manage', 'Users', 'Find people fast: search, role, status and — for theatre owners — area.') + '<div id="ut"></div><div class="card"><div class="filter-grid"><div><label>Search</label><input id="uq" placeholder="Name, email or phone"></div><div><label>Status</label><select id="ua"><option value="">Any</option><option value="1">Active</option><option value="0">Deactivated</option></select></div>'
    + `<div><label>City (theatre owners)</label><select id="uc"><option value="">All cities</option>${[...new Set(theatres.map(t => t.city).filter(Boolean))].sort().map(x => `<option>${esc(x)}</option>`).join('')}</select></div><div><button class="btn sec" id="ux" type="button">Export CSV</button></div></div></div><div id="ul"></div>`);
  const draw = () => {
    $('#ut').innerHTML = tabsHtml('utabs', ROLES.map(([k, l]) => [k, l, k === 'ALL' ? list.length : list.filter(u => u.role === k).length]), tab); wireTabs('utabs', k => { tab = k; page = 1; draw(); });
    const rows = list.filter(u => (tab === 'ALL' || u.role === tab) && (!q || [u.name, u.email, u.phone].some(x => String(x || '').toLowerCase().includes(q))) && (!act || (act === '1') === !!u.active) && (!st || (area[u.email.toLowerCase()] || {}).state === st) && (!ct || (area[u.email.toLowerCase()] || {}).city === ct));
    cur = rows; const shown = rows.slice(0, page * 25);
    $('#ul').innerHTML = rows.length ? `<div class="card tablewrap"><table><tr><th>Name</th><th>Email</th><th>Phone</th><th>Role</th><th>Theatre · area</th><th>Status</th><th></th></tr>${shown.map(u => { const a = area[u.email.toLowerCase()]; return `<tr><td><b>${esc(u.name)}</b></td><td>${esc(u.email)}</td><td>${esc(u.phone || '—')}</td><td><span class="chip static">${esc(String(u.role).replace('_', ' ').toLowerCase())}</span></td><td>${a ? esc(a.theatre) + '<br><small class="muted">' + esc(a.city) + '</small>' : '<span class="muted">—</span>'}</td><td>${u.active ? badge('ACTIVE') : badge('DEACTIVATED')}</td>
      <td><button class="btn sec small" data-v="${u.id}" type="button">Details</button> ${u.role === 'SUPER_ADMIN' ? '' : `<button class="btn sec small" onclick="toggleUser(${u.id},${!u.active})">${u.active ? 'Deactivate' : 'Activate'}</button>`}</td></tr>`; }).join('')}</table></div><div class="pager"><span class="muted">Showing ${shown.length} of ${rows.length}</span>${shown.length < rows.length ? '<button class="btn sec small" id="umore" type="button">Show 25 more</button>' : ''}</div>` : emptyBox('No users match these filters.');
    document.querySelectorAll('#ul [data-v]').forEach(b => b.onclick = () => openUserDetail(list.find(x => String(x.id) === b.dataset.v)));
    const mb = $('#umore'); if (mb) mb.onclick = () => { page++; draw(); };
  };
  $('#uq').oninput = e => { q = e.target.value.toLowerCase(); page = 1; draw(); }; $('#ua').onchange = e => { act = e.target.value; page = 1; draw(); };
  $('#uc').onchange = e => { ct = e.target.value; page = 1; draw(); };
  $('#ux').onclick = () => csvDialog('cinebook-users.csv', [['Name', u => u.name], ['Email', u => u.email], ['Phone', u => u.phone], ['Role', u => u.role], ['Status', u => u.active ? 'Active' : 'Deactivated'], ['Theatre', u => (area[u.email.toLowerCase()] || {}).theatre || ''], ['City', u => (area[u.email.toLowerCase()] || {}).city || '']], cur);
  draw();
}

/* ---------- animated background particles (soft, cheap, respects reduced-motion) ---------- */
function initParticles() {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches || $('#particles')) return;
  const c = document.createElement('canvas'); c.id = 'particles'; c.setAttribute('aria-hidden', 'true'); document.body.prepend(c);
  const x = c.getContext('2d'), cols = ['#D99A9C', '#F1DFA5', '#BFE0F0', '#BFE3CB', '#E3D3EE', '#F6D2B8'], N = window.innerWidth < 700 ? 16 : 34; let W, H, ps = [];
  const size = () => { const d = Math.min(devicePixelRatio || 1, 1.5); W = c.width = innerWidth * d; H = c.height = innerHeight * d; c.style.width = innerWidth + 'px'; c.style.height = innerHeight + 'px'; };
  const mk = (init) => ({ x: Math.random() * W, y: init ? Math.random() * H : H + 20, r: (4 + Math.random() * 12) * (W / innerWidth), v: .12 + Math.random() * .35, s: Math.random() * 6, c: cols[Math.floor(Math.random() * cols.length)], t: Math.random() < .25 ? 'star' : 'dot', a: .25 + Math.random() * .35 });
  const star = (px, py, r) => { x.beginPath(); for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4, rr = i % 2 ? r * .45 : r; x.lineTo(px + Math.cos(a) * rr, py + Math.sin(a) * rr); } x.closePath(); x.fill(); };
  size(); addEventListener('resize', debounce(() => { size(); ps = Array.from({ length: N }, () => mk(true)); }, 200)); ps = Array.from({ length: N }, () => mk(true));
  let on = true; document.addEventListener('visibilitychange', () => { on = !document.hidden; if (on) tick(); });
  function tick() { if (!on) return; x.clearRect(0, 0, W, H); const tm = Date.now() / 1000; ps.forEach((p, i) => { p.y -= p.v * (W / innerWidth); p.x += Math.sin(tm + p.s) * .35; if (p.y < -30) ps[i] = mk(false); x.globalAlpha = p.a; x.fillStyle = p.c; if (p.t === 'star') star(p.x, p.y, p.r * .9); else { x.beginPath(); x.arc(p.x, p.y, p.r * .6, 0, 6.283); x.fill(); } }); x.globalAlpha = 1; requestAnimationFrame(tick); }
  tick();
}
initParticles();

/* =====================================================================
   v4 — locations (area/town + nearby fallback), export, user details,
   type-to-filter dropdowns, shared filter helpers
   ===================================================================== */
const titleCase = s => String(s).toLowerCase().replace(/(^|[\s\-\/&])([a-z])/g, (m, a, b) => a + b.toUpperCase());
const normCsv = s => splitCsv(s).join(', ');
const uniq = a => [...new Set(a.filter(Boolean))].sort((x, y) => String(x).localeCompare(String(y)));
const LANG_SUGGEST = ['Tamil', 'Telugu', 'Malayalam', 'Kannada', 'Hindi', 'English', 'Bengali', 'Marathi', 'Gujarati', 'Punjabi', 'Odia', 'Bhojpuri', 'Assamese', 'Urdu', 'Japanese', 'Korean', 'French', 'Spanish'];
const GENRE_SUGGEST = ['Action', 'Adventure', 'Animation', 'Biography', 'Comedy', 'Crime', 'Devotional', 'Documentary', 'Drama', 'Family', 'Fantasy', 'Historical', 'Horror', 'Musical', 'Mystery', 'Romance', 'Sci-Fi', 'Sports', 'Thriller', 'War'];
const datalists = () => `<datalist id="dl-lang">${LANG_SUGGEST.map(x => `<option value="${x}">`).join('')}</datalist><datalist id="dl-genre">${GENRE_SUGGEST.map(x => `<option value="${x}">`).join('')}</datalist>`;

/* nearby districts (Tamil Nadu); anything not listed falls back to the rest of the state */
const NEAR = {
  'Tiruppur': ['Coimbatore', 'Erode', 'Karur', 'Dindigul'], 'Coimbatore': ['Tiruppur', 'Nilgiris', 'Erode', 'Dindigul'], 'Erode': ['Tiruppur', 'Salem', 'Namakkal', 'Karur', 'Coimbatore'],
  'Karur': ['Tiruppur', 'Erode', 'Namakkal', 'Tiruchirappalli', 'Dindigul'], 'Salem': ['Namakkal', 'Erode', 'Dharmapuri', 'Krishnagiri'], 'Namakkal': ['Salem', 'Erode', 'Karur', 'Tiruchirappalli'],
  'Madurai': ['Dindigul', 'Theni', 'Sivaganga', 'Virudhunagar'], 'Dindigul': ['Madurai', 'Theni', 'Karur', 'Tiruppur'], 'Tiruchirappalli': ['Karur', 'Namakkal', 'Pudukkottai', 'Thanjavur', 'Perambalur'],
  'Chennai': ['Chengalpattu', 'Kanchipuram', 'Tiruvallur'], 'Chengalpattu': ['Chennai', 'Kanchipuram', 'Villupuram'], 'Thanjavur': ['Tiruchirappalli', 'Tiruvarur', 'Pudukkottai', 'Nagapattinam'],
  'Tirunelveli': ['Tenkasi', 'Thoothukudi', 'Kanniyakumari'], 'Vellore': ['Tirupathur', 'Ranipet', 'Tiruvannamalai'], 'Theni': ['Madurai', 'Dindigul'], 'Nilgiris': ['Coimbatore', 'Erode'],
  'Kanniyakumari': ['Tirunelveli', 'Tenkasi'], 'Cuddalore': ['Villupuram', 'Ariyalur', 'Nagapattinam'], 'Thoothukudi': ['Tirunelveli', 'Tenkasi', 'Virudhunagar']
};
const LOCKEYS = ['cityId', 'cityName', 'districtId', 'districtName', 'stateId', 'stateName'];
const getLoc = () => Object.fromEntries(LOCKEYS.map(k => [k, localStorage.getItem(k)]));
function setLoc(o) { LOCKEYS.forEach(k => o && o[k] != null && o[k] !== '' ? localStorage.setItem(k, o[k]) : localStorage.removeItem(k)); if (me && me.email) { try { localStorage.setItem('loc:' + me.email, JSON.stringify(o || {})); } catch (e) {} } }
function restoreUserLoc() { if (!me || !me.email || localStorage.getItem('cityId')) return; try { const o = JSON.parse(localStorage.getItem('loc:' + me.email) || 'null'); if (o && o.cityId) LOCKEYS.forEach(k => o[k] && localStorage.setItem(k, o[k])); } catch (e) {} }
function askLocationOnce(onChange) { if (me && me.role === 'CUSTOMER' && !localStorage.getItem('cityId') && !sessionStorage.getItem('locAsked')) { sessionStorage.setItem('locAsked', '1'); setTimeout(() => openCityModal(onChange), 400); } }

/* Theatres for a movie: own area first, then rest of the district, then nearby districts, then rest of the state */
async function listingNear(movieId, date) {
  const L = getLoc(), q = c => api(`/public/movies/${movieId}/listing?` + new URLSearchParams({ cityId: c, date })).catch(() => []);
  const tag = (arr, scope, from) => arr.map(t => ({ ...t, _scope: scope, _from: from }));
  let out = tag(await q(L.cityId), 'area', L.cityName);
  if (out.length || !L.districtId) return out;
  const towns = (await api('/public/locations?parentId=' + L.districtId).catch(() => [])).filter(c => String(c.id) !== String(L.cityId));
  const res = await Promise.all(towns.map(async c => tag(await q(c.id), 'district', c.name)));
  out = res.flat(); if (out.length || !L.stateId) return out;
  const districts = await api('/public/locations?parentId=' + L.stateId).catch(() => []), near = (NEAR[L.districtName] || []).map(n => n.toLowerCase());
  const pick = d => String(d.id) !== String(L.districtId);
  for (const [scope, set] of [['near', districts.filter(d => pick(d) && near.includes(d.name.toLowerCase()))], ['state', districts.filter(d => pick(d) && !near.includes(d.name.toLowerCase())).slice(0, 10)]]) {
    if (!set.length) continue;
    const parts = await Promise.all(set.map(async d => { const cs = await api('/public/locations?parentId=' + d.id).catch(() => []); return (await Promise.all(cs.map(async c => tag(await q(c.id), scope, d.name)))).flat(); }));
    out = parts.flat(); if (out.length) return out;
  }
  return out;
}
const SCOPE_TXT = { area: 'In your area', district: 'Elsewhere in your district', near: 'Nearby districts', state: 'Other places in your state' };

/* ---------- CSV export with column choice ---------- */
const plainText = h => String(h == null ? '' : h).replace(/<[^>]*>/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\s+/g, ' ').trim();
async function csvDialog(name, cols, getRows, note) {
  const rows = typeof getRows === 'function' ? await getRows() : getRows;
  const m = modal(`<h3>Export to CSV</h3><p class="muted">${rows.length} row(s)${note ? ' · ' + esc(note) : ' · exactly what is filtered on screen'}. Choose the details to include.</p>
    <div class="colpick">${cols.map((c, i) => `<label class="chk"><input type="checkbox" data-c="${i}" checked> ${esc(c[0])}</label>`).join('')}</div>
    <div class="actions"><button class="btn sec small" type="button" id="cx-all">Select all</button><button class="btn sec small" type="button" id="cx-none">Clear</button><span style="flex:1"></span><button class="btn sec" type="button" id="cx-x">Cancel</button><button class="btn" type="button" id="cx-go">Download CSV</button></div>`);
  const boxes = () => [...m.querySelectorAll('[data-c]')];
  m.querySelector('#cx-all').onclick = () => boxes().forEach(b => b.checked = true); m.querySelector('#cx-none').onclick = () => boxes().forEach(b => b.checked = false); m.querySelector('#cx-x').onclick = () => m.remove();
  m.querySelector('#cx-go').onclick = () => { const use = boxes().filter(b => b.checked).map(b => cols[Number(b.dataset.c)]); if (!use.length) return toast('Choose at least one detail', true);
    downloadCsv(name, [use.map(c => c[0]), ...rows.map(r => use.map(c => plainText(c[1](r))))]); m.remove(); toast('Exported ' + rows.length + ' rows'); };
}

/* ---------- type-to-filter dropdowns: any <select> with many options becomes searchable ---------- */
function enhanceSelect(sel) {
  if (sel.dataset.combo || sel.classList.contains('nocombo') || sel.options.length < 6 && !sel.hasAttribute('data-combo-force')) return; sel.dataset.combo = '1';
  const w = document.createElement('div'); w.className = 'combo'; const inp = document.createElement('input'); inp.type = 'text'; inp.autocomplete = 'off'; inp.className = 'combo-in'; const list = document.createElement('div'); list.className = 'combo-list'; list.hidden = true;
  sel.after(w); w.append(inp, list); sel.hidden = true;
  const label = () => { const o = sel.selectedOptions[0]; return o && o.value ? o.text : ''; };
  const sync = () => { inp.value = label(); inp.placeholder = sel.options[0] ? sel.options[0].text : 'Select'; inp.disabled = sel.disabled; w.classList.toggle('off', sel.disabled); };
  const open = f => { list.innerHTML = ''; const q = (f || '').toLowerCase(); [...sel.options].filter(o => !q || o.text.toLowerCase().includes(q)).slice(0, 80).forEach(o => { const b = document.createElement('button'); b.type = 'button'; b.textContent = o.value ? o.text : '— ' + o.text + ' —'; b.className = o.value === sel.value ? 'on' : ''; b.onmousedown = e => { e.preventDefault(); sel.value = o.value; sel.dispatchEvent(new Event('change', { bubbles: true })); sync(); list.hidden = true; }; list.append(b); }); if (!list.children.length) list.innerHTML = '<div class="muted small-note">No match</div>'; list.hidden = false; };
  inp.onfocus = () => { sync(); inp.select(); open(''); }; inp.oninput = () => open(inp.value); inp.onblur = () => { list.hidden = true; sync(); };
  inp.onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); const f = list.querySelector('button'); if (f) f.onmousedown(e); } if (e.key === 'Escape') inp.blur(); };
  new MutationObserver(sync).observe(sel, { childList: true, attributes: true, attributeFilter: ['disabled'] }); sync();
  const ch = () => sync(); sel.addEventListener('change', ch);
}
new MutationObserver(() => document.querySelectorAll('select:not([data-combo])').forEach(enhanceSelect)).observe(document.body, { childList: true, subtree: true });

/* ---------- user details: Super Admin sees everything, theatre sees only its own customers ---------- */

/* ---------- Theatre module: customers who booked at THIS theatre only ---------- */
async function pgTCustomers() {
  const list = await api('/theatre/bookings');
  const uniq = k => [...new Set(list.map(k).filter(Boolean))].sort(), times = [...new Set(list.map(b => String(b.showTime).slice(11, 16)))].sort();
  const opt = (a, all) => `<option value="">${all}</option>` + a.map(x => `<option value="${esc(x)}">${esc(x)}</option>`).join('');
  const t12 = t => new Date('2000-01-01T' + t).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  view(pageHead('Manage', 'Customers', 'Find who booked a movie, show, date or screen, or search one customer by name.', '<button class="btn sec small" id="cx" type="button">Export CSV</button>') +
    `<div class="card"><div class="filter-grid">
    <div><label>Customer name</label><input id="cq" placeholder="Type a name"></div>
    <div><label>Movie</label><select id="cm" class="nocombo">${opt(uniq(b => b.movieTitle), 'All movies')}</select></div>
    <div><label>Screen</label><select id="csr" class="nocombo">${opt(uniq(b => b.screenName), 'All screens')}</select></div>
    <div><label>Show time</label><select id="ct" class="nocombo"><option value="">Any time</option>${times.map(t => `<option value="${t}">${t12(t)}</option>`).join('')}</select></div>
    <div><label>Show date from</label><input type="date" id="cf"></div><div><label>Show date to</label><input type="date" id="cto"></div>
    <div><label>Booking status</label><select id="cst" class="nocombo"><option value="">Any</option><option>CONFIRMED</option><option>CANCELLED</option><option>PENDING_PAYMENT</option></select></div>
    <div><label>Sort</label><select id="cs" class="nocombo"><option value="recent">Latest booking</option><option value="spent">Most spent</option><option value="count">Most bookings</option><option value="name">Name A-Z</option></select></div></div>
    <div class="actions"><button class="btn sec small" id="creset" type="button">Clear filters</button></div><p class="muted" id="cc"></p></div><div id="cl"></div>`);
  const ok = b => { const d = String(b.showTime).slice(0, 10); return (!val('cm') || b.movieTitle === val('cm')) && (!val('csr') || b.screenName === val('csr')) && (!val('ct') || String(b.showTime).slice(11, 16) === val('ct')) && (!val('cf') || d >= val('cf')) && (!val('cto') || d <= val('cto')) && (!val('cst') || b.status === val('cst')); };
  const build = () => {
    const by = {}; list.filter(ok).forEach(b => { const k = b.customerId != null ? 'id' + b.customerId : 'n:' + b.customerName; (by[k] = by[k] || { name: b.customerName, id: b.customerId, rows: [] }).rows.push(b); });
    const q = val('cq').trim().toLowerCase(), sort = val('cs');
    return Object.values(by).map(p => ({ ...p, total: p.rows.filter(b => b.status === 'CONFIRMED').reduce((a, b) => a + Number(b.totalAmount || 0), 0), last: p.rows.reduce((a, b) => a > b.showTime ? a : b.showTime, '') }))
      .filter(p => !q || String(p.name).toLowerCase().includes(q))
      .sort((a, b) => sort === 'spent' ? b.total - a.total : sort === 'count' ? b.rows.length - a.rows.length : sort === 'name' ? String(a.name).localeCompare(b.name) : String(b.last).localeCompare(a.last));
  };
  let cur = [];
  const draw = () => { cur = build(); $('#cc').textContent = `${cur.length} customer(s) · ${cur.reduce((a, p) => a + p.rows.length, 0)} booking(s) match`;
    $('#cl').innerHTML = cur.length ? `<div class="card tablewrap"><table><tr><th>Customer</th><th>Bookings</th><th>Confirmed value</th><th>Latest show</th><th></th></tr>${cur.map((p, i) => `<tr><td><b>${esc(p.name)}</b></td><td>${p.rows.length}</td><td>${money(p.total)}</td><td>${fmt(p.last)}</td><td><button class="btn sec small" data-i="${i}" type="button">View</button></td></tr>`).join('')}</table></div>` : emptyBox('No customers match these filters.');
    document.querySelectorAll('#cl [data-i]').forEach(b => b.onclick = () => { const p = cur[Number(b.dataset.i)];
      const m = modal(`<div class="page-heading"><div><p class="eyebrow">Customer</p><h2>${esc(p.name)}</h2><p class="muted">Bookings at your theatre that match the current filters.</p></div><button class="btn sec small" id="pd-x" type="button">Close</button></div><div class="tablewrap"><table><tr><th>Ref</th><th>Movie</th><th>Screen</th><th>Show</th><th>Seats</th><th>Amount</th><th>Status</th></tr>${p.rows.map(r => `<tr><td>${esc(r.reference)}</td><td>${esc(r.movieTitle)}</td><td>${esc(r.screenName)}</td><td>${fmt(r.showTime)}</td><td>${esc(r.seats)}</td><td>${money(r.totalAmount)}</td><td>${badge(r.status)}</td></tr>`).join('')}</table></div>`);
      m.querySelector('#pd-x').onclick = () => m.remove(); }); };
  ['cq', 'cf', 'cto'].forEach(i => $('#' + i).oninput = draw); ['cm', 'csr', 'ct', 'cst', 'cs'].forEach(i => $('#' + i).onchange = draw);
  $('#creset').onclick = () => { ['cq', 'cf', 'cto'].forEach(i => $('#' + i).value = ''); ['cm', 'csr', 'ct', 'cst'].forEach(i => $('#' + i).value = ''); $('#cs').value = 'recent'; draw(); };
  $('#cx').onclick = () => csvDialog('cinebook-customers.csv', [['Customer', p => p.name], ['Bookings', p => p.rows.length], ['Confirmed bookings', p => p.rows.filter(b => b.status === 'CONFIRMED').length], ['Cancelled bookings', p => p.rows.filter(b => b.status === 'CANCELLED').length], ['Confirmed value', p => p.total], ['Latest show', p => p.last]], cur);
  draw();
}

/* ---------- small shared filter bar (typed search + selects) ---------- */
function fbarHtml(fs) { return `<div class="card"><div class="filter-grid">${fs.map(f => `<div><label>${f.label}</label>${f.type === 'select' ? `<select id="${f.id}"><option value="">${f.all || 'All'}</option>${f.opts.map(o => `<option value="${esc(o)}">${esc(o)}</option>`).join('')}</select>` : `<input id="${f.id}" placeholder="${esc(f.ph || '')}">`}</div>`).join('')}</div></div>`; }
function fbarWire(fs, cb) { fs.forEach(f => { const el = $('#' + f.id); if (el) el[f.type === 'select' ? 'onchange' : 'oninput'] = () => cb(); }); }
const fv = id => (($('#' + id) || {}).value || '').trim().toLowerCase();

let CUR_T = [], CUR_A = [], CUR_R = [];
const ORD = { area: 0, district: 1, near: 2, state: 3 };
const scopeHead = (t, prev) => t._scope && (prev ? prev._scope !== t._scope : t._scope !== 'area') ? `<h4 class="scope-h">${SCOPE_TXT[t._scope]}</h4>` : '';
function bindFinExport(s, g, r) {
  const a = $('#fxs'), b = $('#fxb');
  if (a) a.onclick = () => csvDialog('cinebook-finance-summary.csv', [['Metric', k => k.label], ['Value', k => k.value], ['Previous period', k => k.prev]], KPIS.filter(k => !k[0].startsWith('payouts') && (r !== 'a' || ['gross', 'refundsRequested', 'refundsPending', 'refundsCompleted', 'net', 'commission', 'earnings'].includes(k[0]))).map(k => ({ label: METRIC_TITLE[k[0]] || k[0], value: s.metrics[k[0]], prev: s.previous ? s.previous[k[0]] : '' })), 'summary for the chosen area and period');
  if (b) b.onclick = () => csvDialog('cinebook-finance-breakdown.csv', [['Group', x => x.label], ['Bookings', x => x.bookings], ['Tickets', x => x.tickets], ['Gross sales', x => x.gross], ['Commission', x => x.commission], ['Theatre earnings', x => x.earnings]], g, 'breakdown as currently shown');
}
async function pgTReviews() {
  const d = await api('/theatre/reviews'), s = d.summary, max = Math.max(...s.distribution, 1); let rq = '', rr = '', rp = '';
  view(pageHead('Engage', 'Customer reviews', 'Verified reviews from people who booked and watched. Customer names are shortened for privacy.', '<button class="btn sec small" id="rvx" type="button">Export CSV</button>')
    + `<div class="split"><div class="card rating-card"><div class="big-rating">${s.count ? s.average.toFixed(1) : '—'}</div><div class="gold">${stars(Math.round(s.average))}</div><p class="muted">${s.count} review${s.count === 1 ? '' : 's'}</p></div>
    <div class="card">${[5, 4, 3, 2, 1].map(i => `<div class="distrow"><span>${i}★</span><div class="distbar"><i style="width:${s.distribution[i - 1] / max * 100}%"></i></div><span>${s.distribution[i - 1]}</span></div>`).join('')}</div></div>`
    + fbarHtml([{ id: 'rq', label: 'Search', ph: 'Movie, customer or comment' }, { id: 'rr', label: 'Rating', type: 'select', all: 'All ratings', opts: ['5', '4', '3', '2', '1'] }, { id: 'rp', label: 'Reported', type: 'select', all: 'All', opts: ['Reported', 'Not reported'] }]) + '<div class="card" id="rvl"></div>');
  const cur = () => d.reviews.filter(r => (!rq || [r.movie, r.customer, r.comment].some(x => String(x || '').toLowerCase().includes(rq))) && (!rr || String(r.rating) === rr) && (!rp || (rp === 'Reported') === !!r.reported));
  const draw = () => { const l = cur(); $('#rvl').innerHTML = `<h3>Reviews <small class="muted">(${l.length})</small></h3>` + (l.length ? l.map(r => `<div class="review"><div><span class="gold">${stars(r.rating)}</span> <b>${esc(r.movie)}</b> <small class="muted">· ${esc(r.customer)} · ${fmt(r.createdAt)}</small></div>${r.comment ? `<p>${esc(r.comment)}</p>` : ''}${r.reported ? '<span class="badge PENDING">Reported to admin</span>' : `<button class="btn sec small" data-rep="${r.id}">Report this review</button>`}</div>`).join('') : emptyBox('No reviews match.'));
    document.querySelectorAll('[data-rep]').forEach(b => b.onclick = () => { const reason = prompt('Why should the Super Admin check this review? (e.g. abusive, fake, wrong theatre)'); if (reason) run(async () => { await api(`/theatre/reviews/${b.dataset.rep}/report`, { method: 'POST', body: { reason } }); toast('Reported'); pgTReviews(); }); }); };
  fbarWire([{ id: 'rq' }, { id: 'rr', type: 'select' }, { id: 'rp', type: 'select' }], () => { rq = fv('rq'); rr = ($('#rr').value || ''); rp = ($('#rp').value || ''); draw(); });
  $('#rvx').onclick = () => csvDialog('cinebook-reviews.csv', [['Date', r => r.createdAt], ['Movie', r => r.movie], ['Customer', r => r.customer], ['Rating', r => r.rating], ['Comment', r => r.comment], ['Reported', r => r.reported ? 'Yes' : 'No']], cur());
  draw();
}

/* =====================================================================
   v5 — simpler finance, activity reports, smarter filter bars,
   fuller language/genre lists, theatre movie editing
   ===================================================================== */
const FIN_STATE = { more: false };
function finKpiHtml(s, r) {
  const M = s.metrics || {}, P = s.previous, A = r === 'a';
  const MAIN = A ? ['gross', 'commission', 'refundsRequested', 'net', 'bookings'] : ['gross', 'commission', 'earnings', 'refundsRequested', 'bookings'];
  const MORE = [A ? 'earnings' : 'net', 'collected', 'failed', 'pending', 'cancelled', 'refundsPending', 'refundsCompleted', 'avgTicket', 'tickets'];
  const LAB = { gross: 'Ticket sales', commission: A ? 'Commission earned' : 'Commission deducted', earnings: A ? 'Theatre earnings' : 'Your earnings', refundsRequested: 'Refunds', net: 'Net after refunds', bookings: 'Bookings', collected: 'Payments collected', failed: 'Failed payments', pending: 'Pending payments', cancelled: 'Cancelled bookings', refundsPending: 'Refunds pending', refundsCompleted: 'Refunds completed', avgTicket: 'Average ticket value', tickets: 'Tickets sold' };
  const TONE = { gross: '#D99A9C', commission: '#8CC3DC', earnings: '#7fb596', net: '#7fb596', refundsRequested: '#E5A98A', bookings: '#C9B0DB' };
  const kind = k => (KPIS.find(x => x[0] === k) || [])[3], cell = k => M[k] || { count: 0, value: 0 };
  const val = k => { const c = cell(k), kd = kind(k); return kd === 'money' || kd === 'avg' ? money(c.value) : kd === 'tickets' ? fmtNum(c.value) : fmtNum(c.count); };
  const sub = k => kind(k) === 'money' ? fmtNum(cell(k).count) + ' records' : kind(k) === 'pay' ? money(cell(k).value) : '';
  const num = (k, o) => { const c = o && o[k]; if (!c) return null; const kd = kind(k); return kd === 'money' || kd === 'avg' || kd === 'tickets' ? Number(c.value) : Number(c.count); };
  const delta = k => { if (!P) return ''; const a = num(k, M) || 0, b = num(k, P); if (b == null) return ''; if (b === 0) return a === 0 ? '' : '<i class="delta up">new</i>'; return `<i class="delta ${a >= b ? 'up' : 'down'}">${a >= b ? '▲' : '▼'} ${Math.abs((a - b) / b * 100).toFixed(0)}% vs previous</i>`; };
  return `<div class="fk-row">${MAIN.map(k => `<a class="fk" style="--c:${TONE[k]}" href="#/${r}/finance/m/${k}"><span>${LAB[k]}</span><b>${val(k)}</b>${sub(k) ? `<small>${sub(k)}</small>` : ''}${delta(k)}</a>`).join('')}</div>
    <div class="fk-toggle"><button class="btn sec small" id="fk-toggle" type="button">${FIN_STATE.more ? 'Hide details' : 'More details'}</button></div>
    <div class="card tablewrap fk-more" ${FIN_STATE.more ? '' : 'hidden'}><table><tr><th>Measure</th><th>Amount / count</th><th>Records</th><th></th></tr>${MORE.map(k => `<tr><td>${LAB[k]}</td><td><b>${val(k)}</b>${delta(k) ? ' ' + delta(k) : ''}</td><td>${fmtNum(cell(k).count)}</td><td><a class="text-link" href="#/${r}/finance/m/${k}">View records</a></td></tr>`).join('')}</table></div>`;
}
function wireFinMore() { const b = $('#fk-toggle'); if (b) b.onclick = () => { FIN_STATE.more = !FIN_STATE.more; $('.fk-more').hidden = !FIN_STATE.more; b.textContent = FIN_STATE.more ? 'Hide details' : 'More details'; }; }

/* ---------- activity report: pick who + which day/range, get everything ---------- */
const periodRange = p => { const d = new Date(), iso = x => isoD(x), day = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  if (p === 'today') return [iso(day), iso(day)]; if (p === 'yesterday') { const y = new Date(day); y.setDate(y.getDate() - 1); return [iso(y), iso(y)]; }
  if (p === 'week') { const s = new Date(day); s.setDate(s.getDate() - ((s.getDay() + 6) % 7)); const e = new Date(s); e.setDate(e.getDate() + 6); return [iso(s), iso(e)]; }
  if (p === 'month') return [iso(new Date(d.getFullYear(), d.getMonth(), 1)), iso(new Date(d.getFullYear(), d.getMonth() + 1, 0))]; return ['', '']; };
async function activityExport(role) {
  const isA = role === 'a';
  const [theatres, users] = isA ? await Promise.all([api('/admin/theatres?' + new URLSearchParams({ q: '', status: '' })).catch(() => []), api('/admin/users').catch(() => [])]) : [[], []];
  const m = modal(`<h3>Export activity</h3><p class="muted">${isA ? 'Choose who and which period. You get everything they did in one file: actions, bookings, payments and refunds.' : 'Everything that happened at your theatre in the period you choose: bookings, refunds and shows.'}</p>
    <div class="row">${isA ? `<div><label>Who</label><select id="ae-k" class="nocombo"><option value="all">Everyone</option><option value="theatre">One theatre</option><option value="user">One user</option></select></div><div id="ae-sw"></div>` : '<div><label>Customer (optional)</label><input id="ae-cu" placeholder="Type a customer name"></div>'}
    <div><label>Period</label><select id="ae-p" class="nocombo">${[['all', 'All time'], ['today', 'Today'], ['yesterday', 'Yesterday'], ['week', 'This week'], ['month', 'This month'], ['custom', 'A day or date range…']].map(([v, l]) => `<option value="${v}">${l}</option>`).join('')}</select></div></div>
    <div class="row" id="ae-d" hidden><div><label>From</label><input type="date" id="ae-f"></div><div><label>To (same date for one day)</label><input type="date" id="ae-t"></div></div>
    <div class="actions"><span style="flex:1"></span><button class="btn sec" id="ae-x" type="button">Cancel</button><button class="btn" id="ae-go" type="button">Continue</button></div>`);
  const $m = s => m.querySelector(s); (m.querySelector('.modal') || m).classList.add('wide');
  const swap = () => { if (!isA) return; const k = $m('#ae-k').value, w = $m('#ae-sw'); w.innerHTML = k === 'theatre' ? `<label>Theatre</label><select id="ae-th" data-combo-force><option value="">Choose a theatre</option>${theatres.map(t => `<option value="${t.id}">${esc(t.name)} — ${esc(t.city)}</option>`).join('')}</select>` : k === 'user' ? `<label>User</label><select id="ae-us" data-combo-force><option value="">Choose a user</option>${users.map(u => `<option value="${esc(u.email)}">${esc(u.name)} — ${esc(u.email)}</option>`).join('')}</select>` : ''; };
  if (isA) { $m('#ae-k').onchange = swap; swap(); }
  $m('#ae-p').onchange = () => { $m('#ae-d').hidden = $m('#ae-p').value !== 'custom'; }; $m('#ae-x').onclick = () => m.remove();
  $m('#ae-go').onclick = () => run(async () => {
    const p = $m('#ae-p').value; let [from, to] = p === 'custom' ? [$m('#ae-f').value, $m('#ae-t').value || $m('#ae-f').value] : periodRange(p);
    if (p === 'custom' && !from) throw new Error('Pick a date');
    const inR = d => { const x = String(d || '').slice(0, 10); return !x ? !from : (!from || x >= from) && (!to || x <= to); }, rows = [];
    if (isA) {
      const k = $m('#ae-k').value, th = k === 'theatre' ? theatres.find(t => String(t.id) === $m('#ae-th').value) : null, us = k === 'user' ? users.find(u => u.email === $m('#ae-us').value) : null;
      if (k === 'theatre' && !th) throw new Error('Choose a theatre'); if (k === 'user' && !us) throw new Error('Choose a user');
      const audit = await api('/admin/audit').catch(() => []);
      audit.filter(a => inR(a.at) && (k === 'all' || (th && (String(a.actorEmail).toLowerCase() === String(th.ownerEmail).toLowerCase() || String(a.details || '').toLowerCase().includes(th.name.toLowerCase()))) || (us && String(a.actorEmail).toLowerCase() === us.email.toLowerCase())))
        .forEach(a => rows.push({ type: 'Action', when: a.at, who: a.actorEmail, ref: '', theatre: th ? th.name : '', movie: '', details: a.action + (a.details ? ': ' + a.details : ''), amount: '', status: '' }));
      const refs = new Set(), bk = [];
      for (let pg = 0; pg < 50; pg++) { const q = new URLSearchParams({ size: 200, page: pg }); if (from) { q.set('from', from); q.set('to', to); } if (th) q.set('theatreId', th.id); if (us) q.set('q', us.email); const c = await api('/admin/bookings?' + q); bk.push(...(c.rows || [])); if (bk.length >= c.total) break; }
      bk.filter(b => !us || String(b.customerEmail).toLowerCase() === us.email.toLowerCase()).forEach(b => { refs.add(b.reference);
        rows.push({ type: 'Booking', when: b.createdAt, who: b.customer + (b.customerEmail ? ' <' + b.customerEmail + '>' : ''), ref: b.reference, theatre: b.theatre, movie: b.movie, details: 'Show ' + String(b.showTime).replace('T', ' ') + ' · seats ' + b.seats, amount: b.amount, status: b.status });
        if (b.refundAmount != null) rows.push({ type: 'Refund', when: b.cancelledAt || b.createdAt, who: b.customer, ref: b.reference, theatre: b.theatre, movie: b.movie, details: 'Refund ' + (b.refundStatus || ''), amount: b.refundAmount, status: b.refundStatus || '' }); });
      const pays = await api('/admin/payments').catch(() => []);
      (Array.isArray(pays) ? pays : pays.rows || []).filter(x => inR(x.createdAt) && (k === 'all' || refs.has(x.bookingReference))).forEach(x => rows.push({ type: 'Payment', when: x.createdAt, who: '', ref: x.bookingReference, theatre: '', movie: '', details: [x.mode, x.transactionRef, x.message].filter(Boolean).join(' · '), amount: x.amount, status: x.status }));
    } else {
      const cu = (($m('#ae-cu') || {}).value || '').trim().toLowerCase(), [bk, sh] = await Promise.all([api('/theatre/bookings'), api('/theatre/shows').catch(() => [])]);
      bk.filter(b => inR(b.showTime) && (!cu || String(b.customerName).toLowerCase().includes(cu))).forEach(b => { rows.push({ type: 'Booking', when: b.showTime, who: b.customerName, ref: b.reference, theatre: b.theatreName, movie: b.movieTitle, details: b.screenName + ' · seats ' + b.seats, amount: b.totalAmount, status: b.status });
        if (b.refundAmount != null) rows.push({ type: 'Refund', when: b.showTime, who: b.customerName, ref: b.reference, theatre: b.theatreName, movie: b.movieTitle, details: 'Refund ' + (b.refundStatus || ''), amount: b.refundAmount, status: b.refundStatus || '' }); });
      if (!cu) sh.filter(x => inR(x.startTime)).forEach(x => rows.push({ type: 'Show', when: x.startTime, who: '', ref: '', theatre: x.theatreName, movie: x.movieTitle, details: x.screenName + ' · ' + (x.audioLanguage || '') + ' ' + (x.dimension || '') + ' · ' + x.availableSeats + ' seats free', amount: x.regularPrice, status: x.status }));
    }
    rows.sort((a, b) => String(b.when).localeCompare(String(a.when))); m.remove();
    csvDialog('cinebook-activity-report.csv', [['Type', r => r.type], ['When', r => String(r.when || '').replace('T', ' ')], ['Who', r => r.who], ['Booking ref', r => r.ref], ['Theatre', r => r.theatre], ['Movie', r => r.movie], ['Details', r => r.details], ['Amount', r => r.amount], ['Status', r => r.status]], rows, (from ? from + (to && to !== from ? ' to ' + to : '') : 'all time') + ' · one row per action, booking, refund, payment or show');
  });
}

/* ---------- filter bars: first 4 filters shown, rest folded; clear-all; chips; date presets ---------- */
function enhanceFilterGrid(g) {
  if (g.dataset.fx || g.closest('.modal')) return;
  const ctlOf = c => c.querySelector('input:not([type=checkbox]):not([type=radio]),select'), cells = [...g.children].filter(ctlOf);
  if (cells.length < 3) return; g.dataset.fx = '1';
  const extra = cells.slice(4); let more = null;
  if (extra.length) { more = document.createElement('div'); more.className = 'filter-grid fmore'; more.hidden = true; extra.forEach(c => more.appendChild(c)); g.after(more); }
  const grids = more ? [g, more] : [g], all = () => grids.flatMap(x => [...x.children].filter(ctlOf)).map(c => ({ c, el: ctlOf(c) }));
  const dfl = el => el.tagName === 'SELECT' ? ((([...el.options].find(o => o.defaultSelected)) || el.options[0] || {}).value || '') : el.defaultValue;
  const isSet = el => el.value !== '' && el.value !== dfl(el);
  const fire = el => { el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); };
  const reset = el => { el.value = dfl(el); fire(el); };
  const tools = document.createElement('div'); tools.className = 'ftools'; (more || g).after(tools);
  const dates = [...g.querySelectorAll('input[type=date]'), ...(more ? more.querySelectorAll('input[type=date]') : [])], hasPeriod = [...g.querySelectorAll('select')].some(s => [...s.options].some(o => /today|this month|this week/i.test(o.text)));
  tools.innerHTML = `${extra.length ? `<button type="button" class="btn sec small" data-ft="more">More filters (${extra.length})</button>` : ''}${dates.length >= 2 && !hasPeriod ? ['Today', 'Yesterday', 'This week', 'This month'].map(l => `<button type="button" class="chip" data-fp="${l}">${l}</button>`).join('') : ''}<button type="button" class="btn sec small" data-ft="clear" hidden>Clear all</button><span class="fchips"></span>`;
  const chips = () => { const act = all().filter(x => isSet(x.el)); tools.querySelector('[data-ft=clear]').hidden = !act.length; tools.querySelector('.fchips').innerHTML = act.map((x, i) => { const lab = (x.c.querySelector('label') || {}).textContent || 'Filter', v = x.el.tagName === 'SELECT' ? (x.el.selectedOptions[0] || {}).text : x.el.value; return `<span class="pill">${esc(lab.trim())}: ${esc(v)}<button type="button" data-fr="${i}" aria-label="Remove">×</button></span>`; }).join(''); };
  tools.onclick = e => { const b = e.target.closest('button,.chip'); if (!b) return;
    if (b.dataset.ft === 'more') { more.hidden = !more.hidden; b.textContent = more.hidden ? `More filters (${extra.length})` : 'Fewer filters'; }
    else if (b.dataset.ft === 'clear') { all().forEach(x => { if (isSet(x.el)) reset(x.el); }); }
    else if (b.dataset.fr != null) { const act = all().filter(x => isSet(x.el)); if (act[Number(b.dataset.fr)]) reset(act[Number(b.dataset.fr)].el); }
    else if (b.dataset.fp) { const p = { 'Today': 'today', 'Yesterday': 'yesterday', 'This week': 'week', 'This month': 'month' }[b.dataset.fp], [f, t] = periodRange(p); dates[0].value = f; dates[1].value = t; fire(dates[0]); fire(dates[1]); }
    setTimeout(chips, 0); };
  grids.forEach(x => { x.addEventListener('input', () => setTimeout(chips, 0)); x.addEventListener('change', () => setTimeout(chips, 0)); }); chips();
}
new MutationObserver(() => document.querySelectorAll('#app .filter-grid:not([data-fx])').forEach(enhanceFilterGrid)).observe(document.body, { childList: true, subtree: true });

/* ---------- language / genre facets: present ones with counts, plus a fuller list ---------- */
const countBy = (list, k) => { const c = new Map(); list.forEach(m => splitCsv(m[k]).forEach(x => c.set(x, (c.get(x) || 0) + 1))); return c; };
function facetHtml(id, list, k, suggest) {
  const present = [...countBy(list, k).entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])), have = new Set(present.map(x => x[0].toLowerCase())), extra = suggest.filter(x => !have.has(x.toLowerCase()));
  const chip = (v, n, dim) => `<button type="button" class="chip${dim ? ' dim' : ''}" data-g="${id}" data-v="${esc(v)}"${dim ? ' data-dim="1" hidden' : ''}>${esc(v)}<i class="cnt">${n}</i></button>`;
  return `<input class="fsearch" data-for="${id}" placeholder="Search ${k}…" aria-label="Search ${k}"><div class="chips" id="fx-${id}">${present.map(([v, n]) => chip(v, n, false)).join('') || '<span class="muted">None yet</span>'}${extra.map(v => chip(v, 0, true)).join('')}</div>${extra.length ? `<button type="button" class="text-link" data-more="${id}">Show ${extra.length} more ${k === 'language' ? 'languages' : 'genres'}</button>` : ''}`;
}
document.addEventListener('input', e => { const i = e.target.closest ? e.target.closest('.fsearch') : null; if (!i) return; const q = i.value.trim().toLowerCase(), box = document.getElementById('fx-' + i.dataset.for); box.querySelectorAll('.chip').forEach(c => { const hit = !q || c.dataset.v.toLowerCase().includes(q); c.hidden = !hit || (!!c.dataset.dim && !q && !box.dataset.open); }); });
document.addEventListener('click', e => { const b = e.target.closest ? e.target.closest('[data-more]') : null; if (!b) return; const box = document.getElementById('fx-' + b.dataset.more); b.dataset.t = b.dataset.t || b.textContent; box.dataset.open = box.dataset.open ? '' : '1'; box.querySelectorAll('.chip[data-dim]').forEach(c => c.hidden = !box.dataset.open); b.textContent = box.dataset.open ? 'Show fewer' : b.dataset.t; });

/* ---------- theatre: edit a movie its own theatre added ---------- */
async function editTheatreMovie(id) {
  const mv = await api('/public/movies/' + id);
  const m = modal(`<h3>Edit “${esc(mv.title)}”</h3><p class="muted">You can edit any movie running on your screens. Changes appear everywhere straight away, including for existing bookings.</p>${movieForm(mv)}`);
  (m.querySelector('.modal') || m).classList.add('wide');
  const st = m.querySelector('#ms'); if (st) st.closest('div').hidden = true;
  m.querySelector('#save-movie').onclick = () => run(async () => { const data = readMovieForm(); data.posterUrl = await uploadSelectedPoster(); await api('/theatre/movies/' + id, { method: 'PUT', body: data }); m.remove(); toast('Movie updated'); pgTMovies(); });
}
document.addEventListener('click', e => { const b = e.target.closest ? e.target.closest('[data-edit-movie]') : null; if (b) run(() => editTheatreMovie(b.dataset.editMovie)); });
let CUR_B = [];

/* =====================================================================
   v6 — finance as a statement (money only for Super Admin)
   ===================================================================== */
function statementHtml(s, r) {
  const M = s.metrics || {}, P = s.previous, A = r === 'a', v = k => Number((M[k] || {}).value || 0), pv = k => P && P[k] ? Number(P[k].value || 0) : null;
  const rows = A ? [['Ticket sales', 'gross', 1, 'Confirmed bookings, before refunds'], ['Refunds', 'refundsRequested', -1, 'Returned to customers'], ['Net ticket sales', 'net', 0, '', 'total'], ['Platform commission', 'commission', 0, 'Your income from these sales', 'key'], ['Share for theatres', 'earnings', 0, 'Payable to theatres']]
    : [['Ticket sales', 'gross', 1, 'Confirmed bookings, before refunds'], ['Refunds', 'refundsRequested', -1, 'Returned to customers'], ['Net ticket sales', 'net', 0, '', 'total'], ['Commission deducted', 'commission', -1, 'Platform fee'], ['Your earnings', 'earnings', 0, 'What you receive', 'key']];
  const chg = (a, b) => b == null ? '' : b === 0 ? (a === 0 ? '—' : 'new') : `<span class="${a >= b ? 'up' : 'down'}">${a >= b ? '▲' : '▼'} ${Math.abs((a - b) / b * 100).toFixed(0)}%</span>`;
  const com = v('commission'), sh = v('earnings'), tot = com + sh || 1;
  const pay = !A ? `<p class="muted small-note">Payments: ${fmtNum((M.collected || {}).count || 0)} collected · ${fmtNum((M.pending || {}).count || 0)} pending · ${fmtNum((M.failed || {}).count || 0)} failed. <a href="#/t/finance/m/collected" class="text-link">View payments</a></p>` : '';
  return `<div class="stmt"><div class="card tablewrap"><table class="ledger"><tr><th>Statement</th><th class="num">This period</th>${P ? '<th class="num">Previous</th><th class="num">Change</th>' : ''}</tr>
    ${rows.map(([l, k, sg, hint, cls]) => `<tr class="${cls || ''}"><td><a href="#/${r}/finance/m/${k}">${l}</a>${hint ? `<small>${hint}</small>` : ''}</td><td class="num">${sg < 0 ? '− ' : ''}${money(v(k))}</td>${P ? `<td class="num muted">${pv(k) == null ? '—' : money(pv(k))}</td><td class="num">${chg(v(k), pv(k))}</td>` : ''}</tr>`).join('')}</table>${pay}</div>
    <div class="card"><h3>Where the money goes</h3><div class="splitbar"><i style="width:${com / tot * 100}%;background:#8CC3DC"></i><i style="width:${sh / tot * 100}%;background:#7fb596"></i></div>
    <ul class="splitkey"><li><i style="background:#8CC3DC"></i>${A ? 'Platform commission' : 'Commission'}<b>${money(com)}</b><small>${(com / tot * 100).toFixed(0)}%</small></li><li><i style="background:#7fb596"></i>${A ? 'Theatres' : 'You keep'}<b>${money(sh)}</b><small>${(sh / tot * 100).toFixed(0)}%</small></li></ul></div></div>`;
}
async function pgAReports() {
  const [d, cmp] = await Promise.all([api('/admin/dashboard'), api('/admin/complaints').catch(() => [])]);
  const openC = (Array.isArray(cmp) ? cmp : []).filter(c => !['RESOLVED', 'CLOSED', 'REJECTED'].includes(String(c.status))).length;
  view(pageHead('INSIGHTS', 'Reports', `Platform income for the area and period you choose. ${fmtNum(d.theatresTotal)} theatres · ${fmtNum(d.customers)} customers · ${fmtNum(d.movies)} movies. Customer and theatre details are in Users, Theatres and the Activity report.`)
    + '<div id="fbar"></div><h3 class="sec-title">Income</h3><div id="rk"></div><h3 class="sec-title">Needs your attention</h3><div id="rn" class="attn"></div><h3 class="sec-title">More</h3><div class="action-row"><a class="action-card" href="#/a/finance"><b>₹</b><span>Full finance &amp; analytics</span><small>Breakdown by place, theatre, movie and time</small></a><a class="action-card" href="#/a/activity"><b>⌚</b><span>Activity &amp; exports</span><small>Everything a person or theatre did, by date</small></a></div>');
  const draw = async () => {
    const s = await api('/admin/finance/summary?' + fsParams('a'));
    $('#rk').innerHTML = statementHtml(s, 'a');
    const items = [[d.theatresPending, 'theatre applications to verify', '#/a/theatres'], [((s.metrics || {}).refundsPending || {}).count || 0, 'refunds waiting to be paid', '#/a/refunds'], [openC, 'open complaints', '#/a/complaints']];
    $('#rn').innerHTML = items.map(([n, l, h]) => `<a class="attn-row ${n ? 'hot' : ''}" href="${h}"><b>${fmtNum(n)}</b><span>${l}</span><i>${n ? 'Open →' : 'All clear'}</i></a>`).join('');
  };
  await finBar('a', $('#fbar'), draw); await draw();
}

/* =====================================================================
   v7 — person / theatre details + "Export everything" (date range, ZIP of CSVs)
   ===================================================================== */
const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc32 = u8 => { let c = 0xFFFFFFFF; for (let i = 0; i < u8.length; i++) c = CRC[(c ^ u8[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
function makeZip(files) {
  const enc = new TextEncoder(), parts = [], cen = []; let off = 0;
  const u16 = n => [n & 255, (n >> 8) & 255], u32 = n => [n & 255, (n >> 8) & 255, (n >> 16) & 255, (n >>> 24) & 255];
  files.forEach(f => { const name = enc.encode(f.name), data = enc.encode(f.text), crc = crc32(data);
    const lh = new Uint8Array([0x50, 0x4b, 3, 4, ...u16(20), ...u16(0x0800), ...u16(0), ...u16(0), ...u16(0x21), ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(name.length), ...u16(0)]);
    parts.push(lh, name, data);
    cen.push(new Uint8Array([0x50, 0x4b, 1, 2, ...u16(20), ...u16(20), ...u16(0x0800), ...u16(0), ...u16(0), ...u16(0x21), ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(name.length), ...u16(0), ...u16(0), ...u16(0), ...u16(0), ...u32(0), ...u32(off)]), name);
    off += lh.length + name.length + data.length; });
  const cenSize = cen.reduce((a, c) => a + c.length, 0);
  const end = new Uint8Array([0x50, 0x4b, 5, 6, 0, 0, 0, 0, ...u16(files.length), ...u16(files.length), ...u32(cenSize), ...u32(off), 0, 0]);
  return new Blob([...parts, ...cen, end], { type: 'application/zip' });
}
const csvText = rows => '\ufeff' + rows.map(r => r.map(v => { let x = String(v == null ? '' : v); if (/^[=+\-@]/.test(x) && isNaN(Number(x))) x = "'" + x; return '"' + x.replace(/"/g, '""') + '"'; }).join(',')).join('\r\n');
function saveBlob(name, blob) { const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000); }
const isPrim = v => v == null || ['string', 'number', 'boolean'].includes(typeof v);
function genericSection(name, list) { const keys = []; list.forEach(o => Object.keys(o || {}).forEach(k => { if (isPrim(o[k]) && !keys.includes(k)) keys.push(k); })); return { name, rows: [keys.map(k => k.replace(/([A-Z])/g, ' $1').replace(/^./, c => c.toUpperCase())), ...list.map(o => keys.map(k => String(o[k] == null ? '' : o[k]).replace('T', k.match(/At$|Time$|date$/i) ? ' ' : 'T')))] }; }
const profileSection = ent => ({ name: 'Profile', rows: [['Field', 'Value'], ...Object.entries(ent).filter(([, v]) => isPrim(v)).map(([k, v]) => [k.replace(/([A-Z])/g, ' $1').replace(/^./, c => c.toUpperCase()), v == null ? '' : v])] });

async function collectEntity(kind, ent, from, to) {
  const inR = d => { const x = String(d || '').slice(0, 10); return !from || (x && x >= from && (!to || x <= to)); }, lc = x => String(x || '').toLowerCase(), S = [profileSection(ent)];
  const dateOf = o => o.at || o.createdAt || o.startTime || o.addedAt || o.date || '';
  const email = kind === 'theatre' ? ent.ownerEmail : ent.email, audit = await api('/admin/audit').catch(() => []);
  S.push(genericSection('Activity', audit.filter(a => inR(a.at) && (lc(a.actorEmail) === lc(email) || (kind === 'theatre' && lc(a.details).includes(lc(ent.name)))))));
  if (kind === 'theatre' || ent.role === 'CUSTOMER') {
    const bk = []; for (let pg = 0; pg < 50; pg++) { const q = new URLSearchParams({ size: 200, page: pg }); if (from) { q.set('from', from); q.set('to', to || from); } if (kind === 'theatre') q.set('theatreId', ent.id); else q.set('q', ent.email); const c = await api('/admin/bookings?' + q).catch(() => ({ rows: [], total: 0 })); bk.push(...(c.rows || [])); if (bk.length >= (c.total || 0)) break; }
    const mine = kind === 'theatre' ? bk : bk.filter(b => lc(b.customerEmail) === lc(ent.email)), refs = new Set(mine.map(b => b.reference));
    S.push(genericSection('Bookings', mine));
    S.push(genericSection('Refunds', mine.filter(b => b.refundAmount != null).map(b => ({ reference: b.reference, customer: b.customer, theatre: b.theatre, movie: b.movie, showTime: b.showTime, refundAmount: b.refundAmount, refundStatus: b.refundStatus, cancelledAt: b.cancelledAt }))));
    const pays = await api('/admin/payments').catch(() => []); S.push(genericSection('Payments', (Array.isArray(pays) ? pays : pays.rows || []).filter(p => refs.has(p.bookingReference) && inR(p.createdAt))));
  }
  const rv = await api('/admin/reviews').catch(() => []), rvl = Array.isArray(rv) ? rv : rv.reviews || [];
  S.push(genericSection('Reviews', rvl.filter(r => inR(r.createdAt) && (kind === 'theatre' ? String(r.theatreId) === String(ent.id) : lc(r.customer) === lc(ent.name)))));
  const cm = await api('/admin/complaints').catch(() => []);
  S.push(genericSection('Complaints', (Array.isArray(cm) ? cm : []).filter(c => inR(c.createdAt) && (kind === 'theatre' ? lc(c.theatre) === lc(ent.name) : lc(c.from) === lc(ent.name)))));
  if (kind === 'theatre') {
    const [sc, sh, mv, hi] = await Promise.all([api(`/admin/theatres/${ent.id}/screens`).catch(() => []), api(`/admin/theatres/${ent.id}/shows`).catch(() => []), api(`/admin/theatres/${ent.id}/movies`).catch(() => []), api(`/admin/theatres/${ent.id}/history`).catch(() => [])]);
    S.push(genericSection('Screens', sc)); S.push(genericSection('Movies', mv.filter(x => !from || inR(x.startDate) || inR(x.endDate) || (x.startDate <= from && (!x.endDate || x.endDate >= from))))); S.push(genericSection('Shows', sh.filter(x => inR(x.startTime)))); S.push(genericSection('Status history', hi.filter(x => inR(dateOf(x)))));
  }
  return S.filter(s => s.name === 'Profile' || s.rows.length > 1);
}
function exportEverything(kind, ent) {
  const m = modal(`<h3>Export everything — ${esc(ent.name)}</h3><p class="muted">Profile, activity, bookings, payments, refunds, reviews and complaints${kind === 'theatre' ? ', plus screens, movies, shows and status history' : ''}. Choose the period.</p>
    <div class="row"><div><label>Period</label><select id="ee-p" class="nocombo">${[['all', 'All time'], ['today', 'Today'], ['yesterday', 'Yesterday'], ['week', 'This week'], ['month', 'This month'], ['custom', 'A day or date range…']].map(([v, l]) => `<option value="${v}">${l}</option>`).join('')}</select></div>
    <div><label>File</label><select id="ee-f" class="nocombo"><option value="zip">ZIP — one CSV per section</option><option value="one">One combined CSV</option></select></div></div>
    <div class="row" id="ee-d" hidden><div><label>From</label><input type="date" id="ee-a"></div><div><label>To (same date for one day)</label><input type="date" id="ee-b"></div></div>
    <div class="actions"><span style="flex:1"></span><button class="btn sec" id="ee-x" type="button">Cancel</button><button class="btn" id="ee-go" type="button">Download</button></div>`);
  const q = s => m.querySelector(s); q('#ee-p').onchange = () => { q('#ee-d').hidden = q('#ee-p').value !== 'custom'; }; q('#ee-x').onclick = () => m.remove();
  q('#ee-go').onclick = () => run(async () => {
    const p = q('#ee-p').value; let [f, t] = p === 'custom' ? [q('#ee-a').value, q('#ee-b').value || q('#ee-a').value] : periodRange(p); if (p === 'custom' && !f) throw new Error('Pick a date');
    const S = await collectEntity(kind, ent, f, t), n = S.reduce((a, s) => a + s.rows.length - 1, 0), base = 'cinebook-' + String(ent.name).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') + (f ? '-' + f + (t && t !== f ? '-to-' + t : '') : '');
    if (S.length <= 1 && !n) { toast('Nothing found for this period', true); return; }
    if (q('#ee-f').value === 'zip') saveBlob(base + '.zip', makeZip(S.map(s => ({ name: s.name.toLowerCase().replace(/\s+/g, '-') + '.csv', text: csvText(s.rows) }))));
    else saveBlob(base + '.csv', new Blob([S.map(s => csvText([[s.name.toUpperCase()]]).replace('\ufeff', '') + '\r\n' + csvText(s.rows).replace('\ufeff', '')).join('\r\n\r\n')], { type: 'text/csv;charset=utf-8' }));
    m.remove(); toast('Exported ' + (S.length) + ' sections, ' + n + ' rows');
  });
}
async function openEntityDetail(kind, ent) {
  const m = modal('<div class="udetail"><div class="loader">Loading…</div></div>'); (m.querySelector('.modal') || m).classList.add('wide');
  try {
    const S = await collectEntity(kind, ent, '', ''), by = n => S.find(s => s.name === n), cnt = n => by(n) ? by(n).rows.length - 1 : 0; let tab = S.find(s => s.name !== 'Profile') ? S.find(s => s.name !== 'Profile').name : 'Profile';
    const draw = () => { const sec = by(tab), rows = sec.rows;
      m.querySelector('.udetail').innerHTML = `<div class="page-heading"><div><p class="eyebrow">${kind === 'theatre' ? 'Theatre' : esc(String(ent.role || 'User').replace('_', ' '))}</p><h2>${esc(ent.name)}</h2><p class="muted">${esc(kind === 'theatre' ? [ent.address, ent.city].filter(Boolean).join(', ') + ' · owner ' + (ent.ownerName || '') : ent.email + ' · ' + (ent.phone || 'no phone'))}</p></div><div class="head-actions"><button class="btn small" id="ud-ex" type="button">Export everything</button><button class="btn sec small" id="ud-x" type="button">Close</button></div></div>
        ${tabsHtml('udt', S.map(s => [s.name, s.name, s.name === 'Profile' ? '' : s.rows.length - 1]), tab)}
        <div class="tablewrap">${rows.length > 1 || tab === 'Profile' ? `<table><tr>${rows[0].map(h => `<th>${esc(h)}</th>`).join('')}</tr>${rows.slice(1, 201).map(r => `<tr>${r.map(c => `<td>${esc(String(c).slice(0, 120))}</td>`).join('')}</tr>`).join('')}</table>${rows.length > 201 ? `<p class="muted small-note">Showing the first 200 of ${rows.length - 1}. Use Export everything for the full list.</p>` : ''}` : emptyBox('Nothing recorded.')}</div>`;
      m.querySelector('#ud-x').onclick = () => m.remove(); m.querySelector('#ud-ex').onclick = () => exportEverything(kind, ent); wireTabs('udt', k => { tab = k; draw(); }); };
    draw();
  } catch (e) { m.querySelector('.udetail').innerHTML = `<p class="err">${esc(e.message)}</p>`; }
}
const openUserDetail = u => openEntityDetail('user', u);
async function openTheatreEntity(id) { const l = await api('/admin/theatres?' + new URLSearchParams({ q: '', status: '' })), t = l.find(x => x.id === id); if (t) openEntityDetail('theatre', t); }

/* ===== CineBook: rewards and "for you" rails ===== */
(() => {
  const LS = localStorage, root = document.documentElement;
  const seen = () => { const m = (location.hash || '').match(/^#\/movie\/(\d+)$/); if (!m) return; const l = JSON.parse(LS.getItem('cbRecent') || '[]').filter(x => x !== +m[1]); l.unshift(+m[1]); LS.setItem('cbRecent', JSON.stringify(l.slice(0, 12))); };
  const rails = async hero => {
    const ids = JSON.parse(LS.getItem('cbRecent') || '[]'); if (!ids.length) return;
    const all = (await api('/public/movies')).filter(m => m.status !== 'ARCHIVED'), by = new Map(all.map(m => [m.id, m]));
    const rec = ids.map(i => by.get(i)).filter(Boolean), g = {}; rec.forEach(m => splitCsv(m.genre).forEach(x => g[x] = (g[x] || 0) + 1));
    const top = Object.entries(g).sort((a, b) => b[1] - a[1]).slice(0, 2).map(x => x[0]);
    const fy = all.filter(m => !ids.includes(m.id) && splitCsv(m.genre).some(x => top.includes(x))).slice(0, 12);
    if (!rec.length || !hero.isConnected) return; const s = document.createElement('div'); s.className = 'cb-rails';
    s.innerHTML = `<section class="movie-section"><h2>Recently viewed</h2><div class="rail">${rec.map(pcard).join('')}</div></section>${fy.length ? `<section class="movie-section"><h2>For you</h2><p class="muted">Because you looked at ${esc(top.join(' & '))}</p><div class="rail">${fy.map(pcard).join('')}</div></section>` : ''}`;
    hero.after(s); };
  const rewards = async head => {
    if (me?.role !== 'CUSTOMER') return; const l = await api('/customer/bookings'), pts = l.filter(b => b.status === 'CONFIRMED').reduce((a, b) => a + Math.floor(Number(b.totalAmount) / 10), 0);
    const tier = pts >= 1500 ? 'Gold' : pts >= 500 ? 'Silver' : 'Bronze', next = pts >= 1500 ? 0 : pts >= 500 ? 1500 - pts : 500 - pts;
    if (!head.isConnected) return; const d = document.createElement('div'); d.className = 'cb-banner';
    d.innerHTML = `🎁 <span>${pts} reward points · ${tier} member<br><small>1 point per ₹10 spent${next ? ` · ${next} more points to the next level` : ''}</small></span>`; head.after(d); };
  let busy = false, t;
  const enhance = () => { if (busy) return; busy = true; try {
    seen(); const h = $('#app .hero3'); if (h && !h.dataset.enh) { h.dataset.enh = 1; rails(h).catch(() => {}); }
    const ph = location.hash === '#/bookings' && $('#app .page-heading'); if (ph && !ph.dataset.enh) { ph.dataset.enh = 1; rewards(ph).catch(() => {}); }
    } finally { busy = false; } };
  new MutationObserver(() => { clearTimeout(t); t = setTimeout(enhance, 60); }).observe(document.body, { childList: true, subtree: true });
  enhance();
})();
