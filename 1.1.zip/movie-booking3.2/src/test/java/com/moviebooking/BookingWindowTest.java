package com.moviebooking;

import static org.junit.jupiter.api.Assertions.*;

import com.moviebooking.entity.Theatre;
import com.moviebooking.service.CatalogService;
import java.time.LocalDate;
import org.junit.jupiter.api.Test;

class BookingWindowTest {
    @Test
    void defaultsToSevenDaysAndClampsToFourToSeven() {
        Theatre t = new Theatre();
        assertEquals(7, t.windowDays());
        t.setBookingWindowDays(4); assertEquals(4, t.windowDays());
        t.setBookingWindowDays(2); assertEquals(4, t.windowDays());
        t.setBookingWindowDays(30); assertEquals(7, t.windowDays());
    }

    @Test
    void windowCoversTodayAndTheNextDaysOnly() {
        Theatre t = new Theatre();
        t.setBookingWindowDays(4);
        LocalDate today = LocalDate.now();
        assertTrue(CatalogService.withinWindow(t, today));
        assertTrue(CatalogService.withinWindow(t, today.plusDays(3)));
        assertFalse(CatalogService.withinWindow(t, today.plusDays(4)));
        assertFalse(CatalogService.withinWindow(t, today.minusDays(1)));
    }
}
