package com.moviebooking;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.moviebooking.entity.Screen;
import com.moviebooking.entity.Theatre;
import com.moviebooking.service.ScreenOverrideCommissionPolicy;
import java.math.BigDecimal;
import org.junit.jupiter.api.Test;

class CommissionPolicyTest {
    private final ScreenOverrideCommissionPolicy policy = new ScreenOverrideCommissionPolicy(new BigDecimal("10.00"));

    private Screen screen(String theatreRate, String screenRate) {
        Theatre t = new Theatre();
        if (theatreRate != null) t.setCommissionPercent(new BigDecimal(theatreRate));
        Screen s = new Screen();
        s.setTheatre(t);
        if (screenRate != null) s.setCommissionPercent(new BigDecimal(screenRate));
        return s;
    }

    @Test
    void screenOverridesTheatreWhichOverridesDefault() {
        assertEquals(new BigDecimal("15.00"), policy.effectiveRate(screen("20.00", "15.00")));  // screen wins
        assertEquals(new BigDecimal("20.00"), policy.effectiveRate(screen("20.00", null)));     // theatre default
        assertEquals(new BigDecimal("10.00"), policy.effectiveRate(screen(null, null)));        // platform default
    }

    @Test
    void commissionOn200At15PercentIs30() {
        BigDecimal c = policy.commission(new BigDecimal("200.00"), new BigDecimal("15.00"));
        assertEquals(new BigDecimal("30.00"), c);
        assertEquals(new BigDecimal("170.00"), new BigDecimal("200.00").subtract(c));
    }
}
