package com.moviebooking;

import static org.junit.jupiter.api.Assertions.*;

import com.moviebooking.service.MovieImportService;
import com.moviebooking.service.metadata.ImportedMovie;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

class MovieImportValidationTest {
    private final MovieImportService service = new MovieImportService(List.of(), null, null, null, null);

    private ImportedMovie complete() {
        ImportedMovie m = new ImportedMovie();
        m.setTitle("Sample"); m.setLanguage("Tamil"); m.setGenre("Drama"); m.setRuntimeMinutes(140);
        m.setReleaseDate(LocalDate.now().plusDays(10)); m.setPosterUrl("https://example.com/p.jpg");
        m.setDescription("A long enough description that proves the plot is really present.");
        return m;
    }

    @SuppressWarnings("unchecked")
    private List<String> check(ImportedMovie m) {
        ReflectionTestUtils.setField(service, "minDescription", 40);
        return (List<String>) ReflectionTestUtils.invokeMethod(service, "validate", m, LocalDate.now());
    }

    @Test void completeRecordPasses() { assertTrue(check(complete()).isEmpty()); }

    @Test void posterAndDescriptionAreOptional() {
        ImportedMovie m = complete(); m.setPosterUrl(null); m.setDescription(null);
        assertTrue(check(m).isEmpty());
    }

    @Test void missingRuntimeAndGenreAreReported() {
        ImportedMovie m = complete(); m.setRuntimeMinutes(null); m.setGenre(null);
        List<String> p = check(m);
        assertEquals(2, p.size());
        assertTrue(p.contains("genre missing"));
    }

    @Test void farFutureOrMissingDateIsRejected() {
        ImportedMovie m = complete(); m.setReleaseDate(LocalDate.now().plusDays(900));
        assertFalse(check(m).isEmpty());
        m.setReleaseDate(null);
        assertTrue(check(m).contains("release date missing"));
    }
}
