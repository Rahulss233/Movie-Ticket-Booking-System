package com.moviebooking;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

import com.moviebooking.entity.Movie;
import com.moviebooking.entity.Offer;
import com.moviebooking.entity.Screen;
import com.moviebooking.entity.Show;
import com.moviebooking.entity.Theatre;
import com.moviebooking.entity.User;
import com.moviebooking.exception.BadRequestException;
import com.moviebooking.repository.MovieRepository;
import com.moviebooking.repository.OfferRedemptionRepository;
import com.moviebooking.repository.OfferRepository;
import com.moviebooking.repository.ShowSeatRepository;
import com.moviebooking.repository.TheatreRepository;
import com.moviebooking.service.AuditService;
import com.moviebooking.service.OfferService;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/** The server alone decides discounts: these cases cover the rules a customer could try to bend. */
class OfferServiceTest {
    OfferRepository offers = mock(OfferRepository.class);
    OfferRedemptionRepository redemptions = mock(OfferRedemptionRepository.class);
    OfferService service = new OfferService(offers, redemptions, mock(MovieRepository.class), mock(TheatreRepository.class), mock(ShowSeatRepository.class), mock(AuditService.class));
    User user = new User();
    Show show = new Show();
    Theatre theatre = new Theatre();
    Movie movie = new Movie();

    @BeforeEach
    void setUp() {
        user.setId(1L); theatre.setId(10L); movie.setId(5L);
        Screen screen = new Screen(); screen.setTheatre(theatre); show.setScreen(screen); show.setMovie(movie);
    }

    private Offer offer(String type, String value) {
        Offer o = new Offer();
        o.setId(1L); o.setCode("SAVE"); o.setTitle("t"); o.setDiscountType(type); o.setDiscountValue(new BigDecimal(value));
        o.setStartsAt(LocalDateTime.now().minusDays(1)); o.setEndsAt(LocalDateTime.now().plusDays(1));
        when(offers.findByCodeIgnoreCase("save")).thenReturn(Optional.of(o));
        return o;
    }

    @Test void percentDiscountIsCappedByMaximum() {
        Offer o = offer("PERCENT", "50"); o.setMaxDiscount(new BigDecimal("100"));
        assertEquals(new BigDecimal("100.00"), service.check("save", user, show, new BigDecimal("600")).discount());
    }

    @Test void flatDiscountNeverMakesBookingFree() {
        offer("FLAT", "500");
        assertEquals(new BigDecimal("199.00"), service.check("save", user, show, new BigDecimal("200")).discount());
    }

    @Test void expiredCouponIsRejected() {
        Offer o = offer("FLAT", "50"); o.setEndsAt(LocalDateTime.now().minusMinutes(1));
        assertThrows(BadRequestException.class, () -> service.check("save", user, show, new BigDecimal("300")));
    }

    @Test void pausedCouponIsRejected() {
        Offer o = offer("FLAT", "50"); o.setStatus("PAUSED");
        assertThrows(BadRequestException.class, () -> service.check("save", user, show, new BigDecimal("300")));
    }

    @Test void belowMinimumIsRejected() {
        Offer o = offer("FLAT", "50"); o.setMinAmount(new BigDecimal("500"));
        assertThrows(BadRequestException.class, () -> service.check("save", user, show, new BigDecimal("300")));
    }

    @Test void otherTheatreOfferIsRejected() {
        Offer o = offer("FLAT", "50"); Theatre other = new Theatre(); other.setId(99L); o.setTheatre(other);
        assertThrows(BadRequestException.class, () -> service.check("save", user, show, new BigDecimal("300")));
    }

    @Test void perUserLimitIsEnforced() {
        offer("FLAT", "50");
        when(redemptions.countActiveForUser(anyLong(), anyLong())).thenReturn(1L);
        assertThrows(BadRequestException.class, () -> service.check("save", user, show, new BigDecimal("300")));
    }

    @Test void totalLimitIsEnforced() {
        Offer o = offer("FLAT", "50"); o.setTotalLimit(3);
        when(redemptions.countActive(anyLong())).thenReturn(3L);
        assertThrows(BadRequestException.class, () -> service.check("save", user, show, new BigDecimal("300")));
    }

    @Test void unknownCodeIsRejected() {
        when(offers.findByCodeIgnoreCase("nope")).thenReturn(Optional.empty());
        assertThrows(BadRequestException.class, () -> service.check("nope", user, show, new BigDecimal("300")));
    }
}
