package com.moviebooking;

import static org.junit.jupiter.api.Assertions.*;

import com.moviebooking.dto.Dtos.RowDef;
import com.moviebooking.exception.BadRequestException;
import com.moviebooking.service.ScreenLayoutParser;
import com.moviebooking.service.ScreenLayoutParser.SeatSpec;
import java.util.List;
import org.junit.jupiter.api.Test;

class ScreenLayoutParserTest {
    @Test void aislesAndMissingNumbersKeepGridPositions() {
        List<SeatSpec> s = ScreenLayoutParser.parse(List.of(new RowDef("E", "FIRST CLASS", "1-2,_,18-19")));
        assertEquals(4, s.size());
        assertEquals("E", s.get(0).row());
        assertEquals(18, s.get(2).number());
        assertEquals(3, s.get(2).gridCol());          // seats 0,1 then one empty column
    }

    @Test void blankRowIsASpacerLine() {
        List<SeatSpec> s = ScreenLayoutParser.parse(List.of(new RowDef("A", "BOX", "1-3"), new RowDef("", "", ""), new RowDef("B", "BOX", "1-3")));
        assertEquals(0, s.get(0).gridRow());
        assertEquals(2, s.get(3).gridRow());
    }

    @Test void sectionsKeepFirstAppearanceOrder() {
        List<SeatSpec> s = ScreenLayoutParser.parse(List.of(new RowDef("A", "GOLD", "1-2"), new RowDef("B", "SILVER", "1-2"), new RowDef("C", "GOLD", "1-2")));
        assertEquals(List.of("GOLD", "SILVER"), ScreenLayoutParser.sections(s));
    }

    @Test void duplicateSeatIsRejected() {
        assertThrows(BadRequestException.class, () -> ScreenLayoutParser.parse(List.of(new RowDef("A", "X", "1-3,2"))));
    }

    @Test void badPatternSectionAndEmptyAreRejected() {
        assertThrows(BadRequestException.class, () -> ScreenLayoutParser.parse(List.of(new RowDef("A", "X", "1-abc"))));
        assertThrows(BadRequestException.class, () -> ScreenLayoutParser.parse(List.of(new RowDef("A", "", "1-3"))));
        assertThrows(BadRequestException.class, () -> ScreenLayoutParser.parse(List.of()));
        assertThrows(BadRequestException.class, () -> ScreenLayoutParser.parse(List.of(new RowDef("A", "X", "5-2"))));
    }

    @Test void labelsAreUppercasedAndSeatNumbersKept() {
        List<SeatSpec> s = ScreenLayoutParser.parse(List.of(new RowDef("e", "X", "1,18")));
        assertEquals("E", s.get(0).row());
        assertEquals(18, s.get(1).number());
    }

    @Test void starShorthandAndReverseNumbering() {
        List<SeatSpec> a = ScreenLayoutParser.parse(List.of(new RowDef("A*5", "X", "")));
        assertEquals(5, a.size()); assertEquals(1, a.get(0).number()); assertEquals(5, a.get(4).number());
        List<SeatSpec> z = ScreenLayoutParser.parse(List.of(new RowDef("Z*-5", "X", "")));
        assertEquals("Z", z.get(0).row()); assertEquals(5, z.get(0).number()); assertEquals(1, z.get(4).number());
        List<SeatSpec> r = ScreenLayoutParser.parse(List.of(new RowDef("B", "X", "18-16,_,*-2")));
        assertEquals(18, r.get(0).number()); assertEquals(16, r.get(2).number()); assertEquals(2, r.get(3).number()); assertEquals(4, r.get(3).gridCol());
    }
}
