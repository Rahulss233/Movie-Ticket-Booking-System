package com.moviebooking;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.moviebooking.dto.Dtos.HoldRequest;
import com.moviebooking.dto.Dtos.RegisterRequest;
import com.moviebooking.entity.Location;
import com.moviebooking.entity.Movie;
import com.moviebooking.entity.Screen;
import com.moviebooking.entity.Seat;
import com.moviebooking.entity.Show;
import com.moviebooking.entity.ShowSeat;
import com.moviebooking.entity.Theatre;
import com.moviebooking.entity.User;
import com.moviebooking.enums.LocationType;
import com.moviebooking.enums.MovieStatus;
import com.moviebooking.enums.Role;
import com.moviebooking.enums.SeatCategory;
import com.moviebooking.enums.TheatreStatus;
import com.moviebooking.repository.LocationRepository;
import com.moviebooking.repository.MovieRepository;
import com.moviebooking.repository.ScreenRepository;
import com.moviebooking.repository.SeatRepository;
import com.moviebooking.repository.ShowRepository;
import com.moviebooking.repository.ShowSeatRepository;
import com.moviebooking.repository.TheatreRepository;
import com.moviebooking.service.AuthService;
import com.moviebooking.service.BookingService;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

/** Two customers race for the same seat: exactly one must win. (Run with: mvn test) */
@SpringBootTest
class SeatBookingConcurrencyTest {
    @Autowired AuthService auth;
    @Autowired BookingService bookingService;
    @Autowired LocationRepository locations;
    @Autowired TheatreRepository theatres;
    @Autowired ScreenRepository screens;
    @Autowired SeatRepository seats;
    @Autowired MovieRepository movies;
    @Autowired ShowRepository shows;
    @Autowired ShowSeatRepository showSeats;

    @Test
    void onlyOneCustomerCanHoldTheSameSeat() throws Exception {
        User owner = auth.createUser(new RegisterRequest("Owner", "owner@t.local", "9111111111", "Passw0rdX"), Role.THEATRE_ADMIN);
        User c1 = auth.createUser(new RegisterRequest("C1", "c1@t.local", "9222222222", "Passw0rdX"), Role.CUSTOMER);
        User c2 = auth.createUser(new RegisterRequest("C2", "c2@t.local", "9333333333", "Passw0rdX"), Role.CUSTOMER);
        Location city = locations.findAll().stream().filter(l -> l.getType() == LocationType.CITY).findFirst().orElseThrow();

        Theatre t = new Theatre();
        t.setName("T"); t.setAddress("addr"); t.setCity(city); t.setOwner(owner);
        t.setContactPhone("9444444444"); t.setLicenseNumber("LIC-1"); t.setStatus(TheatreStatus.APPROVED);
        theatres.save(t);
        Screen sc = new Screen(); sc.setTheatre(t); sc.setName("S1"); sc.setTotalSeats(1); screens.save(sc);
        Seat seat = new Seat(); seat.setScreen(sc); seat.setRowLabel("A"); seat.setSeatNumber(1); seat.setCategory(SeatCategory.REGULAR); seats.save(seat);
        Movie m = new Movie(); m.setTitle("M"); m.setGenre("Drama"); m.setLanguage("Tamil"); m.setDurationMinutes(120);
        m.setStatus(MovieStatus.ACTIVE); m.setReleaseDate(LocalDate.now().minusDays(1)); movies.save(m);
        Show show = new Show(); show.setMovie(m); show.setScreen(sc);
        show.setStartTime(LocalDateTime.now().plusDays(2)); show.setEndTime(LocalDateTime.now().plusDays(2).plusHours(3));
        show.setRegularPrice(new BigDecimal("150")); show.setPremiumPrice(new BigDecimal("250")); shows.save(show);
        ShowSeat ss = new ShowSeat(); ss.setShow(show); ss.setSeat(seat); ss.setPrice(new BigDecimal("150")); showSeats.save(ss);

        CountDownLatch go = new CountDownLatch(1);
        AtomicInteger ok = new AtomicInteger();
        ExecutorService pool = Executors.newFixedThreadPool(2);
        List<Future<?>> fs = new java.util.ArrayList<>();
        for (User u : List.of(c1, c2)) {
            fs.add(pool.submit(() -> {
                try {
                    go.await();
                    bookingService.holdSeats(u, new HoldRequest(show.getId(), List.of(seat.getId())));
                    ok.incrementAndGet();
                } catch (Exception expected) { /* the loser gets a conflict */ }
            }));
        }
        go.countDown();
        for (Future<?> f : fs) f.get(20, TimeUnit.SECONDS);
        pool.shutdown();
        assertEquals(1, ok.get(), "exactly one hold must succeed");
    }
}
