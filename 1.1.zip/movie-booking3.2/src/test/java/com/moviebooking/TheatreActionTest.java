package com.moviebooking;

import static org.junit.jupiter.api.Assertions.*;

import com.moviebooking.enums.TheatreAction;
import com.moviebooking.enums.TheatreStatus;
import org.junit.jupiter.api.Test;

class TheatreActionTest {
    @Test
    void approvalRulesAreEnforced() {
        assertTrue(TheatreAction.APPROVE.canApplyTo(TheatreStatus.PENDING_VERIFICATION));
        assertFalse(TheatreAction.APPROVE.canApplyTo(TheatreStatus.REJECTED));
        assertFalse(TheatreAction.SUSPEND.canApplyTo(TheatreStatus.PENDING_VERIFICATION));
        assertTrue(TheatreAction.REACTIVATE.canApplyTo(TheatreStatus.SUSPENDED));
        assertTrue(TheatreAction.REJECT.isReasonRequired());
        assertFalse(TheatreAction.APPROVE.isReasonRequired());
    }
}
